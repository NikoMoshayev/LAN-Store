"""NVM release image comparison for GbE SV.

Compares a candidate NVM image against the most recent official release and
reports every differing **bit**, annotated with its field name.

Field names are resolved by merging two sources, because neither alone is
complete:
  1. The Nahum NVM map workbook (`.gbe-nvm/maps/.../*.xlsm`) — authoritative for
     layout, but some entries are stale (e.g. word 0x11 bits 3:0 are documented
     "Reserved" even though bit 2 is `fextnvm7_side_clk_ungate`).
  2. `tools/fextnvm_register_definitions.py` — extracted from RTL, and carries an
     explicit NVM-word -> FEXTNVM register mapping.

Changes are split into *functional* (real config bits) and *bookkeeping*
(image version, EETRACK ID, checksum) so a reviewer sees the real delta first.

Office-friendly: pure offline analysis once the images are on disk.
"""

from __future__ import annotations

import argparse
import html
import json
import re
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

REPO_ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
MAP_XLSM = REPO_ROOT / ".gbe-nvm/maps/Nahum13_nvl_pch_s/n13_nvl_pch_s_nvm_map.xlsm"
MAP_CACHE = REPO_ROOT / ".gbe-nvm/maps/Nahum13_nvl_pch_s/nvm_map_cache.json"
# Copying nvm_compare.py + nvm_map_cache.json + fextnvm_register_definitions.py
# next to each other makes the tool portable off-repo (field names survive
# without the workbook or openpyxl).
LOCAL_MAP_CACHE = HERE / "nvm_map_cache.json"
MAP_CACHE_VERSION = 2
FEXTNVM_DEFS = REPO_ROOT / "tools/fextnvm_register_definitions.py"
LOCAL_FEXTNVM_DEFS = HERE / "fextnvm_register_definitions.py"

CHECKSUM_WORD = 0x3F
CHECKSUM_TARGET = 0xBABA
CHECKSUM_RANGE = range(0x00, 0x40)

VERSION_WORD = 0x05
EETRACK_WORDS = (0x06, 0x07)
BOOKKEEPING_WORDS = {VERSION_WORD, CHECKSUM_WORD, *EETRACK_WORDS}

SKU_PATTERNS = {"Cons": re.compile(r"_cons_", re.I), "Corp": re.compile(r"_corp_", re.I)}

# Field names come from this platform's map; other Nahum-family platforms share
# most of the layout but not every bit.
MAP_PRODUCT = "NVL-S (Nahum13 nvl_pch_s)"
MAP_PRODUCT_RE = re.compile(r"NVL[_-]PCH[_-]S", re.I)
PRODUCT_RE = re.compile(r"^GBE[_-](.+?)[_-]ALL[_-]", re.I)


def product_of(name: str) -> str:
    m = PRODUCT_RE.search(name)
    return m.group(1).upper() if m else ""


# The workbook is full of smart punctuation, which turns to mojibake on a
# cp437/cp1252 Windows console. Normalise once at parse time.
_PUNCT = str.maketrans({
    "\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"',
    "\u2013": "-", "\u2014": "-", "\u2212": "-", "\u2026": "...",
    "\u00a0": " ", "\u00b7": "-",
})


def _ascii(text: str) -> str:
    return text.translate(_PUNCT).encode("ascii", "replace").decode("ascii")


# --------------------------------------------------------------------- images --

@dataclass
class NvmImage:
    """A single NVM region image."""

    name: str
    data: bytes
    sku: str | None = None
    source: str = ""

    @property
    def word_count(self) -> int:
        return len(self.data) // 2

    def word(self, index: int) -> int:
        return self.data[2 * index] | (self.data[2 * index + 1] << 8)

    def words(self) -> list[int]:
        return [self.word(i) for i in range(self.word_count)]

    @property
    def checksum(self) -> int:
        return sum(self.word(i) for i in CHECKSUM_RANGE) & 0xFFFF

    @property
    def checksum_ok(self) -> bool:
        return self.checksum == CHECKSUM_TARGET

    @property
    def image_version(self) -> str:
        """Word 0x05 holds the release version in nibbles: 0x2064 -> 2.6, 0x0074 -> 0.7."""
        w = self.word(VERSION_WORD)
        return f"{(w >> 12) & 0xF}.{(w >> 4) & 0xF}"

    @property
    def product(self) -> str:
        return product_of(self.name)


def _parse_hex_words(text: str) -> bytes:
    """Release .txt files are 16-bit word values in hex, 8 per line."""
    tokens = re.findall(r"\b[0-9A-Fa-f]{4}\b", text)
    out = bytearray()
    for tok in tokens:
        value = int(tok, 16)
        out += bytes((value & 0xFF, (value >> 8) & 0xFF))
    return bytes(out)


def _sku_of(name: str) -> str | None:
    for sku, pattern in SKU_PATTERNS.items():
        if pattern.search(name):
            return sku
    return None


def load_image(path: str | Path) -> NvmImage:
    """Load a single .bin (raw) or .txt (hex word dump) NVM image."""
    p = Path(path)
    data = p.read_bytes() if p.suffix.lower() == ".bin" else _parse_hex_words(p.read_text(errors="replace"))
    return NvmImage(name=p.stem, data=data, sku=_sku_of(p.name), source=str(p))


def load_release(path: str | Path) -> dict[str, NvmImage]:
    """Load a release package: .zip, an extracted directory, or a single image.

    Returns {sku: NvmImage}; single images without a recognisable SKU use key "".
    """
    p = Path(path)

    if p.is_file() and p.suffix.lower() == ".zip":
        out: dict[str, NvmImage] = {}
        with zipfile.ZipFile(p) as zf:
            for info in zf.infolist():
                if info.is_dir() or not info.filename.lower().endswith(".bin"):
                    continue
                name = Path(info.filename).stem
                raw = zf.read(info)
                sku = _sku_of(info.filename) or ""
                out[sku] = NvmImage(name=name, data=raw, sku=sku or None, source=f"{p}!{info.filename}")
        if not out:
            raise ValueError(f"no .bin images found inside {p}")
        return out

    if p.is_dir():
        out = {}
        for binf in sorted(p.rglob("*.bin")):
            img = load_image(binf)
            out[img.sku or ""] = img
        if not out:
            raise ValueError(f"no .bin images found under {p}")
        return out

    img = load_image(p)
    return {img.sku or "": img}


# ------------------------------------------------------------- field resolver --

@dataclass
class Field:
    name: str
    description: str = ""
    source: str = ""

    def __post_init__(self) -> None:
        self.name = _ascii(self.name)
        self.description = _ascii(self.description)
        if self.description.strip().lower() in {"n/a", "reserved", "none"}:
            self.description = ""
        if self.description.strip() == self.name.strip():
            self.description = ""

    def label(self) -> str:
        text = self.name
        if self.description:
            text = f"{text} - {self.description}" if text else self.description
        return text or "(unnamed)"


# Map rows often carry only the register half as a "name" (e.g. "FEXTNVM7 Word 1"),
# which identifies the word but not the bit. Treat those as unnamed so the
# RTL-derived per-bit name wins.
GENERIC_NAME_RE = re.compile(r"^FEXTNVM\d*\s+Word\s+\d+$", re.I)
# "FEXTNVM7 Word 1" -> register FEXTNVM7, low half; "Word 2" -> high half.
REG_HALF_RE = re.compile(r"^(FEXTNVM\d*)\s+Word\s+(\d+)$", re.I)


def _is_placeholder(name: str) -> bool:
    if not name:
        return True
    stripped = name.strip()
    return stripped.lower() in {"reserved", "n/a", "(unnamed)", "rserved"} or bool(GENERIC_NAME_RE.match(stripped))


class FieldResolver:
    """Resolves (word, bit) -> Field by merging the NVM map and RTL definitions."""

    def __init__(self, map_ranges: dict[int, list[tuple[int, int, Field]]],
                 word_regs: dict[int, tuple[str, int]],
                 reg_bits: dict[str, dict[int, Field]]):
        self._map = map_ranges
        self._word_regs = word_regs
        self._reg_bits = reg_bits

    # -- loading -------------------------------------------------------------

    @classmethod
    def load(cls, refresh: bool = False) -> "FieldResolver":
        ranges, word_regs = cls._load_map(refresh)
        return cls(ranges, word_regs, cls._load_fextnvm())

    @staticmethod
    def _load_map(refresh: bool) -> tuple[dict[int, list[tuple[int, int, Field]]],
                                          dict[int, tuple[str, int]]]:
        raw: list[dict] | None = None
        for cache in (MAP_CACHE, LOCAL_MAP_CACHE):
            if raw is None and cache.exists() and not refresh:
                cached = json.loads(cache.read_text())
                if isinstance(cached, dict) and cached.get("version") == MAP_CACHE_VERSION:
                    raw = cached["rows"]
        if raw is None and MAP_XLSM.exists():
            raw = FieldResolver._read_xlsm()
            if raw is not None:
                MAP_CACHE.write_text(json.dumps({"version": MAP_CACHE_VERSION, "rows": raw}, indent=1))
        if raw is None:
            return {}, {}

        ranges: dict[int, list[tuple[int, int, Field]]] = {}
        word_regs: dict[int, tuple[str, int]] = {}
        for row in raw:
            ranges.setdefault(row["word"], []).append(
                (row["hi"], row["lo"], Field(row["name"], row["desc"], "nvm-map"))
            )
            if row.get("reg"):
                word_regs[row["word"]] = (row["reg"], row["half"])
        return ranges, word_regs

    @staticmethod
    def _read_xlsm() -> list[dict] | None:
        try:
            import openpyxl
        except ImportError:
            return None

        wb = openpyxl.load_workbook(MAP_XLSM, data_only=True, read_only=True)
        ws = wb["full nvm map"]
        rows: list[dict] = []
        for row in ws.iter_rows(values_only=True):
            if not row or row[0] is None:
                continue
            try:
                word = int(str(row[0]).strip().lower().rstrip("h"), 16)
            except ValueError:
                continue
            bits = str(row[1]).strip() if row[1] is not None else "15:0"
            if ":" in bits:
                hi, lo = (int(x) for x in bits.split(":"))
            else:
                try:
                    hi = lo = int(bits)
                except ValueError:
                    hi, lo = 15, 0
            rtl = str(row[2]).strip() if row[2] else ""
            spec = str(row[3]).strip() if row[3] else ""
            desc = str(row[5]).strip().replace("\n", " ") if row[5] else ""
            name = rtl if not _is_placeholder(rtl) else (spec if not _is_placeholder(spec) else "")

            reg, half = "", 0
            m = REG_HALF_RE.match(spec)
            if m:
                reg = m.group(1).upper()
                half = 16 if m.group(2) == "2" else 0

            rows.append({"word": word, "hi": hi, "lo": lo, "name": name,
                         "desc": desc, "reg": reg, "half": half})
        return rows

    @staticmethod
    def _load_fextnvm() -> dict[str, dict[int, Field]]:
        """Register name -> {absolute bit: Field} from the RTL-extracted tables.

        Only the per-bit field names are used; the `nvm_words` entries in that
        file are incomplete (`word_xxh`) and partly wrong, so the word mapping
        comes from the NVM map instead.
        """
        defs = next((p for p in (FEXTNVM_DEFS, LOCAL_FEXTNVM_DEFS) if p.exists()), None)
        if defs is None:
            return {}
        namespace: dict = {}
        exec(compile(defs.read_text(), str(defs), "exec"), namespace)
        regs = namespace.get("FEXTNVM_REGISTERS", {})

        out: dict[str, dict[int, Field]] = {}
        for reg_name, reg in regs.items():
            for key, spec in (reg.get("fields") or {}).items():
                name = spec.get("name", "")
                if _is_placeholder(name):
                    continue
                if isinstance(key, str) and ":" in key:
                    hi, lo = (int(x) for x in key.split(":")[:2])
                    hi, lo = max(hi, lo), min(hi, lo)
                    indices = range(lo, hi + 1)
                else:
                    indices = [int(key)]
                for bit in indices:
                    out.setdefault(reg_name.upper(), {})[bit] = Field(
                        name, spec.get("description", ""), f"rtl:{reg_name}[{bit}]"
                    )
        return out

    # -- lookup --------------------------------------------------------------

    def _rtl_field(self, word: int, bit: int) -> Field | None:
        entry = self._word_regs.get(word)
        if not entry:
            return None
        reg, half = entry
        return self._reg_bits.get(reg, {}).get(bit + half)

    def resolve(self, word: int, bit: int) -> Field:
        map_field: Field | None = None
        for hi, lo, fld in self._map.get(word, []):
            if lo <= bit <= hi:
                map_field = fld
                break

        if map_field and not _is_placeholder(map_field.name):
            return map_field

        # Map row is generic ("FEXTNVM7 Word 1") or reserved: take the RTL name,
        # but keep the map's description when it carries real information.
        rtl_field = self._rtl_field(word, bit)
        if rtl_field:
            desc = rtl_field.description
            source = rtl_field.source
            if map_field and map_field.description and not _is_placeholder(map_field.description):
                desc = map_field.description
                source = f"{rtl_field.source}+nvm-map"
            return Field(rtl_field.name, desc, source)

        if map_field:
            return map_field
        return Field("", "", "unmapped")


# ------------------------------------------------------------------ comparing --

@dataclass
class BitChange:
    word: int
    bit: int
    old: int
    new: int
    field: Field

    @property
    def action(self) -> str:
        return "SET" if self.new else "CLEAR"


@dataclass
class WordChange:
    word: int
    old: int
    new: int
    bits: list[BitChange] = field(default_factory=list)

    @property
    def is_bookkeeping(self) -> bool:
        return self.word in BOOKKEEPING_WORDS


@dataclass
class Comparison:
    old: NvmImage
    new: NvmImage
    changes: list[WordChange]
    bits_scanned: int
    size_mismatch: bool = False

    @property
    def functional(self) -> list[WordChange]:
        return [c for c in self.changes if not c.is_bookkeeping]

    @property
    def bookkeeping(self) -> list[WordChange]:
        return [c for c in self.changes if c.is_bookkeeping]

    @property
    def changed_bits(self) -> int:
        return sum(len(c.bits) for c in self.changes)

    @property
    def map_note(self) -> str:
        """Warn when bit names are borrowed from a different platform's map."""
        product = self.new.product or self.old.product
        if product and not MAP_PRODUCT_RE.search(product):
            return (f"Field names come from the {MAP_PRODUCT} NVM map, but these images are "
                    f"{product}. Layout is shared across the Nahum family, so the diff itself "
                    f"is exact — but treat bit *names* as indicative and confirm against the "
                    f"{product} map before acting on them.")
        return ""

    @property
    def functional_bits(self) -> int:
        return sum(len(c.bits) for c in self.functional)

    def verdict(self) -> str:
        problems = []
        if self.size_mismatch:
            problems.append("SIZE MISMATCH")
        if not self.new.checksum_ok:
            problems.append(f"BAD CHECKSUM in new image (0x{self.new.checksum:04X} != 0xBABA)")
        if not self.old.checksum_ok:
            problems.append(f"BAD CHECKSUM in baseline (0x{self.old.checksum:04X} != 0xBABA)")
        if problems:
            return "FAIL: " + "; ".join(problems)
        if not self.changes:
            return "IDENTICAL: images match bit for bit"
        return f"OK: {self.functional_bits} functional bit(s) changed across {len(self.functional)} word(s)"


def compare(old: NvmImage, new: NvmImage, resolver: FieldResolver | None = None) -> Comparison:
    """Bit-exact comparison of two NVM images."""
    resolver = resolver or FieldResolver.load()
    count = min(old.word_count, new.word_count)
    changes: list[WordChange] = []

    for w in range(count):
        wa, wb = old.word(w), new.word(w)
        if wa == wb:
            continue
        wc = WordChange(word=w, old=wa, new=wb)
        for bit in range(15, -1, -1):
            ba, bb = (wa >> bit) & 1, (wb >> bit) & 1
            if ba != bb:
                wc.bits.append(BitChange(w, bit, ba, bb, resolver.resolve(w, bit)))
        changes.append(wc)

    return Comparison(
        old=old,
        new=new,
        changes=changes,
        bits_scanned=count * 16,
        size_mismatch=old.word_count != new.word_count,
    )


def compare_releases(new_path: str | Path, baseline_path: str | Path,
                     resolver: FieldResolver | None = None) -> dict[str, Comparison]:
    """Compare two release packages SKU-for-SKU. Returns {sku: Comparison}."""
    resolver = resolver or FieldResolver.load()
    new_imgs, old_imgs = load_release(new_path), load_release(baseline_path)
    shared = [s for s in new_imgs if s in old_imgs]
    if not shared:
        raise ValueError(
            f"no matching SKUs: new has {sorted(new_imgs)}, baseline has {sorted(old_imgs)}"
        )
    return {sku: compare(old_imgs[sku], new_imgs[sku], resolver) for sku in sorted(shared)}


# ------------------------------------------------------------------ baselines --

VERSION_RE = re.compile(r"_(?:Version_)?(\d+)\.(\d+)_Release", re.I)


def release_version(path: str | Path) -> tuple[int, int] | None:
    m = VERSION_RE.search(Path(path).name)
    return (int(m.group(1)), int(m.group(2))) if m else None


def find_baselines(search_dirs: Iterable[str | Path], product: str = "") -> list[tuple[tuple[int, int], Path]]:
    """Find candidate official release packages, newest first."""
    found: dict[tuple[int, int], Path] = {}
    for d in search_dirs:
        d = Path(d)
        if not d.is_dir():
            continue
        for candidate in list(d.glob("*_Release*.zip")) + [p for p in d.glob("*_Release*") if p.is_dir()]:
            if product and product.lower() not in candidate.name.lower():
                continue
            ver = release_version(candidate)
            if ver and (ver not in found or candidate.suffix == ".zip"):
                found[ver] = candidate
    return sorted(found.items(), key=lambda kv: kv[0], reverse=True)


def latest_baseline(search_dirs: Iterable[str | Path], product: str = "",
                    below: tuple[int, int] | None = None) -> Path | None:
    for ver, path in find_baselines(search_dirs, product):
        if below is None or ver < below:
            return path
    return None


# -------------------------------------------------------------------- reports --

def render_text(cmp: Comparison, show_bookkeeping: bool = True) -> str:
    L: list[str] = []
    L.append(f"--- baseline : {cmp.old.name}   (v{cmp.old.image_version}, xsum 0x{cmp.old.checksum:04X})")
    L.append(f"+++ candidate: {cmp.new.name}   (v{cmp.new.image_version}, xsum 0x{cmp.new.checksum:04X})")
    L.append("")
    L.append(cmp.verdict())
    if cmp.map_note:
        L.append(f"NOTE: {cmp.map_note}")

    for title, group in (("FUNCTIONAL CHANGES", cmp.functional),
                         ("BOOKKEEPING (version / EETRACK / checksum)", cmp.bookkeeping)):
        if not group or (group is cmp.bookkeeping and not show_bookkeeping):
            continue
        L.append("")
        L.append(title)
        L.append("-" * len(title))
        for wc in group:
            L.append(f"  word 0x{wc.word:04X}  0x{wc.old:04X} -> 0x{wc.new:04X}"
                     f"   {wc.old:016b} -> {wc.new:016b}")
            for bc in wc.bits:
                L.append(f"      bit {bc.bit:2d}  {bc.old} -> {bc.new}  [{bc.action:5s}]  {bc.field.label()}")

    identical = cmp.bits_scanned - cmp.changed_bits
    L.append("")
    L.append(f"  scanned {cmp.bits_scanned:,} bits ({cmp.bits_scanned // 16:,} words)")
    L.append(f"  changed: {len(cmp.changes)} word(s), {cmp.changed_bits} bit(s)"
             f"  |  functional: {len(cmp.functional)} word(s), {cmp.functional_bits} bit(s)")
    L.append(f"  identical: {identical:,} bits ({100 * identical / cmp.bits_scanned:.4f}%)")
    return "\n".join(L)


def render_markdown(cmp: Comparison) -> str:
    L = [f"### {cmp.new.name}  vs  {cmp.old.name}", "", f"**{cmp.verdict()}**", ""]
    if cmp.map_note:
        L += [f"> **Note:** {cmp.map_note}", ""]
    L.append(f"- Baseline `v{cmp.old.image_version}` checksum `0x{cmp.old.checksum:04X}`"
             f" {'OK' if cmp.old.checksum_ok else 'INVALID'}")
    L.append(f"- Candidate `v{cmp.new.image_version}` checksum `0x{cmp.new.checksum:04X}`"
             f" {'OK' if cmp.new.checksum_ok else 'INVALID'}")
    L.append(f"- Scanned {cmp.bits_scanned:,} bits; {cmp.changed_bits} changed"
             f" ({cmp.functional_bits} functional)")
    L.append("")

    if cmp.functional:
        L += ["| Word | Bit | Change | Field |", "|---|---|---|---|"]
        for wc in cmp.functional:
            for bc in wc.bits:
                L.append(f"| `0x{wc.word:04X}` | {bc.bit} | `{bc.old}`→`{bc.new}` **{bc.action}** "
                         f"| {bc.field.label()} |")
    else:
        L.append("_No functional bit changes._")

    if cmp.bookkeeping:
        L += ["", "<details><summary>Bookkeeping words</summary>", ""]
        L += ["| Word | Old | New |", "|---|---|---|"]
        for wc in cmp.bookkeeping:
            L.append(f"| `0x{wc.word:04X}` | `0x{wc.old:04X}` | `0x{wc.new:04X}` |")
        L += ["", "</details>"]
    return "\n".join(L)


def _img_meta_row(label: str, img: NvmImage) -> str:
    state = "ok" if img.checksum_ok else "bad"
    mark = "valid" if img.checksum_ok else "INVALID"
    return (f"<tr><td>{label}</td><td><code>{html.escape(img.name)}</code></td>"
            f"<td>v{img.image_version}</td><td>{len(img.data)} B / {img.word_count} words</td>"
            f"<td class='{state}'>0x{img.checksum:04X} {mark}</td></tr>")


def render_html(comparisons: dict[str, Comparison], title: str = "NVM Comparison",
                notes: str = "") -> str:
    """Full review document: verdicts, metadata, functional diff, bookkeeping, SKU delta."""
    from datetime import datetime

    parts: list[str] = []

    # -- executive summary across all SKUs
    parts.append("<h2>Summary</h2><table><tr><th>SKU</th><th>Verdict</th>"
                 "<th>Functional bits</th><th>Total changed bits</th></tr>")
    for sku, cmp in comparisons.items():
        ok = cmp.verdict().startswith(("OK", "IDENTICAL"))
        parts.append(f"<tr><td><b>{html.escape(sku or 'image')}</b></td>"
                     f"<td class='{'ok' if ok else 'bad'}'>{html.escape(cmp.verdict())}</td>"
                     f"<td>{cmp.functional_bits}</td><td>{cmp.changed_bits}</td></tr>")
    parts.append("</table>")

    if notes:
        parts.append(f"<div class='notes'>{html.escape(notes)}</div>")

    for note in {c.map_note for c in comparisons.values() if c.map_note}:
        parts.append(f"<div class='notes'>{html.escape(note)}</div>")

    for sku, cmp in comparisons.items():
        ok = cmp.verdict().startswith(("OK", "IDENTICAL"))
        parts.append(f"<h2>{html.escape(sku or 'image')} "
                     f"<span class='{'ok' if ok else 'bad'}'>{html.escape(cmp.verdict())}</span></h2>")

        parts.append("<table><tr><th>Role</th><th>Image</th><th>Version</th><th>Size</th>"
                     "<th>Checksum</th></tr>")
        parts.append(_img_meta_row("Baseline", cmp.old))
        parts.append(_img_meta_row("Candidate", cmp.new))
        parts.append("</table>")

        identical = cmp.bits_scanned - cmp.changed_bits
        parts.append(f"<p class='meta'>{cmp.bits_scanned:,} bits compared "
                     f"({cmp.bits_scanned // 16:,} words) &middot; {cmp.changed_bits} changed "
                     f"&middot; {identical:,} identical "
                     f"({100 * identical / cmp.bits_scanned:.4f}%)</p>")

        parts.append("<h3>Functional changes</h3>")
        if cmp.functional:
            parts.append("<table><tr><th>Word</th><th>Bit</th><th>Change</th>"
                         "<th>Field</th><th>Description</th></tr>")
            for wc in cmp.functional:
                for bc in wc.bits:
                    cls = "set" if bc.new else "clr"
                    parts.append(
                        f"<tr><td><code>0x{wc.word:04X}</code><br>"
                        f"<span class='sub'>0x{wc.old:04X}&rarr;0x{wc.new:04X}</span></td>"
                        f"<td>{bc.bit}</td>"
                        f"<td class='{cls}'>{bc.old}&rarr;{bc.new}<br>{bc.action}</td>"
                        f"<td><code>{html.escape(bc.field.name or '(unnamed)')}</code></td>"
                        f"<td>{html.escape(bc.field.description)}</td></tr>")
            parts.append("</table>")
        else:
            parts.append("<p><em>None — no configuration bits changed.</em></p>")

        parts.append("<h3>Bookkeeping</h3>")
        if cmp.bookkeeping:
            parts.append("<table><tr><th>Word</th><th>Old</th><th>New</th><th>Field</th></tr>")
            for wc in cmp.bookkeeping:
                label = wc.bits[0].field.name if wc.bits else ""
                parts.append(f"<tr><td><code>0x{wc.word:04X}</code></td>"
                             f"<td><code>0x{wc.old:04X}</code></td>"
                             f"<td><code>0x{wc.new:04X}</code></td>"
                             f"<td>{html.escape(label or '(version / EETRACK / checksum)')}</td></tr>")
            parts.append("</table>")
            parts.append("<p class='meta'>These change on every rebuild and carry no "
                         "behavioural meaning.</p>")
        else:
            parts.append("<p><em>None.</em></p>")

    # -- SKU delta within the candidate, to catch one-sided edits
    cands = {s: c.new for s, c in comparisons.items() if s}
    if len(cands) == 2:
        (sa, ia), (sb, ib) = sorted(cands.items())
        resolver = FieldResolver.load()
        delta = compare(ia, ib, resolver)
        parts.append(f"<h2>SKU delta within candidate ({sa} vs {sb})</h2>")
        parts.append("<p class='meta'>Expected differences: EETRACK ID and Device ID. "
                     "Anything else should be justified by the NVM map's "
                     "<em>V version</em> / <em>LM version</em> columns.</p>")
        parts.append("<table><tr><th>Word</th><th>Bit</th><th>"
                     f"{html.escape(sa)}&rarr;{html.escape(sb)}</th><th>Field</th></tr>")
        for wc in delta.changes:
            for bc in wc.bits:
                parts.append(f"<tr><td><code>0x{wc.word:04X}</code></td><td>{bc.bit}</td>"
                             f"<td>{bc.old}&rarr;{bc.new}</td>"
                             f"<td>{html.escape(bc.field.label())}</td></tr>")
        parts.append("</table>")

    parts.append("<h2>Notes</h2><ul>"
                 "<li>Checksum covers words <code>0x00</code>&ndash;<code>0x3F</code> only and must "
                 "sum to <code>0xBABA</code>; changes above <code>0x3F</code> are not protected.</li>"
                 "<li>Each <code>FEXTNVMn</code> is 32-bit across two words: "
                 "&quot;Word 1&quot; = <code>[15:0]</code>, &quot;Word 2&quot; = <code>[31:16]</code>.</li>"
                 "<li>Field names merge the NVM map workbook (layout) with RTL-extracted "
                 "register definitions (per-bit names).</li></ul>")

    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    return f"""<!doctype html><html><head><meta charset="utf-8">
<title>{html.escape(title)}</title>
<style>
 body{{font:14px/1.55 Segoe UI,system-ui,sans-serif;margin:2rem auto;max-width:1100px;color:#1b1b1b}}
 h1{{margin-bottom:.1rem}} h2{{margin-top:2.2rem;border-bottom:1px solid #e3e3e3;padding-bottom:.2rem}}
 h3{{margin-top:1.3rem;font-size:1.02em;color:#333}}
 .meta,.stamp{{color:#666;font-size:.9em}}
 .sub{{color:#777;font-size:.85em}}
 code{{background:#f3f3f3;padding:1px 4px;border-radius:3px;font-size:.92em}}
 table{{border-collapse:collapse;margin:.5rem 0;width:100%}}
 th,td{{border:1px solid #ddd;padding:.35rem .6rem;text-align:left;vertical-align:top}}
 th{{background:#f7f7f7}}
 .set{{color:#0a7d28;font-weight:600}} .clr{{color:#b3261e;font-weight:600}}
 .ok{{color:#0a7d28}} .bad{{color:#b3261e;font-weight:600}}
 .notes{{background:#fff8e1;border-left:4px solid #f0b400;padding:.6rem .9rem;margin:1rem 0;white-space:pre-wrap}}
</style></head><body>
<h1>{html.escape(title)}</h1>
<p class="stamp">GbE NVM comparison &middot; generated {stamp}</p>
{''.join(parts)}
</body></html>
"""


# ------------------------------------------------------------------------ CLI --

def _cmd_compare(args) -> int:
    resolver = FieldResolver.load(refresh=args.refresh_map)

    baseline = args.baseline
    if baseline is None:
        dirs = args.search or [Path(args.new).parent, Path.home() / "Downloads"]
        below = release_version(args.new)
        found = latest_baseline(dirs, args.product, below=below)
        if not found:
            print("error: no baseline found; pass one explicitly or use --search", file=sys.stderr)
            return 2
        baseline = found
        print(f"# auto-selected baseline: {baseline}\n")

    comparisons = compare_releases(args.new, baseline, resolver)

    if args.format == "html":
        out = render_html(comparisons, title=f"{Path(args.new).name} vs {Path(baseline).name}")
    elif args.format == "md":
        out = "\n\n".join(render_markdown(c) for c in comparisons.values())
    else:
        out = "\n\n".join(
            f"{'=' * 78}\n  SKU: {sku or 'image'}\n{'=' * 78}\n" + render_text(c)
            for sku, c in comparisons.items()
        )

    if args.output:
        Path(args.output).write_text(out, encoding="utf-8")
        print(f"wrote {args.output}")
    else:
        print(out)

    return 0 if all(c.verdict().startswith(("OK", "IDENTICAL")) for c in comparisons.values()) else 1


def _cmd_check(args) -> int:
    rc = 0
    for sku, img in load_release(args.image).items():
        status = "OK" if img.checksum_ok else "INVALID"
        if not img.checksum_ok:
            rc = 1
        print(f"{sku or 'image':6s} {img.name}")
        print(f"       size      {len(img.data)} B ({img.word_count} words)")
        print(f"       version   v{img.image_version}  (word 0x05 = 0x{img.word(VERSION_WORD):04X})")
        print(f"       checksum  0x{img.checksum:04X}  {status}")
    return rc


def _cmd_show(args) -> int:
    resolver = FieldResolver.load()
    word = int(args.word, 0)
    for sku, img in load_release(args.image).items():
        value = img.word(word)
        print(f"{sku or 'image'}  word 0x{word:04X} = 0x{value:04X}  ({value:016b})")
        for bit in range(15, -1, -1):
            print(f"    bit {bit:2d} = {(value >> bit) & 1}   {resolver.resolve(word, bit).label()}")
    return 0


def _cmd_baselines(args) -> int:
    dirs = args.search or [Path.home() / "Downloads"]
    for (major, minor), path in find_baselines(dirs, args.product):
        print(f"  {major}.{minor:<4}  {path}")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="nvm_compare", description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("compare", help="bit-exact diff of a candidate against a baseline")
    c.add_argument("new", help="candidate .zip / directory / .bin / .txt")
    c.add_argument("baseline", nargs="?", help="baseline release; auto-detected if omitted")
    c.add_argument("--search", action="append", help="directory to search for baselines (repeatable)")
    c.add_argument("--product", default="", help="substring filter, e.g. NVL_PCH_S")
    c.add_argument("--format", choices=["text", "md", "html"], default="text")
    c.add_argument("-o", "--output", help="write report to file")
    c.add_argument("--refresh-map", action="store_true", help="re-read the NVM map workbook")
    c.set_defaults(func=_cmd_compare)

    k = sub.add_parser("check", help="validate checksum and show version of an image/release")
    k.add_argument("image")
    k.set_defaults(func=_cmd_check)

    s = sub.add_parser("show", help="decode every bit of one NVM word")
    s.add_argument("image")
    s.add_argument("word", help="word offset, e.g. 0x58")
    s.set_defaults(func=_cmd_show)

    b = sub.add_parser("baselines", help="list release packages found on disk, newest first")
    b.add_argument("--search", action="append")
    b.add_argument("--product", default="")
    b.set_defaults(func=_cmd_baselines)

    args = ap.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
