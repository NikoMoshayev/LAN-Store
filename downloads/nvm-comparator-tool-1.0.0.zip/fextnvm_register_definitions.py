#!/usr/bin/env python3
"""
FEXTNVM Register Field Definitions - Extracted from RTL
Source: gbe_t_gen_regs.v
Generated: 2026-01-12

Complete bit-field mapping for all FEXTNVM registers (1-13)
These are critical configuration registers for Intel GbE LAN Controller
"""

FEXTNVM_REGISTERS = {
    # =========================================================================
    # FEXTNVM (0x00028) - Future Extended NVM Register
    # Reset Value: 0x00000000
    # =========================================================================
    "FEXTNVM": {
        "address": 0x00028,
        "reset_value": 0x00000000,
        "nvm_words": {"low": "word_19h", "high": "word_1Ah"},
        "description": "Future Extended NVM Register - Primary chicken bits",
        "fields": {
            0:  {"name": "tg_phy_pd_frm_dud_d", "description": "PHY power down from DUD"},
            1:  {"name": "reserved", "description": "Reserved"},
            2:  {"name": "reserved", "description": "Reserved"},
            3:  {"name": "reserved", "description": "Reserved"},
            4:  {"name": "clock_gating_dis", "description": "Clock gating disable (OR'd with dtfus_core_coredcg_dis_d)"},
            5:  {"name": "reserved", "description": "Reserved"},
            6:  {"name": "smb_freq_sel_bit0", "description": "SMBus frequency select bit 0 (w/a value)"},
            7:  {"name": "reserved", "description": "Reserved"},
            8:  {"name": "reserved", "description": "Reserved"},
            9:  {"name": "reserved", "description": "Reserved"},
            10: {"name": "reserved", "description": "Reserved"},
            11: {"name": "reserved", "description": "Reserved"},
            12: {"name": "reserved", "description": "Reserved"},
            13: {"name": "lcd_enable_gated", "description": "LCD enable (gated with nv_done, turn_off_lcd, sku checks)"},
            14: {"name": "smb_freq_sel_bit1", "description": "SMBus frequency select bit 1 (w/a straps)"},
            15: {"name": "reserved", "description": "Reserved"},
            16: {"name": "eeprom_apm_en_d", "description": "EEPROM APM enable"},
            # Bits 17-28 reserved
            29: {"name": "force_smb_freq", "description": "Force SMBus frequency selection"},
            # Bits 30-31 reserved
        },
        "signals": {
            "tg_fut_ext_nvm_low_d[15:0]": "Low 16 bits output",
            "tg_fut_ext_nvm_hi_d[15:0]": "High 16 bits output",
        }
    },

    # =========================================================================
    # FEXTNVM2 (0x00030) - Future Extended NVM 2 Register  
    # Note: Listed as 0x00050 in spec but RTL shows 0x00030
    # Reset Value: 0x00804000 (bit14=1, bit23=1)
    # =========================================================================
    "FEXTNVM2": {
        "address": 0x00030,
        "reset_value": 0x00804000,
        "nvm_words": {"low": "word_24h", "high": "word_25h"},
        "description": "Future Extended NVM 2 Register",
        "fields": {
            # Bits 0-9 reserved
            10: {"name": "dis_sai_chk_in_pci2pcim_4sb", "description": "Disable SAI check in PCI2PCIM for SB (needs sb_strap_data[0])"},
            11: {"name": "dis_sai_chk_in_pci2pcim_4pr", "description": "Disable SAI check in PCI2PCIM for PR (needs sb_strap_data[0])"},
            # Bits 12-14 reserved
            15: {"name": "fextnvm2_lo_bit15", "description": "FEXTNVM2 low bit 15 output"},
            # Bit 16 reserved
            17: {"name": "dis_rs_on_chid_chk_in_pci2pcim_4pr", "description": "Disable RS on CHID check in PCI2PCIM for PR (needs sb_strap_data[0])"},
            # Bits 18-31 reserved
        }
    },

    # =========================================================================
    # FEXTNVM3 (0x0003C) - Future Extended NVM 3 Register
    # Reset Value: 0x00000000
    # =========================================================================
    "FEXTNVM3": {
        "address": 0x0003C,
        "reset_value": 0x00000000,
        "nvm_words": {"low": "word_4Bh", "high": "word_4Ch"},
        "description": "Future Extended NVM 3 Register - UCTL and misc chicken bits",
        "fields": {
            "0:7": {"name": "uctl_cb[7:0]", "description": "UCTL chicken bits (8 bits)"},
            8:  {"name": "fut_ext_nvm3_reg_8", "description": "HSD#2374233 chicken bit"},
            9:  {"name": "fut_ext_nvm3_reg_9", "description": "Chicken bit"},
            10: {"name": "fut_ext_nvm3_reg_10", "description": "Sighting 3449038 chicken bit"},
            11: {"name": "fut_ext_nvm3_reg_11", "description": "Sighting 3449039 chicken bit"},
            12: {"name": "fut_ext_nvm3_reg_12", "description": "Chicken bit"},
            # Bits 13-15 reserved
            16: {"name": "fut_ext_nvm3_reg_16", "description": "N4 HSD2945608 Sighting 3449047"},
            "17:18": {"name": "fut_ext_nvm3_reg_18_17[1:0]", "description": "N5 2-bit field"},
            19: {"name": "fut_ext_nvm3_reg_19", "description": "N5 HSD2744447"},
            20: {"name": "fut_ext_nvm3_reg_20", "description": "N5 HSD2744810"},
            21: {"name": "fut_ext_nvm3_reg_21", "description": "N5 HSD2749750"},
            22: {"name": "fut_ext_nvm3_reg_22", "description": "N5 HSD2750671"},
            23: {"name": "fut_ext_nvm3_reg_23", "description": "Chicken bit"},
            24: {"name": "fut_ext_nvm3_reg_24", "description": "N4 HSD2751309"},
            25: {"name": "reserved_sw_wa", "description": "Reserved for SW WA indication (do not use in RTL)"},
            "26:27": {"name": "fut_ext_nvm3_reg_27_26[1:0]", "description": "2-bit field"},
            28: {"name": "fut_ext_nvm3_reg_28", "description": "Chicken bit"},
            29: {"name": "fut_ext_nvm3_reg_29", "description": "Chicken bit"},
            30: {"name": "fut_ext_nvm3_reg_30", "description": "Chicken bit"},
            31: {"name": "fut_ext_nvm3_reg_31", "description": "Chicken bit"},
        }
    },

    # =========================================================================
    # FEXTNVM4 (0x00024) - Future Extended NVM 4 Register
    # Reset Value: 0x00000000
    # =========================================================================
    "FEXTNVM4": {
        "address": 0x00024,
        "reset_value": 0x00000000,
        "nvm_words": {"low": "word_2Ah", "high": "word_2Bh"},
        "description": "Future Extended NVM 4 Register",
        "fields": {
            # All 32 bits available for general use
            "0:31": {"name": "fut_ext_nvm4_reg[31:0]", "description": "General purpose chicken bits"},
        }
    },

    # =========================================================================
    # FEXTNVM5 (0x00014) - Future Extended NVM 5 Register
    # Reset Value: 0x00000080 (bit 7 set)
    # =========================================================================
    "FEXTNVM5": {
        "address": 0x00014,
        "reset_value": 0x00000080,
        "nvm_words": {"low": "word_2Ch", "high": "word_2Dh"},
        "description": "Future Extended NVM 5 Register - Clock gating and PMC handshake",
        "fields": {
            0: {"name": "fut_ext_nvm5_reg_0", "description": "Clock gating control (OR'd with dtfus_core_coredcg_dis_d)"},
            1: {"name": "fut_ext_nvm5_reg_1", "description": "ghost_dev_pci_bbc_clk_enable CB (OR'd with dtfus_core_coredcg_dis_d)"},
            2: {"name": "fut_ext_nvm5_reg_2", "description": "ghost_dev_pci_m_mbb_clk_enable CB (AND'd with ~dtfus_core_coredcg_dis_d)"},
            3: {"name": "fut_ext_nvm5_reg_3", "description": "Chicken bit"},
            "4:7": {"name": "fextnvm5_lanphypc_ctl[3:0]", "description": "LANPHYPC control (4 bits)"},
            # Bits 8-14 reserved
            "15:31": {"name": "fextnvm5_pmc_hndshk_ctl[16:0]", "description": "PMC handshake control (17 bits)"},
        },
        "notes": "Bit 7 (fextnvm5_lanphypc_ctl[3]) controls gbt_gbcn_pmc_lanphypc_timer_en"
    },

    # =========================================================================
    # FEXTNVM6 (0x00010) - Future Extended NVM 6 Register
    # Reset Value: 0x00000000
    # =========================================================================
    "FEXTNVM6": {
        "address": 0x00010,
        "reset_value": 0x00000000,
        "nvm_words": {"low": "word_2Ch", "high": "word_2Dh"},
        "description": "Future Extended NVM 6 Register - K1 and function control",
        "fields": {
            0:  {"name": "fextnvm6_lcd_master_rst_on_flr_en", "description": "LCD master reset on FLR enable"},
            1:  {"name": "fextnvm6_func_clk_sw_strobe_in_pcie_en", "description": "Function clock SW strobe in PCIe enable"},
            2:  {"name": "fextnvm6_m2s_1pcie_0smb_sync_dis", "description": "M2S PCIe/SMB sync disable"},
            3:  {"name": "fextnvm6_gbb_bbu_req_vdm_fix_dis", "description": "GBB BBU request VDM fix disable"},
            "4:5": {"name": "fextnvm6_gbe_pmc_noa_sel[1:0]", "description": "GbE PMC NOA select (2 bits)"},
            6:  {"name": "fextnvm6_trans2d0_rst_pci_cfg_A0ECO2", "description": "HSD404482 SPTLP A0ECO2 - Trans to D0 reset PCI config"},
            7:  {"name": "fextnvm6_dis_d3_lane_rst", "description": "HSD1507627819 - Disable D3 lane reset"},
            8:  {"name": "fextnvm6_cppxp_bbc_ckreq_en", "description": "CPPXP BBC clock request enable"},
            9:  {"name": "fextnvm6_k1_cond_timer_wide_en", "description": "K1 condition timer wide enable"},
            "10:12": {"name": "fextnvm6_func_pcim2pci_cb[2:0]", "description": "Function PCIM2PCI chicken bits (3 bits)"},
            13: {"name": "fextnvm6_pipe_rxpolarity", "description": "PIPE RX polarity"},
            14: {"name": "fextnvm6_func_clk_en_cb", "description": "Function clock enable chicken bit"},
            15: {"name": "fextnvm6_use_4pmc_linkup1_cbldis0", "description": "Use 4PMC linkup1 cbldis0"},
            "16:31": {"name": "fextnvm6_k1_offsnooz_ctrl[15:0]", "description": "K1 off/snooze control (16 bits)"},
        },
        "special": {
            31: {"name": "k1_off_en", "description": "K1 off enable - NOT loaded from NVM, only SW writable, reset on bb_rst"}
        }
    },

    # =========================================================================
    # FEXTNVM7 (0x000E4) - Future Extended NVM 7 Register
    # Reset Value: 0x00000000
    # =========================================================================
    "FEXTNVM7": {
        "address": 0x000E4,
        "reset_value": 0x00000000,
        "nvm_words": {"low": "word_xxh", "high": "word_xxh"},
        "description": "Future Extended NVM 7 Register - SMB/MDIO retry and clock control",
        "fields": {
            0:  {"name": "fextnvm7_tsync_clkreq_en_cb", "description": "Time sync clock request enable CB"},
            1:  {"name": "fextnvm7_mbckreq_dis", "description": "MB clock request disable"},
            2:  {"name": "fextnvm7_side_clk_ungate", "description": "Side clock ungate"},
            3:  {"name": "fextnvm7_unbind_bbclk_req_from_k1", "description": "Unbind BB clock request from K1"},
            4:  {"name": "fextnvm7_force_smb_in_lan_dis", "description": "Force SMB in LAN disable"},
            5:  {"name": "fextnvm7_dont_release_force_smb_on_pltrst", "description": "Don't release force SMB on PLTRST"},
            6:  {"name": "fextnvm7_force_smb_on_lanphypc_lo", "description": "Force SMB on LANPHYPC low"},
            7:  {"name": "fextnvm7_ppw_togl_lanphypc_if_smb_addr_fail", "description": "PPW toggle LANPHYPC if SMB addr fail"},
            8:  {"name": "fextnvm7_sku_togl_lanphypc_if_smb_addr_fail", "description": "SKU toggle LANPHYPC if SMB addr fail"},
            9:  {"name": "fextnvm7_retry_sku_on_smb_addr_fail", "description": "Retry SKU on SMB addr fail (gated by dongle)"},
            10: {"name": "fextnvm7_retry_sku_on_mdio_fail", "description": "Retry SKU on MDIO fail (gated by dongle)"},
            11: {"name": "fextnvm7_retry_sku_on_lcd_pwdn", "description": "Retry SKU on LCD power down (gated by dongle)"},
            12: {"name": "fextnvm7_dont_restart_mdio_on_inf_change", "description": "Don't restart MDIO on interface change"},
            13: {"name": "fextnvm7_dont_set_err_on_restart_mdio", "description": "Don't set error on restart MDIO"},
            "14:15": {"name": "fextnvm7_kum_try_cnt[1:0]", "description": "Kumeran retry count (2 bits) - HSD374380"},
            16: {"name": "fextnvm7_mdio_timeout_on_smb_cb", "description": "MDIO timeout on SMB CB - HSD374380"},
            17: {"name": "fextnvm7_ignore_tm_idle_in_k1_cond", "description": "Ignore TM idle in K1 condition - HSD374635"},
            18: {"name": "fextnvm7_oblcd_en", "description": "Dongle OBLCD enable"},
            19: {"name": "fextnvm7_clk_req_exit_k1_cb", "description": "Dongle clock request exit K1 CB"},
            20: {"name": "fextnvm7_rxelecidle_for_inband_ctrl_cb", "description": "Dongle RX electrical idle for inband control CB"},
            21: {"name": "fextnvm7_kumeran_regs_0_8_rd_dis_cb", "description": "Dongle Kumeran regs 0-8 read disable CB"},
            22: {"name": "fextnvm7_dma_use_mosc_div2_dis", "description": "DMA use MOSC div2 disable - N7"},
            23: {"name": "fextnvm7_sw_iosf_clk2mosc_en", "description": "SW IOSF clock to MOSC enable - N7 (inverted)"},
            24: {"name": "fextnvm7_use_fdone4nvmcyc_int", "description": "Use FDONE for NVM cycle interrupt - N7"},
            25: {"name": "reserved", "description": "Reserved"},
            26: {"name": "fextnvm7_set_extrnl_1us_strb", "description": "Set external 1us strobe - N7"},
            27: {"name": "fextnvm7_set_extrnl_1ms_strb", "description": "Set external 1ms strobe - N7"},
            28: {"name": "fextnvm7_old_mosc_or_pll_switch_cb", "description": "Old MOSC or PLL switch CB"},
            29: {"name": "fextnvm7_dont_wait4_mosc_or_pll_switch_cb", "description": "Don't wait for MOSC or PLL switch CB"},
            30: {"name": "fextnvm7_dont_wait4_pend_wr_req_cb", "description": "Don't wait for pending write request CB - HSD375492"},
            31: {"name": "fextnvm7_dont_wait4_dmaclk_switch_cb", "description": "Don't wait for DMA clock switch CB - HSD375492"},
        }
    },

    # =========================================================================
    # FEXTNVM8 (0x05BB0) - Future Extended NVM 8 Register
    # Reset Value: 0x00403494
    # =========================================================================
    "FEXTNVM8": {
        "address": 0x05BB0,
        "reset_value": 0x00403494,
        "nvm_words": {"low": "word_xxh", "high": "word_xxh"},
        "description": "Future Extended NVM 8 Register - MPHY power gate and OBFF control",
        "fields": {
            0:  {"name": "gbt_gbpgd_nvm_pg_en", "description": "NVM power gate enable"},
            1:  {"name": "fextnvm8_use_legacy_cbldis_ind", "description": "Use legacy CBLDIS indication"},
            "2:6": {"name": "fextnvm8_corepwr_stable_indx[4:0]", "description": "Core power stable index (5 bits)"},
            7:  {"name": "fextnvm8_dont_use_clkreq2exit_mphy_pg", "description": "Don't use CLKREQ to exit MPHY power gate"},
            8:  {"name": "fextnvm8_early_turn_pll_on_en", "description": "Early turn PLL on enable"},
            9:  {"name": "fextnvm8_mpg_on_any_link", "description": "MPHY power gate on any link"},
            10: {"name": "fextnvm8_unbind_dpg_from_mphy_pg_state", "description": "Unbind DPG from MPHY power gate state"},
            11: {"name": "fextnvm8_ignore_iodata_ack", "description": "Ignore IO data ack"},
            12: {"name": "fextnvm8_ignr_srcdst_4_sai_cls", "description": "Ignore src/dst for SAI class - N7"},
            13: {"name": "fextnvm8_ignr_srcdst_4_no_sai_cls", "description": "Ignore src/dst for no SAI class - N7"},
            14: {"name": "fextnvm8_sms_relase_token_every_transac", "description": "SMS release token every transaction"},
            15: {"name": "fextnvm8_sms_cl_clkreq_at_m2s_tx_idelness_cb", "description": "SMS clear CLKREQ at M2S TX idleness CB"},
            16: {"name": "fextnvm8_nvm_override_sleep_en", "description": "NVM override sleep enable"},
            17: {"name": "fextnvm8_m2k_fifo_cntl", "description": "M2K FIFO control"},
            18: {"name": "fextnvm8_mask_pmim_pending_int", "description": "Mask PMIM pending interrupt"},
            19: {"name": "fextnvm8_ppw_tans_done_on_nvdone_dis", "description": "PPW transition done on NV done disable"},
            20: {"name": "fextnvm8_mpg_on_giga", "description": "MPHY power gate on Giga"},
            21: {"name": "fextnvm8_always_request_iosf_prim", "description": "Always request IOSF primary"},
            22: {"name": "fextnvm8_dis_ghost_clk_toggle_on_prim_active", "description": "Disable GHOST clock toggle on primary active"},
            23: {"name": "fextnvm8_dis_ghost_clk_toggle_on_internal_rst", "description": "Disable GHOST clock toggle on internal reset"},
            24: {"name": "fextnvm8_force_corepwr_stable", "description": "Force core power stable"},
            25: {"name": "fextnvm8_disable_func_nv_done_sticky", "description": "Disable function NV done sticky"},
            26: {"name": "fextnvm8_sync_pcim2pci_ind2iosf_pr", "description": "Sync PCIM2PCI indication to IOSF PR - HSD390413"},
            27: {"name": "fextnvm8_sync_pci2pcim_ind2iosf_pr", "description": "Sync PCI2PCIM indication to IOSF PR - HSD390413"},
            28: {"name": "fextnvm8_obff_pure_pending_interrupt", "description": "OBFF pure pending interrupt - HSD390413"},
            29: {"name": "fextnvm8_obff_enable_s_break_int", "description": "OBFF enable S break interrupt - HSD390413"},
            30: {"name": "fextnvm8_obff_break_none_itr", "description": "OBFF break none ITR - HSD390413"},
            31: {"name": "fextnvm8_obff_break_none_itr_rxt0", "description": "OBFF break none ITR RxT0 - HSD390413"},
        }
    },

    # =========================================================================
    # FEXTNVM9 (0x05BB4) - Future Extended NVM 9 Register
    # Reset Value: 0x0404000A
    # =========================================================================
    "FEXTNVM9": {
        "address": 0x05BB4,
        "reset_value": 0x0404000A,
        "nvm_words": {"low": "word_xxh", "high": "word_xxh"},
        "description": "Future Extended NVM 9 Register - Clock gating and system transition",
        "fields": {
            0:  {"name": "fextnvm9_send_lanphypc_after_nvmload", "description": "Send LANPHYPC after NVM load"},
            1:  {"name": "fextnvm9_pmc_ack_timeout_en", "description": "PMC ack timeout enable"},
            2:  {"name": "fextnvm9_ignr_rs_4_sb_msg", "description": "Ignore RS for SB messages"},
            3:  {"name": "fextnvm9_dont_wait2_sp_g2_clkack_cb", "description": "Don't wait for SP G2 clock ack CB"},
            4:  {"name": "fextnvm9_cb_boot_prep_clkreq", "description": "Boot prep clock request CB"},
            5:  {"name": "fextnvm9_ignore_sp_gbe_pin_clkreq_in_sx", "description": "Ignore SP GbE pin CLKREQ in Sx"},
            6:  {"name": "fextnvm9_rosc_clkgate_dis", "description": "ROSC clock gate disable"},
            7:  {"name": "fextnvm9_rosc_clkreq_dis", "description": "ROSC clock request disable"},
            8:  {"name": "fextnvm9_xosc_clkgate_dis", "description": "XOSC clock gate disable"},
            9:  {"name": "fextnvm9_xosc_clkreq_dis", "description": "XOSC clock request disable"},
            10: {"name": "fextnvm9_sp_g2_clkgate_dis", "description": "SP G2 clock gate disable"},
            11: {"name": "fextnvm9_sp_g2_clkreq_dis", "description": "SP G2 clock request disable"},
            12: {"name": "fextnvm9_iosfsb_clkgate_dis", "description": "IOSFSB clock gate disable"},
            13: {"name": "fextnvm9_iosfsb_clkreq_dis", "description": "IOSFSB clock request disable"},
            14: {"name": "fextnvm9_iosfpr_clkgate_dis", "description": "IOSFPR clock gate disable"},
            15: {"name": "fextnvm9_iosfpr_clkreq_dis", "description": "IOSFPR clock request disable"},
            16: {"name": "fextnvm9_ts_keep_monitor_sys_time_pulse", "description": "Keep monitoring system time pulse for time sync"},
            17: {"name": "fextnvm9_set_pg_condition_met_even_policy_dis", "description": "Set PG condition met even policy disable"},
            18: {"name": "fextnvm9_ignore_sp_gbe_pin_clkreq_in_lanphypc_asserted", "description": "Ignore SP GbE pin CLKREQ when LANPHYPC asserted"},
            19: {"name": "fextnvm9_late_nvmgate_mbb_all_dis_cb_d", "description": "Late NVM gate MBB all disable CB"},
            20: {"name": "fextnvm9_unbinde_pipe_sm_from_boundary_locked", "description": "Unbind PIPE FSM from boundary locked"},
            21: {"name": "fextnvm9_ignore_boundary_locked", "description": "Ignore boundary locked in MPHY PG SM"},
            22: {"name": "fextnvm9_mask_system_move2s0_p", "description": "Mask system move to S0 (request PLL only after #pltrst deassert)"},
            23: {"name": "fextnvm9_ack_even_sp_g2_not_rdy_cb", "description": "Ack even SP G2 not ready in Sx transition"},
            24: {"name": "fextnvm9_ack_even_sp_g2_rdy_cb", "description": "Ack even SP G2 ready in S0 transition"},
            25: {"name": "fextnvm9_ignore_iosfpr_ind_on_ack_cb", "description": "Ignore IOSFPR indication on ack in Sx/Moff transition"},
            26: {"name": "fextnvm9_force_k1_due2system_transition_fsm", "description": "Force K1 due to system transition FSM"},
            27: {"name": "fextnvm9_cdcs_force_pwrgate_ready", "description": "CDCS force power gate ready"},
            28: {"name": "fextnvm9_pgcb_clk_force_ungate", "description": "PGCB clock force ungate"},
            29: {"name": "fextnvm9_acc_pgcb_clk_wake_en", "description": "ACC PGCB clock wake enable"},
            30: {"name": "fextnvm9_force_cdc_of_when_sp_g2_still_req", "description": "Force CDC off when SP G2 still requested"},
            31: {"name": "fextnvm9_force_smb_due2_system_transition_fsm_dis", "description": "Force SMB due to system transition FSM disable"},
        }
    },

    # =========================================================================
    # FEXTNVM10 (0x05BB8) - Future Extended NVM 10 Register
    # Reset Value: 0xD80006B0
    # =========================================================================
    "FEXTNVM10": {
        "address": 0x05BB8,
        "reset_value": 0xD80006B0,
        "nvm_words": {"low": "word_xxh", "high": "word_xxh"},
        "description": "Future Extended NVM 10 Register - A0ECO fixes and timeout control",
        "fields": {
            0:  {"name": "fextnvm10_choose_new_wr_rxdv_neg_pulse_A0ECO1", "description": "HSD403369 SPTLP A0ECO1"},
            1:  {"name": "fextnvm10_dont_answer_host_UR_on_rst_entry", "description": "Don't answer host UR on reset entry"},
            2:  {"name": "fextnvm10_dont_answer_csme_UR_on_rst_entry", "description": "Don't answer CSME UR on reset entry"},
            3:  {"name": "fextnvm10_dont_mask_pcim_ind_from_flp", "description": "Don't mask PCIM indication from FLP"},
            4:  {"name": "fextnvm10_rst_boot_prep_ignore_rs", "description": "Reset boot prep ignore RS"},
            5:  {"name": "fextnvm10_pmc_hndshk_ignor_mphy", "description": "PMC handshake ignore MPHY"},
            6:  {"name": "fextnvm10_reset_lcd_on_side_rst_en", "description": "Reset LCD on side reset enable"},
            7:  {"name": "fextnvm10_use_new_clkreq_logic", "description": "Use new CLKREQ logic"},
            8:  {"name": "fextnvm10_rst_boot_prep_send_decoded_rs", "description": "Reset boot prep send decoded RS"},
            9:  {"name": "fextnvm10_dont_stop_pcim2pci_access", "description": "Don't stop PCIM2PCI access"},
            10: {"name": "fextnvm10_car_all_idle_on_lanphypc", "description": "CAR all idle on LANPHYPC"},
            11: {"name": "fextnvm10_int_pin_write_once_dis", "description": "Interrupt pin write once disable"},
            12: {"name": "fextnvm10_dis_credit_fix_on_ur", "description": "Disable credit fix on UR"},
            13: {"name": "fextnvm10_dis_new_cdc_fix", "description": "Disable new CDC fix"},
            14: {"name": "fextnvm10_use_cdc_prim_clkack", "description": "Use CDC primary clock ack"},
            15: {"name": "fextnvm10_sp_gbe_pin_clkreq_invert", "description": "SP GbE pin CLKREQ invert"},
            16: {"name": "fextnvm10_dis_isch_timeout_during_int_out_A0ECO1", "description": "HSD403571 SPTLP A0ECO1 - Disable ISR timeout during INT out"},
            17: {"name": "fextnvm10_dis_ghost_dev_pci_bbc_clk_en_fix", "description": "Disable GHOST dev PCI BBC clock enable fix"},
            18: {"name": "fextnvm10_sb_clkreq_deassert_delay_dis", "description": "SB CLKREQ deassert delay disable"},
            19: {"name": "fextnvm10_en_zero_byte_wr_for_mwr", "description": "Enable zero byte write for MWR"},
            20: {"name": "fextnvm10_tsync_startsync_fix_dis", "description": "Time sync start sync fix disable"},
            21: {"name": "fextnvm10_unclaimed_tar_access_dis_fix_cb", "description": "Unclaimed TAR access disable fix CB"},
            22: {"name": "fextnvm10_sms_cl_clkreq_at_m2s_trans_from_idle_cb", "description": "SMS clear CLKREQ at M2S transition from idle CB"},
            23: {"name": "fextnvm10_allow_sb_host_access_before_nv_done", "description": "Allow SB host access before NV done"},
            24: {"name": "fextnvm10_dont_send_deassert_int_on_dmi_rst", "description": "Don't send deassert interrupt on DMI reset"},
            25: {"name": "fextnvm10_dont_lock_token_fsms", "description": "Don't lock token FSMs"},
            "26:27": {"name": "fextnvm10_no_cmpl_or_token_timeout_val_4_spi[1:0]", "description": "No completion or token timeout value for SPI (2 bits)"},
            28: {"name": "fextnvm10_no_cmpl_or_token_timeout_en_4_spi", "description": "No completion or token timeout enable for SPI"},
            "29:30": {"name": "fextnvm10_no_cmpl_or_token_timeout_val_4_sms[1:0]", "description": "No completion or token timeout value for SMS (2 bits)"},
            31: {"name": "fextnvm10_no_cmpl_or_token_timeout_en_4_sms", "description": "No completion or token timeout enable for SMS"},
        }
    },

    # =========================================================================
    # FEXTNVM11 (0x05BBC) - Future Extended NVM 11 Register
    # Reset Value: 0x00212000
    # =========================================================================
    "FEXTNVM11": {
        "address": 0x05BBC,
        "reset_value": 0x00212000,
        "nvm_words": {"low": "word_xxh", "high": "word_xxh"},
        "description": "Future Extended NVM 11 Register - Power and PB read control",
        "fields": {
            0:  {"name": "fextnvm11_LANPHYPC_on_force_power_gate_POK", "description": "Toggle LANPHYPC on ForcePowerGatePOK message"},
            1:  {"name": "fextnvm11_dis_sms_clkreq_on_tx_fix_A0ECO1", "description": "A0ECO1 - Disable SMS CLKREQ on TX fix"},
            2:  {"name": "fextnvm11_dis_direct_fw_clkack_in_cdc", "description": "Disable direct FW clock ack in CDC"},
            3:  {"name": "fextnvm11_dont_wait2force_POK", "description": "Don't wait to force POK"},
            4:  {"name": "fextnvm11_rx_burst_cnt_non_write_pkt", "description": "RX burst count non-write packet"},
            5:  {"name": "fextnvm11_prim_clkreq_min_deassertion_fix_A0ECO1", "description": "A0ECO1 - Primary CLKREQ minimum deassertion fix"},
            6:  {"name": "fextnvm11_dis_fix_for_min_assertion", "description": "Disable fix for minimum assertion"},
            7:  {"name": "fextnvm11_select_old_prim_clkreq", "description": "Select old primary CLKREQ"},
            8:  {"name": "fextnvm11_always_restore_apm_from_pmc", "description": "Always restore APM from PMC"},
            9:  {"name": "fextnvm11_sw_disable_pb_read", "description": "SW disable PB read"},
            10: {"name": "fextnvm11_disable_pb_read_on_master_disable_done", "description": "Disable PB read on master disable done"},
            11: {"name": "fextnvm11_disable_pb_read_on_non_doa", "description": "Disable PB read on non-D0A"},
            12: {"name": "fextnvm11_dont_write_on_read_disable", "description": "Don't write on read disable"},
            13: {"name": "fextnvm11_disable_ghost_bp_from_iosf", "description": "Disable GHOST backpressure from IOSF"},
            14: {"name": "reserved", "description": "Reserved"},
            15: {"name": "reserved", "description": "Reserved"},
            "16:19": {"name": "fextnvm11_iosf2pci_fifo_low_th[3:0]", "description": "IOSF2PCI FIFO low threshold (4 bits)"},
            "20:23": {"name": "fextnvm11_iosf2pci_fifo_high_th[3:0]", "description": "IOSF2PCI FIFO high threshold (4 bits)"},
            24: {"name": "fextnvm11_pcim2pci_to_fleep_fix_en", "description": "SPT B0 - PCIM2PCI to FLEEP fix enable"},
            25: {"name": "fextnvm11_io_over_cfg_to_fleep_fix_en", "description": "SPT B0 - IO over config to FLEEP fix enable"},
            26: {"name": "fextnvm11_hh_fix_dis", "description": "CNL - HH bug fix disable in generic client"},
            27: {"name": "fextnvm11_use_legacy_ts_pulse_samp", "description": "CNL - Use legacy TS pulse sampling"},
            28: {"name": "fextnvm11_prep_ack_rs_zero_dis", "description": "CNL - Prep ack RS zero disable"},
            29: {"name": "fextnvm11_disable_pci2iosf_bp_from_iosf2pci", "description": "CNL - Disable PCI2IOSF backpressure from IOSF2PCI"},
            30: {"name": "reserved", "description": "Reserved"},
            31: {"name": "reserved", "description": "Reserved"},
        }
    },

    # =========================================================================
    # FEXTNVM12 (0x05BC0) - Future Extended NVM 12 Register
    # Reset Value: 0x0000003F
    # =========================================================================
    "FEXTNVM12": {
        "address": 0x05BC0,
        "reset_value": 0x0000003F,
        "nvm_words": {"low": "word_xxh", "high": "word_xxh"},
        "description": "Future Extended NVM 12 Register - D3 exit and PME control",
        "fields": {
            0:  {"name": "fextnvm12_shard_start_nvm_on_d3_exit", "description": "CNL - Shared start NVM on D3 exit"},
            1:  {"name": "fextnvm12_pci_start_nvm_on_d3_exit", "description": "CNL - PCI start NVM on D3 exit"},
            2:  {"name": "fextnvm12_pmi_acpi_config_to_car", "description": "PMI ACPI config to CAR"},
            3:  {"name": "fextnvm12_lcd_reset_on_d3_exit", "description": "CNL - LCD reset on D3 exit"},
            4:  {"name": "fextnvm12_master_reset_on_d3_exit", "description": "Master reset on D3 exit"},
            5:  {"name": "fextnvm12_lcd_ppw_reset_on_d3_exit", "description": "LCD PPW reset on D3 exit"},
            6:  {"name": "fextnvm12b1_wrng_rs_on_unclm_msg_fix_dis", "description": "CNL - Wrong RS on unclaimed message fix disable"},
            7:  {"name": "fextnvm12_use_old_sb_agnet_clkreq", "description": "CNL - Use old SB agent CLKREQ"},
            8:  {"name": "fextnvm12_disable_pme_fix", "description": "Disable PME fix"},
            9:  {"name": "fextnvm12_disable_io_over_config", "description": "CNL - Disable IO over config access"},
            10: {"name": "fextnvm12_ur_cmpl_fix_dis", "description": "CNL - UR completion fix disable (hardwired to 0)"},
            11: {"name": "fextnvm12_dont_gate_pcim2pci_in_src", "description": "Don't gate PCIM2PCI in SRC"},
            12: {"name": "fextnvm12_dont_wake_from_dpg_with_clkreq", "description": "RB - Don't wake from DPG with CLKREQ"},
            13: {"name": "fextnvm12_lock_write_to_flash", "description": "RB - Lock write to flash (write-once, reset on bb_rst)"},
            14: {"name": "fextnvm12_dont_deassert_rosc_slow_clkreq", "description": "RB - Don't deassert ROSC slow CLKREQ"},
            15: {"name": "fextnvm12_dont_deassert_vnn_request", "description": "RB - Don't deassert VNN request"},
            16: {"name": "fextnvm12_dont_block_master_msg", "description": "RB - Don't block master message"},
            17: {"name": "fextnvm12_rosc_fast_clkreq_dis", "description": "RB - ROSC fast CLKREQ disable"},
            18: {"name": "fextnvm12_sel_128bytes_max_read_payload_cb", "description": "MTL - Select 128 bytes max read payload CB"},
            19: {"name": "fextnvm12_disable_pme_wake_fix_h", "description": "PME wake bug fix disable for host (inverted)"},
            20: {"name": "fextnvm12_disable_pme_wake_fix_me", "description": "PME wake bug fix disable for ME (inverted)"},
            21: {"name": "fextnvm12_primclk_req_dep_k1_state_cb", "description": "MTL - Primary clock request dependent K1 state CB (RX ping loss)"},
            "22:23": {"name": "fextnvm12_snps_phy_pwrdn_cfg_ctrl[1:0]", "description": "MTL SNPS PHY power down config control (2 bits)"},
            24: {"name": "fextnvm12_swrst_fix_disable", "description": "SW reset fix disable"},
            "25:26": {"name": "fextnvm12_swrst_fix_cfg[1:0]", "description": "SW reset fix config (2 bits)"},
            27: {"name": "fextnvm12_sb_comp_wid_low_addr", "description": "SB completion WID low address"},
            28: {"name": "fextnvm12_comp_wid_lbe", "description": "Completion WID LBE"},
            29: {"name": "fextnvm12_byp_host_d3", "description": "HSD-16011293524 - Bypass host D3"},
            30: {"name": "fextnvm12_byp_me_d3", "description": "HSD-16011293524 - Bypass ME D3"},
            31: {"name": "fextnvm12_ena_lane_rst_in_smbus", "description": "HSD-16011293524 - Enable lane reset in SMBus"},
        }
    },

    # =========================================================================
    # FEXTNVM13 (0x05BC4) - Future Extended NVM 13 Register
    # Reset Value: 0x00000000
    # =========================================================================
    "FEXTNVM13": {
        "address": 0x05BC4,
        "reset_value": 0x00000000,
        "nvm_words": {"low": "word_xxh", "high": "word_xxh"},
        "description": "Future Extended NVM 13 Register - PIPE glue and K1 entry control",
        "fields": {
            "0:5": {"name": "fextnvm13_pipe_glue_cbs[5:0]", "description": "PIPE glue chicken bits (6 bits) - MTL"},
            6:  {"name": "fextnvm13_dont_wait_to_psd_pg_in_move2sx", "description": "MTL - Don't wait for PSD power gate in move to Sx"},
            7:  {"name": "fextnvm13_disable_sw_rst_in_progress", "description": "Disable SW reset in progress"},
            8:  {"name": "fextnvm13_disable_sb_sw_rst_indication", "description": "Disable SB SW reset indication"},
            9:  {"name": "fextnvm13_disable_squelch_flag_fix", "description": "Disable squelch flag fix"},
            # Bits 10-23 reserved
            "24:31": {"name": "fextnvm13_k1_entry_count_value[7:0]", "description": "K1 entry count value (8 bits)"},
        }
    },
}

# =========================================================================
# Helper functions for register access
# =========================================================================

def get_register_by_address(address: int) -> dict:
    """Get register definition by address"""
    for name, reg in FEXTNVM_REGISTERS.items():
        if reg["address"] == address:
            return {name: reg}
    return None

def get_field_bit(register_name: str, field_name: str) -> int:
    """Get the bit position of a field in a register"""
    if register_name not in FEXTNVM_REGISTERS:
        return None
    reg = FEXTNVM_REGISTERS[register_name]
    for bit, field in reg.get("fields", {}).items():
        if isinstance(bit, int) and field.get("name") == field_name:
            return bit
    return None

def print_register_summary(register_name: str):
    """Print a summary of a register's fields"""
    if register_name not in FEXTNVM_REGISTERS:
        print(f"Register {register_name} not found")
        return
    
    reg = FEXTNVM_REGISTERS[register_name]
    print(f"\n{'='*70}")
    print(f"{register_name} (0x{reg['address']:05X})")
    print(f"Reset Value: 0x{reg['reset_value']:08X}")
    print(f"Description: {reg['description']}")
    print(f"{'='*70}")
    
    for bit, field in sorted(reg.get("fields", {}).items(), 
                             key=lambda x: int(str(x[0]).split(':')[0]) if isinstance(x[0], (int, str)) else 0):
        print(f"  Bit {bit:>5}: {field['name']:<50} - {field['description']}")

def get_all_clock_gating_fields() -> list:
    """Get all fields related to clock gating"""
    clock_fields = []
    for reg_name, reg in FEXTNVM_REGISTERS.items():
        for bit, field in reg.get("fields", {}).items():
            name = field.get("name", "")
            if "clkgate" in name.lower() or "clk_gate" in name.lower():
                clock_fields.append({
                    "register": reg_name,
                    "address": reg["address"],
                    "bit": bit,
                    "name": name,
                    "description": field.get("description", "")
                })
    return clock_fields

def get_all_k1_fields() -> list:
    """Get all fields related to K1 power state"""
    k1_fields = []
    for reg_name, reg in FEXTNVM_REGISTERS.items():
        for bit, field in reg.get("fields", {}).items():
            name = field.get("name", "")
            if "k1" in name.lower():
                k1_fields.append({
                    "register": reg_name,
                    "address": reg["address"],
                    "bit": bit,
                    "name": name,
                    "description": field.get("description", "")
                })
    return k1_fields


if __name__ == "__main__":
    print("FEXTNVM Register Field Definitions")
    print("Extracted from gbe_t_gen_regs.v RTL")
    print("="*70)
    
    # Print all registers
    for reg_name in FEXTNVM_REGISTERS:
        print_register_summary(reg_name)
    
    # Print clock gating related fields
    print("\n" + "="*70)
    print("CLOCK GATING RELATED FIELDS:")
    print("="*70)
    for field in get_all_clock_gating_fields():
        print(f"  {field['register']}[{field['bit']}]: {field['name']}")
    
    # Print K1 related fields  
    print("\n" + "="*70)
    print("K1 POWER STATE RELATED FIELDS:")
    print("="*70)
    for field in get_all_k1_fields():
        print(f"  {field['register']}[{field['bit']}]: {field['name']}")
