@echo off
REM Launcher for the GbE NVM Comparator - double-click to start.
setlocal
cd /d "%~dp0"

where py >nul 2>&1 && (py -3 nvm_compare_gui.py %* & goto :done)
where python >nul 2>&1 && (python nvm_compare_gui.py %* & goto :done)

echo.
echo Python 3 was not found on this PC.
echo Install it from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^)
echo or from the Microsoft Store, then run this file again.
echo.
pause

:done
endlocal
