GbE NVM Comparator - portable edition
=====================================

Compares a candidate GbE NVM image against the last official release and reports
every differing BIT, with field names, checksum validation, and a
functional-vs-bookkeeping split.

Requires Python 3.9+ only. No pip install, no network, no repo checkout.


QUICK START
-----------
Double-click  "Compare NVM.bat"

Then:
  1. Baseline (official) -> pick the last official release
  2. Candidate (new)     -> pick the image under review
     (or press "Find latest official..." to locate a baseline automatically)
  3. Press Compare
  4. Export with "Save HTML report", "Save Markdown", or "Copy summary"

Accepts release .zip, an extracted folder, a raw .bin, or the release .txt
hex-word dump. Release zips are matched SKU-for-SKU (Cons vs Cons,
Corp vs Corp) automatically.


COMMAND LINE
------------
  python nvm_compare.py compare new.zip official.zip
  python nvm_compare.py compare new.zip official.zip --format html -o report.html
  python nvm_compare.py check candidate.bin          # checksum + version
  python nvm_compare.py show release.zip 0x58        # decode one word, bit by bit
  python nvm_compare.py baselines --search .         # list releases found on disk

Exit code 0 = both images checksum correctly and sizes match; 1 = otherwise.
Usable as a pre-flash / CI gate.


HOW TO READ THE RESULT
----------------------
FUNCTIONAL changes are the real configuration bits - this is what you review.

BOOKKEEPING changes are word 0x05 (image version), 0x06/0x07 (EETRACK ID) and
0x3F (SW checksum). These change on every rebuild and mean nothing on their own.

The HTML report also includes a "SKU delta within candidate" section comparing
Cons against Corp, which catches bits that were changed on only one SKU.

A healthy release shows a small number of functional bits that map 1:1 to the
release changelog. Anything unexplained is a finding.


PLATFORM SCOPE
--------------
Works on the Nahum / I219 NVM region (8 KB, 16-bit words, 0xBABA checksum at
word 0x3F). Verified on NVL-PCH-S, NVL-PCD-H, PTL-PCD-P/H, WCL-PCD-N, LNL-M,
MTL-M/P, MTL-S, ARL-SOC-M and ADP-S.

Field names are taken from the NVL-S map (Nahum13 nvl_pch_s). On other platforms
the diff is still bit-exact, but bit MEANINGS can drift between generations - the
tool prints a warning in every report when the images are not NVL-S. Confirm
names against that platform's own map before acting on them.

NOT supported: Foxville (I225/I226). That device uses a section-based NVM with
separate checksums per Common / LAN 1 / LAN 2 / LAN 3 section.


FILES
-----
  Compare NVM.bat                  double-click launcher (Windows)
  nvm_compare_gui.py               the GUI
  nvm_compare.py                   comparison engine + CLI
  nvm_map_cache.json               NVM word/bit map (from the NVL-S workbook)
  fextnvm_register_definitions.py  FEXTNVM per-bit names (extracted from RTL)
  README.txt                       this file

All five files must stay in the same folder.


REFRESHING THE MAP
------------------
nvm_map_cache.json is a snapshot of the NVL-S NVM map workbook. If the workbook
is updated, regenerate it from a repo checkout with:

    python nvm_compare.py compare <a> <b> --refresh-map

then copy the new .gbe-nvm/maps/Nahum13_nvl_pch_s/nvm_map_cache.json into this
folder.
