"""Standalone GUI for comparing two GbE NVM images.

Pick a baseline (last official release) and a candidate, press Compare, and get a
full bit-level review: verdict, checksum status, functional changes, bookkeeping,
and the Cons/Corp delta. Reports export to HTML or Markdown.

    python gbe-sv-debug/sut_toolkit/nvm_compare_gui.py

Accepts release .zip, extracted folders, raw .bin, or the release .txt hex dump.
Runs off-repo as long as nvm_compare.py and nvm_map_cache.json sit beside it.
"""

from __future__ import annotations

import sys
import threading
import traceback
import webbrowser
from pathlib import Path
from tkinter import BOTH, END, LEFT, RIGHT, TOP, X, Y, StringVar, Tk, filedialog, messagebox
from tkinter import ttk, scrolledtext

sys.path.insert(0, str(Path(__file__).resolve().parent))

from nvm_compare import (  # noqa: E402
    Comparison,
    FieldResolver,
    compare_releases,
    latest_baseline,
    load_release,
    render_html,
    render_markdown,
    render_text,
)

FILETYPES = [
    ("NVM release or image", "*.zip *.bin *.txt"),
    ("Release package", "*.zip"),
    ("Raw image", "*.bin"),
    ("Hex word dump", "*.txt"),
    ("All files", "*.*"),
]


class NvmCompareApp:
    def __init__(self, root: Tk):
        self.root = root
        root.title("GbE NVM Comparator")
        root.geometry("1180x760")
        root.minsize(900, 560)

        self.baseline = StringVar()
        self.candidate = StringVar()
        self.status = StringVar(value="Select a baseline and a candidate image.")
        self.comparisons: dict[str, Comparison] = {}
        self._resolver: FieldResolver | None = None

        self._build_inputs()
        self._build_results()
        self._build_statusbar()

    # ----------------------------------------------------------------- layout --

    def _build_inputs(self) -> None:
        frame = ttk.LabelFrame(self.root, text="Images", padding=10)
        frame.pack(side=TOP, fill=X, padx=10, pady=(10, 6))
        frame.columnconfigure(1, weight=1)

        self._file_row(frame, 0, "Baseline (official)", self.baseline, self._pick_baseline)
        self._file_row(frame, 1, "Candidate (new)", self.candidate, self._pick_candidate)

        actions = ttk.Frame(frame)
        actions.grid(row=2, column=0, columnspan=4, sticky="w", pady=(10, 0))
        ttk.Button(actions, text="Compare", command=self.run_compare).pack(side=LEFT)
        ttk.Button(actions, text="Find latest official\u2026",
                   command=self.autodetect_baseline).pack(side=LEFT, padx=6)
        ttk.Separator(actions, orient="vertical").pack(side=LEFT, fill=Y, padx=10)
        self.btn_html = ttk.Button(actions, text="Save HTML report\u2026",
                                   command=self.save_html, state="disabled")
        self.btn_html.pack(side=LEFT)
        self.btn_md = ttk.Button(actions, text="Save Markdown\u2026",
                                 command=self.save_markdown, state="disabled")
        self.btn_md.pack(side=LEFT, padx=6)
        self.btn_copy = ttk.Button(actions, text="Copy summary",
                                   command=self.copy_summary, state="disabled")
        self.btn_copy.pack(side=LEFT)

    def _file_row(self, parent, row: int, label: str, var: StringVar, browse) -> None:
        ttk.Label(parent, text=label, width=20).grid(row=row, column=0, sticky="w", pady=3)
        ttk.Entry(parent, textvariable=var).grid(row=row, column=1, sticky="ew", padx=6)
        ttk.Button(parent, text="File\u2026", width=8,
                   command=lambda: browse(False)).grid(row=row, column=2)
        ttk.Button(parent, text="Folder\u2026", width=9,
                   command=lambda: browse(True)).grid(row=row, column=3, padx=(4, 0))

    def _build_results(self) -> None:
        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(side=TOP, fill=BOTH, expand=True, padx=10, pady=6)
        self._placeholder = ttk.Frame(self.tabs)
        ttk.Label(self._placeholder, padding=40,
                  text="No comparison yet.\n\nChoose two images and press Compare.",
                  justify="center").pack(expand=True)
        self.tabs.add(self._placeholder, text="Results")

    def _build_statusbar(self) -> None:
        bar = ttk.Frame(self.root)
        bar.pack(side=TOP, fill=X, padx=10, pady=(0, 8))
        ttk.Label(bar, textvariable=self.status, anchor="w").pack(side=LEFT, fill=X, expand=True)

    # ---------------------------------------------------------------- actions --

    def _pick(self, var: StringVar, want_dir: bool, title: str) -> None:
        path = (filedialog.askdirectory(title=title) if want_dir
                else filedialog.askopenfilename(title=title, filetypes=FILETYPES))
        if path:
            var.set(path)

    def _pick_baseline(self, want_dir: bool) -> None:
        self._pick(self.baseline, want_dir, "Select baseline NVM release")

    def _pick_candidate(self, want_dir: bool) -> None:
        self._pick(self.candidate, want_dir, "Select candidate NVM release")

    def autodetect_baseline(self) -> None:
        start = Path(self.candidate.get()).parent if self.candidate.get() else Path.home() / "Downloads"
        found = latest_baseline([start, Path.home() / "Downloads"])
        if found and str(found) != self.candidate.get():
            self.baseline.set(str(found))
            self.status.set(f"Baseline auto-selected: {found.name}")
        else:
            messagebox.showinfo("No baseline found",
                                "No release package was found next to the candidate or in "
                                "Downloads. Pick one manually.")

    def run_compare(self) -> None:
        base, cand = self.baseline.get().strip(), self.candidate.get().strip()
        if not base or not cand:
            messagebox.showwarning("Missing input", "Select both a baseline and a candidate.")
            return

        self.status.set("Comparing\u2026")
        self.root.update_idletasks()
        threading.Thread(target=self._compare_worker, args=(base, cand), daemon=True).start()

    def _compare_worker(self, base: str, cand: str) -> None:
        try:
            self._resolver = self._resolver or FieldResolver.load()
            result = compare_releases(cand, base, self._resolver)
            self.root.after(0, self._show_results, result)
        except Exception as exc:  # surfaced to the user, not swallowed
            detail = traceback.format_exc(limit=3)
            self.root.after(0, self._show_error, exc, detail)

    def _show_error(self, exc: Exception, detail: str) -> None:
        self.status.set(f"Failed: {exc}")
        messagebox.showerror("Comparison failed", f"{exc}\n\n{detail}")

    # ---------------------------------------------------------------- results --

    def _show_results(self, comparisons: dict[str, Comparison]) -> None:
        self.comparisons = comparisons
        for tab in self.tabs.tabs():
            self.tabs.forget(tab)

        for sku, cmp in comparisons.items():
            self.tabs.add(self._build_tab(cmp), text=f"{sku or 'image'}  ({cmp.functional_bits})")
        self.tabs.add(self._build_text_tab(), text="Full text diff")

        for btn in (self.btn_html, self.btn_md, self.btn_copy):
            btn.config(state="normal")

        worst = [c.verdict() for c in comparisons.values() if not c.verdict().startswith(("OK", "IDENT"))]
        total = sum(c.functional_bits for c in comparisons.values())
        self.status.set(worst[0] if worst
                        else f"Done \u2014 {total} functional bit(s) changed across "
                             f"{len(comparisons)} SKU(s).")

    def _build_tab(self, cmp: Comparison) -> ttk.Frame:
        tab = ttk.Frame(self.tabs, padding=8)

        head = ttk.Frame(tab)
        head.pack(fill=X)
        ok = cmp.verdict().startswith(("OK", "IDENTICAL"))
        ttk.Label(head, text=cmp.verdict(), font=("Segoe UI", 11, "bold"),
                  foreground="#0a7d28" if ok else "#b3261e").pack(anchor="w")

        meta = (f"baseline {cmp.old.name}  (v{cmp.old.image_version}, "
                f"xsum 0x{cmp.old.checksum:04X} {'OK' if cmp.old.checksum_ok else 'INVALID'})\n"
                f"candidate {cmp.new.name}  (v{cmp.new.image_version}, "
                f"xsum 0x{cmp.new.checksum:04X} {'OK' if cmp.new.checksum_ok else 'INVALID'})\n"
                f"{cmp.bits_scanned:,} bits compared \u00b7 {cmp.changed_bits} changed \u00b7 "
                f"{cmp.functional_bits} functional")
        ttk.Label(head, text=meta, foreground="#555", justify="left").pack(anchor="w", pady=(2, 8))

        ttk.Label(tab, text="Functional changes", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self._table(tab, cmp.functional, height=11)

        ttk.Label(tab, text="Bookkeeping (version / EETRACK / checksum)",
                  font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 0))
        self._table(tab, cmp.bookkeeping, height=6)
        return tab

    def _table(self, parent, word_changes, height: int) -> None:
        cols = ("word", "value", "bit", "change", "field", "description")
        widths = (72, 130, 40, 74, 250, 460)
        wrap = ttk.Frame(parent)
        wrap.pack(fill=BOTH, expand=True, pady=(2, 0))

        tree = ttk.Treeview(wrap, columns=cols, show="headings", height=height)
        for col, width in zip(cols, widths):
            tree.heading(col, text=col.capitalize())
            tree.column(col, width=width, anchor="w", stretch=(col == "description"))

        tree.tag_configure("set", foreground="#0a7d28")
        tree.tag_configure("clr", foreground="#b3261e")

        if not word_changes:
            tree.insert("", END, values=("", "", "", "", "(none)", ""))
        for wc in word_changes:
            for bc in wc.bits:
                tree.insert("", END, tags=("set" if bc.new else "clr",), values=(
                    f"0x{wc.word:04X}",
                    f"0x{wc.old:04X} \u2192 0x{wc.new:04X}",
                    bc.bit,
                    f"{bc.old}\u2192{bc.new} {bc.action}",
                    bc.field.name or "(unnamed)",
                    bc.field.description,
                ))

        vsb = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side=LEFT, fill=BOTH, expand=True)
        vsb.pack(side=RIGHT, fill=Y)

    def _build_text_tab(self) -> ttk.Frame:
        tab = ttk.Frame(self.tabs, padding=8)
        box = scrolledtext.ScrolledText(tab, wrap="none", font=("Consolas", 10))
        box.pack(fill=BOTH, expand=True)
        box.insert(END, self._text_report())
        box.configure(state="disabled")
        return tab

    def _text_report(self) -> str:
        return "\n\n".join(
            f"{'=' * 78}\n  SKU: {sku or 'image'}\n{'=' * 78}\n" + render_text(cmp)
            for sku, cmp in self.comparisons.items()
        )

    # ----------------------------------------------------------------- export --

    def _title(self) -> str:
        return f"{Path(self.candidate.get()).name} vs {Path(self.baseline.get()).name}"

    def save_html(self) -> None:
        path = filedialog.asksaveasfilename(
            title="Save HTML report", defaultextension=".html",
            initialfile="nvm_comparison.html", filetypes=[("HTML report", "*.html")])
        if not path:
            return
        Path(path).write_text(render_html(self.comparisons, title=self._title()), encoding="utf-8")
        self.status.set(f"Saved {path}")
        if messagebox.askyesno("Report saved", "Open the report in your browser?"):
            webbrowser.open(Path(path).resolve().as_uri())

    def save_markdown(self) -> None:
        path = filedialog.asksaveasfilename(
            title="Save Markdown", defaultextension=".md",
            initialfile="nvm_comparison.md", filetypes=[("Markdown", "*.md")])
        if not path:
            return
        body = "\n\n".join(render_markdown(c) for c in self.comparisons.values())
        Path(path).write_text(f"# {self._title()}\n\n{body}\n", encoding="utf-8")
        self.status.set(f"Saved {path}")

    def copy_summary(self) -> None:
        body = "\n\n".join(render_markdown(c) for c in self.comparisons.values())
        self.root.clipboard_clear()
        self.root.clipboard_append(body)
        self.status.set("Markdown summary copied to clipboard \u2014 paste into the HSD.")


def _selftest(baseline: str, candidate: str) -> int:
    """Headless check that the UI builds and a comparison renders."""
    root = Tk()
    root.withdraw()
    app = NvmCompareApp(root)
    app.baseline.set(baseline)
    app.candidate.set(candidate)
    app._resolver = FieldResolver.load()
    app._show_results(compare_releases(candidate, baseline, app._resolver))
    print(f"selftest OK: {len(app.comparisons)} SKU(s), tabs={len(app.tabs.tabs())}")
    print(f"html={len(render_html(app.comparisons))} chars, text={len(app._text_report())} chars")
    root.destroy()
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if argv and argv[0] == "--selftest":
        return _selftest(argv[1], argv[2])

    root = Tk()
    try:
        ttk.Style().theme_use("vista")
    except Exception:
        pass
    app = NvmCompareApp(root)
    if len(argv) >= 1:
        app.candidate.set(argv[0])
    if len(argv) >= 2:
        app.baseline.set(argv[1])
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
