import csv, os

f = r'c:\Users\michaele\OneDrive - Intel Corporation\Documents\Regression_files\09_ISSUE_ANALYSIS\_tmp_16029551069\DriverAndSMBUS_100GbpsFullDuplex_Pass_unzipped\DriverAndSMBUS_100GbpsFullDuplex_Pass\SMBUS_100MbpsFullDuplex_LinkSpeed_Pass.csv'
if not os.path.exists(f):
    print("File not found")
    exit(1)

with open(f, 'r') as fh:
    rows = list(csv.reader(fh))[8:]

page = 0
all_pages = set()
regs_per_page = {}
for row in rows:
    if len(row) < 10: continue
    data = row[9].strip()
    if not data: continue
    parts = data.split()
    if len(parts) < 7: continue
    try:
        cmd = int(parts[0], 16)
        msg_type = int(parts[2], 16)
    except ValueError: continue
    if cmd not in (0xC3, 0xD3): continue
    if msg_type in (1, 2):
        b5 = int(parts[5], 16)
        b3 = int(parts[3], 16)
        b4 = int(parts[4], 16)
        reg = b5 & 0x1F
        dv = (b3 << 8) | b4
        direction = 'C3' if cmd == 0xC3 else 'D3'
        if reg == 31:
            page = dv & 0x7FF
            all_pages.add(page)
        else:
            key = (page, reg, direction)
            if key not in regs_per_page:
                regs_per_page[key] = {'count': 0, 'vals': set()}
            regs_per_page[key]['count'] += 1
            regs_per_page[key]['vals'].add(dv)

print('Pages accessed:', sorted(all_pages))
print()
for (pg, reg, d), info in sorted(regs_per_page.items()):
    vals = sorted(info['vals'])[:5]
    vals_str = ', '.join(f'0x{v:04X}' for v in vals)
    cnt = info['count']
    print(f'  Page {pg:>4} Reg 0x{reg:02X} ({reg:>2}) [{d}]: {cnt:>4} times | {vals_str}')
