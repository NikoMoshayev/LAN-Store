# Merino S4 SMBus Context

## Purpose

This note captures the context gathered for the Merino S4 power-button LED flicker investigation so it can travel with `SMBUS_PARSER_PORTABLE`.

## Issue Context

- Platform: HP Merino / PTL-U / I219-LM
- Symptom: Power button LED flickers while system enters S4
- Scope screenshot channels:
  - C1 = SMBus DATA
  - C2 = SMBus CLK

## Saleae Capture

- Capture file: `C:\Users\michaele\Downloads\Merino S4 0603\Merino S4 0603.sal`
- Capture type: Saleae `.sal` archive
- File size: about 551 MB
- Approximate duration: 40.53 s
- Analog sample rate: 12.5 MHz
- Digital sample rate: 50 MHz
- Digital threshold: 1.2 V
- Capture mode: FreeRun
- Configured trigger: PE_RST on digital channel 4
- `digitalTriggerTime = -1`, so no actual trigger timestamp is recorded
- Saleae UI view was positioned around 18.731764 s

## Stored Channels

Actual stored streams in the `.sal` file:

| Channel | Name | Stored Type |
|---|---|---|
| 0 | Lan_Disable_PCH | Analog |
| 1 | Lan_Disable | Analog |
| 2 | VDD0V9 | Analog |
| 3 | Lan 3V3 | Digital |
| 4 | PE_RST | Digital |
| 5 | Lan_Wake | Digital |
| 6 | SMBus_Data | Analog + Digital |
| 7 | SMBus_CLK | Analog + Digital |

Visible in the Saleae UI but not stored as analog in the archive:

- Lan 3V3 analog
- PE_RST analog
- Lan_Wake analog
- Lan wake channel 15

Note: There are similarly named wake rows: `Lan_Wake` ch5 and `Lan wake` ch15. The stored wake signal is ch5.

## Capture Quality Observations

1. PE_RST trigger was configured, but the capture is effectively free-run:
   - `captureMode = FreeRun`
   - `digitalTriggerTime = -1`

2. LAN power/reset/wake digital streams are tiny compared with SMBus streams:
   - `digital-3.bin` Lan 3V3: 113 bytes
   - `digital-4.bin` PE_RST: 113 bytes
   - `digital-5.bin` Lan_Wake: 116 bytes
   - `digital-6.bin` SMBus_Data: 41,457 bytes
   - `digital-7.bin` SMBus_CLK: 78,220 bytes

Interpretation: the capture shows much more SMBus activity than LAN reset/power/wake digital activity. It does not look like a large LAN reset or power toggle is directly causing the LED flicker.

## SMBus Analog Findings

SMBus analog streams:

- DATA: channel 6, `analog-6.bin`
- CLK: channel 7, `analog-7.bin`

The analog DATA/CLK levels look electrically clean:

- DATA mid-level region: about 0.031%
- CLK mid-level region: about 0.052%
- DATA high raw cluster: about 636 counts
- CLK high raw cluster: about 647 counts
- DATA low raw cluster: about -11 counts
- CLK low raw cluster: about 4 counts

No obvious analog signal-integrity issue was seen, such as persistent half-level behavior or heavy noise.

## Main Unexpected SMBus Behavior

Both SMBus DATA and CLK appear held low together near the end of the capture:

- Both-low interval: about 29.600 s to 40.520 s
- Duration: about 10.920 s

Before this interval, both lines are mostly idle-high until about 29.58 s.

Expected SMBus idle state is DATA high and CLK high. If the SMBus domain is expected to remain active during this window, both lines low for about 11 s is unexpected.

Possible interpretations:

- SMBus pull-up rail is removed during S4 entry
- SMBus domain is powered down
- EC/PMC/ME/platform logic is holding or clamping the bus low
- Measurement reference or power domain changes during S4 entry

Additional suspicious point:

- DATA and CLK are in the same digital state about 99.893% of paired samples

DATA should not simply mirror CLK during normal SMBus transactions, so this supports the idea that the capture is dominated by power-domain or pull-up behavior rather than normal SMBus traffic.

## Current Interpretation

The capture does not include the power button LED control line. Based on available channels, the evidence points more toward S4 power sequencing, EC/platform firmware, or SMBus pull-up-domain behavior than toward the LAN driver directly toggling the LED.

Strong summary statement:

> SMBus DATA and CLK look electrically clean while active, but both lines lose idle-high behavior and are held low together for about 10.9 s during the S4 sequence. This is consistent with platform power-domain or EC/SMBus ownership behavior during S4, not direct LAN driver LED control.

## Recommended Decode / Export Windows

Use these time windows if exporting from Saleae Logic or preparing CSV for this parser:

- `18.70 s` to `18.85 s`: area where Saleae UI was positioned
- `29.50 s` to `40.53 s`: both-low SMBus interval and S4 end region

Recommended Saleae export:

- Digital channels: 3, 4, 5, 6, 7
- Analog channels: 0, 1, 2, 6, 7
- SMBus analyzer decode level: Bytes or SMBus basic protocol, not only Signals

## Recommended Next Capture

Capture these together if possible:

- SMBus DATA
- SMBus CLK
- Power button LED control line
- SLP_S4# or S4 state indicator
- PE_RST
- LAN 3V3 or relevant SMBus pull-up rail

This would allow direct timing correlation between S4 entry, SMBus pull-up behavior, LAN reset/power state, and LED flicker.