"""
Jacksonville PHY Register and Bit Definitions
Complete register map with bit field descriptions
"""

# Page name definitions from Jacksonville PHY JVL Specification
PAGE_NAMES = {
    0: "IEEE 802.3 Standard Registers",
    1: "Extended IEEE 802.3 Registers",
    96: "Copper PHY Specific Registers",
    97: "Copper PHY Extended Configuration",
    100: "PHY Indirect Access Registers",
    768: "External MDIO Registers",
    769: "Port Control Registers",
    770: "Kumeran Registers",
    771: "Kumeran Registers",
    772: "Kumeran Configuration Registers", 
    773: "Power Management Registers",
    774: "Kumeran BER Meter Registers",
    775: "Reserved",
    776: "General Registers",
    777: "Reserved",
    778: "Statistics Registers",
    779: "ULP Registers",
    781: "SKU Control Registers",
    800: "WOL Registers",
    801: "WOL Registers"
}

def get_page_name(page):
    """Get human-readable page name"""
    return PAGE_NAMES.get(page, f"Unknown Page ({page})")

def format_register_display(page, register, register_name):
    """Format register display as: page <page>[0x<hex>]: <name>"""
    if page is None or register is None:
        return None
    return f"page {page}[0x{register:02X}]: {register_name}"

def default_bits():
    """Default bit labels when detailed fields are not available."""
    return {i: f"Bit {i}" for i in range(16)}

# Jacksonville PHY Page 0 (IEEE 802.3 Standard Registers)
PAGE_0_REGISTERS = {
    0x00: {
        "name": "Control Register - Address 0",
        "bits": {
            15: "Reset",
            14: "Loopback",
            13: "Speed Select (LSB)",
            12: "Auto-Negotiation Enable",
            11: "Power Down",
            10: "Isolate",
            9: "Restart Auto-Negotiation",
            8: "Duplex Mode",
            7: "Collision Test",
            6: "Speed Selection (MSB)",
            5: "Reserved",
            4: "Reserved", 
            3: "Reserved",
            2: "Reserved",
            1: "Reserved",
            0: "Reserved"
        }
    },
    0x01: {
        "name": "Basic Status Register",
        "bits": {
            15: "100BASE-T4 Capable",
            14: "100BASE-TX Full Duplex Capable",
            13: "100BASE-TX Half Duplex Capable", 
            12: "10BASE-T Full Duplex Capable",
            11: "10BASE-T Half Duplex Capable",
            10: "100BASE-T2 Full Duplex Capable",
            9: "100BASE-T2 Half Duplex Capable",
            8: "Extended Status",
            7: "Reserved",
            6: "MF Preamble Suppression",
            5: "Auto-Negotiation Complete",
            4: "Remote Fault",
            3: "Auto-Negotiation Ability",
            2: "Link Status",
            1: "Jabber Detect",
            0: "Extended Capability"
        }
    },
    0x02: {
        "name": "PHY Identifier 1",
        "bits": {15: "OUI[21:6] - Bit 15", 14: "OUI[21:6] - Bit 14", 13: "OUI[21:6] - Bit 13", 12: "OUI[21:6] - Bit 12",
                11: "OUI[21:6] - Bit 11", 10: "OUI[21:6] - Bit 10", 9: "OUI[21:6] - Bit 9", 8: "OUI[21:6] - Bit 8",
                7: "OUI[21:6] - Bit 7", 6: "OUI[21:6] - Bit 6", 5: "OUI[21:6] - Bit 5", 4: "OUI[21:6] - Bit 4",
                3: "OUI[21:6] - Bit 3", 2: "OUI[21:6] - Bit 2", 1: "OUI[21:6] - Bit 1", 0: "OUI[21:6] - Bit 0"}
    },
    0x03: {
        "name": "PHY Identifier 2", 
        "bits": {15: "OUI[5:0] - Bit 5", 14: "OUI[5:0] - Bit 4", 13: "OUI[5:0] - Bit 3", 12: "OUI[5:0] - Bit 2",
                11: "OUI[5:0] - Bit 1", 10: "OUI[5:0] - Bit 0", 9: "Model Number - Bit 5", 8: "Model Number - Bit 4",
                7: "Model Number - Bit 3", 6: "Model Number - Bit 2", 5: "Model Number - Bit 1", 4: "Model Number - Bit 0",
                3: "Revision Number - Bit 3", 2: "Revision Number - Bit 2", 1: "Revision Number - Bit 1", 0: "Revision Number - Bit 0"}
    },
    0x04: {
        "name": "Auto-Negotiation Advertisement Register",
        "bits": {
            15: "Next Page",
            14: "Reserved",
            13: "Remote Fault",
            12: "Reserved",
            11: "Asymmetric Pause",
            10: "Pause Capable",
            9: "100BASE-T4 Capability",
            8: "100BASE-TX Full-Duplex Capable",
            7: "100BASE-TX Half-Duplex Capable",
            6: "10BASE-TX Full-Duplex Capable",
            5: "10BASE-TX Half-Duplex Capable",
            4: "Selector Field Bit 4",
            3: "Selector Field Bit 3",
            2: "Selector Field Bit 2",
            1: "Selector Field Bit 1",
            0: "Selector Field Bit 0"
        }
    },
    0x05: {
        "name": "Auto-Negotiation Link Partner Ability Register",
        "bits": {
            15: "Next Page",
            14: "Acknowledge",
            13: "Remote Fault",
            12: "Reserved",
            11: "Asymmetric Pause",
            10: "Pause Capable",
            9: "100BASE-T4 Capability",
            8: "100BASE-TX Full-Duplex Capability",
            7: "100BASE-TX Half-Duplex Capability",
            6: "10BASE-T Full-Duplex Capability",
            5: "10BASE-T Half-Duplex Capability",
            4: "Protocol Selector Field Bit 4",
            3: "Protocol Selector Field Bit 3",
            2: "Protocol Selector Field Bit 2",
            1: "Protocol Selector Field Bit 1",
            0: "Protocol Selector Field Bit 0"
        }
    },
    0x06: {
        "name": "Auto-Negotiation Expansion Register",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Parallel Detection Fault",
            3: "Link Partner Next Page Ability",
            2: "Next Page Capability",
            1: "Page Received",
            0: "Link Partner Auto-Negotiation Ability"
        }
    },
    0x07: {
        "name": "Auto-Negotiation Next Page Transmit Register",
        "bits": {
            15: "Next Page",
            14: "Reserved",
            13: "Message Page",
            12: "Acknowledge 2",
            11: "Toggle",
            10: "Message/Unformatted Field Bit 10",
            9: "Message/Unformatted Field Bit 9",
            8: "Message/Unformatted Field Bit 8",
            7: "Message/Unformatted Field Bit 7",
            6: "Message/Unformatted Field Bit 6",
            5: "Message/Unformatted Field Bit 5",
            4: "Message/Unformatted Field Bit 4",
            3: "Message/Unformatted Field Bit 3",
            2: "Message/Unformatted Field Bit 2",
            1: "Message/Unformatted Field Bit 1",
            0: "Message/Unformatted Field Bit 0"
        }
    },
    0x08: {
        "name": "Link Partner Next Page Register",
        "bits": {
            15: "Next Page",
            14: "Acknowledge",
            13: "Message Page",
            12: "Acknowledge2",
            11: "Toggle",
            10: "Message/Unformatted Code Field Bit 10",
            9: "Message/Unformatted Code Field Bit 9",
            8: "Message/Unformatted Code Field Bit 8",
            7: "Message/Unformatted Code Field Bit 7",
            6: "Message/Unformatted Code Field Bit 6",
            5: "Message/Unformatted Code Field Bit 5",
            4: "Message/Unformatted Code Field Bit 4",
            3: "Message/Unformatted Code Field Bit 3",
            2: "Message/Unformatted Code Field Bit 2",
            1: "Message/Unformatted Code Field Bit 1",
            0: "Message/Unformatted Code Field Bit 0"
        }
    },
    0x09: {
        "name": "1000BASE-T Control (Master-Slave Control/Status)",
        "bits": {
            15: "Test Mode Bit 2",
            14: "Test Mode Bit 1",
            13: "Test Mode Bit 0",
            12: "Master/Slave Manual Configuration Enable",
            11: "Master/Slave Configuration Value",
            10: "Port Type",
            9: "Advertise 1000BASE-T Full-Duplex Capability",
            8: "Advertise 1000BASE-T Half-Duplex Capability",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Reserved",
            3: "Reserved",
            2: "Reserved",
            1: "Reserved",
            0: "Reserved"
        }
    },
    # NOTE: Registers 0x19 and 0x1A are defined below as OEM Bits and SMBus Address
    # per Jacksonville EAS 1.12 (not Interrupt Enable/Status as in some other Intel PHYs).
    0x17: {
        "name": "PHY Special Control Status",
        "bits": {
            15: "Auto-MDIX Enable",
            14: "Force Link Good",
            13: "Energy Detect Power Down",
            12: "Force Link",
            11: "Reserved",
            10: "Polarity Reverse",
            9: "MDI/MDIX State",
            8: "Downshift Enable", 
            7: "Energy Detect Status",
            6: "TX Disable",
            5: "Remote Loopback",
            4: "Digital Restart",
            3: "Reserved",
            2: "Duplex Indication",
            1: "Speed Indication Low",
            0: "Speed Indication High"
        }
    },
    # NOTE: Register 0x18 is defined below as PHY Configuration Register
    # per Jacksonville EAS 1.12 (not Interrupt Control as in some other Intel PHYs).
    0x1F: {
        "name": "Page Select Register",
        "bits": {
            15: "Reserved", 14: "Reserved", 13: "Reserved", 12: "Reserved", 
            11: "Page Select Bit 11", 10: "Page Select Bit 10", 9: "Page Select Bit 9", 8: "Page Select Bit 8",
            7: "Page Select Bit 7", 6: "Page Select Bit 6", 5: "Page Select Bit 5", 4: "Page Select Bit 4",
            3: "Page Select Bit 3", 2: "Page Select Bit 2", 1: "Page Select Bit 1", 0: "Page Select Bit 0"
        }
    },
    0x18: {
        "name": "PHY Configuration Register",
        "bits": default_bits()
    },
    0x19: {
        "name": "OEM Bits Register",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Aneg_now (Restart AN)",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "a1000_dis (Disable 1Gbps)",
            5: "Reserved",
            4: "Reserved",
            3: "Reserved",
            2: "rev_aneg (Low Power Link Up)",
            1: "Reserved",
            0: "Reserved"
        }
    },
    0x1A: {
        "name": "SMB Address Register",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "SMBus Freq High",
            11: "SMB fragments size (0=32B, 1=64B)",
            10: "APM Enable",
            9: "PEC Enable",
            8: "SMBus Freq Low",
            7: "SMBus Address Valid",
            6: "SMBus Address Bit 6",
            5: "SMBus Address Bit 5",
            4: "SMBus Address Bit 4",
            3: "SMBus Address Bit 3",
            2: "SMBus Address Bit 2",
            1: "SMBus Address Bit 1",
            0: "SMBus Address Bit 0"
        }
    },
    0x1B: {
        "name": "Receive Address Register 0",
        "bits": default_bits()
    },
    0x1C: {
        "name": "Receive Address Register 1",
        "bits": default_bits()
    },
    0x1D: {
        "name": "Receive Address Register 2",
        "bits": default_bits()
    },
    0x1E: {
        "name": "LEDs Configuration Register",
        "bits": {
            15: "Blink rate (0=200ms, 1=83ms)",
            14: "LED2 Blink",
            13: "LED2 Invert",
            12: "LED2 Mode Bit 2",
            11: "LED2 Mode Bit 1",
            10: "LED2 Mode Bit 0",
            9: "LED1 Blink",
            8: "LED1 Invert",
            7: "LED1 Mode Bit 2",
            6: "LED1 Mode Bit 1",
            5: "LED1 Mode Bit 0",
            4: "LED0 Blink",
            3: "LED0 Invert",
            2: "LED0 Mode Bit 2",
            1: "LED0 Mode Bit 1",
            0: "LED0 Mode Bit 0"
        }
    }
}

# Jacksonville PHY Extended Register Pages
# Page definitions from Jacksonville PHY specification

# Page 768 Registers (0x300) - External MDIO Registers
PAGE_768_REGISTERS = {
    0x10: {  # Register 16
        "name": "External MDIO Control Register",
        "bits": default_bits()
    },
    0x11: {  # Register 17
        "name": "MDIO Control Register",
        "bits": default_bits()
    },
    0x12: {  # Register 18
        "name": "External MDIO Data Register",
        "bits": default_bits()
    },
    0x13: {  # Register 19
        "name": "MAC/PHY Status In Register",
        "bits": default_bits()
    },
    0x14: {  # Register 20
        "name": "MAC Status Out Register",
        "bits": default_bits()
    }
}

# Page 769 Registers (0x301) - Port Control Registers
PAGE_769_REGISTERS = {
    0x00: {  # Register 0
        "name": "Port Control Status Register",
        "bits": {
            15: "Link Status",
            14: "Speed[1]",
            13: "Speed[0]",
            12: "Duplex",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Reserved",
            3: "Reserved",
            2: "Reserved",
            1: "Reserved",
            0: "Reserved"
        }
    },
    0x01: {  # Register 1
        "name": "Port Control Configuration",
        "bits": default_bits()
    },
    0x02: {  # Register 2
        "name": "Port Interrupt Status",
        "bits": default_bits()
    },
    0x03: {  # Register 3
        "name": "Port Interrupt Enable",
        "bits": default_bits()
    },
    0x04: {  # Register 4
        "name": "Port Extended Status",
        "bits": default_bits()
    },
    0x05: {  # Register 5
        "name": "Port Reserved",
        "bits": default_bits()
    },
    0x06: {  # Register 6
        "name": "Port Reserved",
        "bits": default_bits()
    },
    0x07: {  # Register 7
        "name": "Port Reserved",
        "bits": default_bits()
    },
    0x08: {  # Register 8
        "name": "Port Reserved",
        "bits": default_bits()
    },
    0x09: {  # Register 9
        "name": "Port Reserved",
        "bits": default_bits()
    },
    0x0A: {  # Register 10
        "name": "Port Reserved",
        "bits": default_bits()
    },
    0x0B: {  # Register 11
        "name": "Port Reserved",
        "bits": default_bits()
    },
    0x0C: {  # Register 12
        "name": "Port Reserved",
        "bits": default_bits()
    },
    0x0D: {  # Register 13
        "name": "Port Reserved",
        "bits": default_bits()
    },
    0x0E: {  # Register 14
        "name": "Port Reserved",
        "bits": default_bits()
    },
    0x0F: {  # Register 15
        "name": "Port Reserved",
        "bits": default_bits()
    },
    0x10: {  # Register 16
        "name": "Kumeran Mode Control PHY Address 01, Page 769, Register 16",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "MDIO frequency access",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Reserved",
            3: "Reserved",
            2: "Reserved",
            1: "Reserved",
            0: "Reserved"
        }
    },
    0x11: {  # Register 17
        "name": "Port General Configuration PHY Address 01, Page 769, Register 17",
        "bits": {
            15: "Tx Gate Wait IFS Bit 4",
            14: "Tx Gate Wait IFS Bit 3",
            13: "Tx Gate Wait IFS Bit 2",
            12: "Tx Gate Wait IFS Bit 1",
            11: "Tx Gate Wait IFS Bit 0",
            10: "BP extension Wait Bit 2",
            9: "BP extension Wait Bit 1",
            8: "BP extension Wait Bit 0",
            7: "Reserved",
            6: "Active_PD_enable (sD3 Enable)",
            5: "ME_WU_Actived",
            4: "Host_WU_Active",
            3: "Wakeup clocks stop",
            2: "MACPD_enable",
            1: "Reserved",
            0: "Reserved"
        }
    },
    0x15: {  # Register 21
        "name": "MTX Control Register 1 PHY Address 01, Page 769, Register 21",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Collision threshold",
            7: "Collision threshold",
            6: "Collision threshold",
            5: "Collision threshold",
            4: "Collision threshold",
            3: "Collision threshold",
            2: "Collision threshold",
            1: "Collision threshold",
            0: "Retry late collision"
        }
    },
    0x17: {  # Register 23
        "name": "SMBus Control Register PHY Address 01, Page 769, Register 23",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Use LANWAKE#",
            3: "Reserved",
            2: "Reserved",
            1: "dis_SMB_filtering",
            0: "Force SMBus"
        }
    },
    0x12: {  # Register 18
        "name": "PHY LEDs Control Register PHY Address 01, Page 769, Register 18",
        "bits": default_bits()
    },
    0x13: {  # Register 19
        "name": "PHY Address Switching Register PHY Address 01, Page 769, Register 19",
        "bits": default_bits()
    },
    0x14: {  # Register 20
        "name": "DFT Control Register PHY Address 01, Page 769, Register 20",
        "bits": {
            15: "nreg_en_fix_3214400",
            14: "nreg_software_gate_rx",
            13: "nreg_enable_delay_cycle_jumbo",
            12: "nreg_force_power_down_serdes",
            11: "nreg_power_down_serdes",
            10: "nreg_early_link_use_dis",
            9: "NREG_FORCE_SR_DIS",
            8: "NREG_FORCE_GO_EIDLE",
            7: "NREG_FORCE_PLL_STOP",
            6: "veto_bit_phy_rst",
            5: "power_down_f",
            4: "use_xtal_clk_f",
            3: "force_use_xtal_clk",
            2: "nreg_stop_pll_pwr_down_en",
            1: "nreg_pll_link_disc_en",
            0: "romi_write_oem_en_n"
        }
    },
    0x18: {  # Register 24
        "name": "MTX Control Register 2 PHY Address 01, Page 769, Register 24",
        "bits": default_bits()
    },
    0x19: {  # Register 25
        "name": "Rate Adaptation Control Register PHY Address 01, Page 769, Register 25",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "rx_en_rxdv_preamble",
            7: "rx_en_crs_preamble",
            6: "Reserved",
            5: "rx_flip_bad_sfd",
            4: "read_delay_fd Bit 4",
            3: "read_delay_fd Bit 3",
            2: "read_delay_fd Bit 2",
            1: "read_delay_fd Bit 1",
            0: "read_delay_fd Bit 0"
        }
    },
    0x1A: {  # Register 26
        "name": "LSI SERDES Control and Status Register PHY Address 01, Page 769, Register 26",
        "bits": default_bits()
    },
    0x1B: {  # Register 27
        "name": "Flow Control Transmit Timer Value (FCTTV) Register PHY Address 01, Page 769, Register 27",
        "bits": {
            15: "FCTTV Bit 15",
            14: "FCTTV Bit 14",
            13: "FCTTV Bit 13",
            12: "FCTTV Bit 12",
            11: "FCTTV Bit 11",
            10: "FCTTV Bit 10",
            9: "FCTTV Bit 9",
            8: "FCTTV Bit 8",
            7: "FCTTV Bit 7",
            6: "FCTTV Bit 6",
            5: "FCTTV Bit 5",
            4: "FCTTV Bit 4",
            3: "FCTTV Bit 3",
            2: "FCTTV Bit 2",
            1: "FCTTV Bit 1",
            0: "FCTTV Bit 0"
        }
    },
    0x1C: {  # Register 28
        "name": "Extended Proxy Control (EPRXC) Register PHY Address 01, Page 769, Register 28",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "disable_storing_me_pkt_1g",
            6: "clear_me_wol_pkt_ind_from_reg",
            5: "use_pcie_rst0_smb_sel1",
            4: "Enable new indication for FC",
            3: "Enable Flow Control in SMBus",
            2: "Enable ICMPv6 filtering",
            1: "uctl_can_lcd_reset",
            0: "uctl_active_in_pcie"
        }
    },
    0x1D: {  # Register 29
        "name": "Switch PHY Address Enable Register PHY Address 01, Page 769, Register 29",
        "bits": default_bits()
    }
}

# Page 770 Registers (0x302) - Kumeran Registers
PAGE_770_REGISTERS = {
    0x10: {  # Register 16
        "name": "Kumeran FIFO’s Control/Status Register",
        "bits": default_bits()
    },
    0x11: {  # Register 17
        "name": "PCIe Power Management Control Register",
        "bits": {
            15: "Burst enable",
            14: "K1 enable",
            13: "Giga_K1_disable",
            12: "pll_stop_en_ich",
            11: "dis_kstate_hdx",
            10: "HV_PM_CTRL (Disable periodic inband)",
            9: "Request PCIE clock in K1",
            8: "PLL stop in K1 giga",
            7: "PLL stop in K1 (10/100)",
            6: "K0s mode enable 10/100",
            5: "K0s mode 1 enable 1000",
            4: "K1 entry latency Bit 3",
            3: "K1 entry latency Bit 2",
            2: "K1 entry latency Bit 1",
            1: "K1 entry latency Bit 0",
            0: "Enable EI in Cable Disconnect"
        }
    },
    0x12: {  # Register 18
        "name": "Inband Control Register",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Link status TX timeout Bit 5",
            12: "Link status TX timeout Bit 4",
            11: "Link status TX timeout Bit 3",
            10: "Link status TX timeout Bit 2",
            9: "Link status TX timeout Bit 1",
            8: "Link status TX timeout Bit 0",
            7: "kum_pad_use_dis",
            6: "Max retries Bit 6",
            5: "Max retries Bit 5",
            4: "Max retries Bit 4",
            3: "Max retries Bit 3",
            2: "Max retries Bit 2",
            1: "Max retries Bit 1",
            0: "Max retries Bit 0"
        }
    },
    0x13: {  # Register 19
        "name": "Kumeran Diagnostic Register",
        "bits": {
            15: "Inband MDIO ack timeout Bit 7",
            14: "Inband MDIO ack timeout Bit 6",
            13: "Inband MDIO ack timeout Bit 5",
            12: "Inband MDIO ack timeout Bit 4",
            11: "Inband MDIO ack timeout Bit 3",
            10: "Inband MDIO ack timeout Bit 2",
            9: "Inband MDIO ack timeout Bit 1",
            8: "Inband MDIO ack timeout Bit 0",
            7: "Reserved",
            6: "Reserved",
            5: "Inband status ack timeout Bit 5",
            4: "Inband status ack timeout Bit 4",
            3: "Inband status ack timeout Bit 3",
            2: "Inband status ack timeout Bit 2",
            1: "Inband status ack timeout Bit 1",
            0: "Inband status ack timeout Bit 0"
        }
    },
    0x14: {  # Register 20
        "name": "Acknowledge Timeouts Register",
        "bits": {
            15: "Inband MDIO ack timeout Bit 7",
            14: "Inband MDIO ack timeout Bit 6",
            13: "Inband MDIO ack timeout Bit 5",
            12: "Inband MDIO ack timeout Bit 4",
            11: "Inband MDIO ack timeout Bit 3",
            10: "Inband MDIO ack timeout Bit 2",
            9: "Inband MDIO ack timeout Bit 1",
            8: "Inband MDIO ack timeout Bit 0",
            7: "Reserved",
            6: "Reserved",
            5: "Inband status ack timeout Bit 5",
            4: "Inband status ack timeout Bit 4",
            3: "Inband status ack timeout Bit 3",
            2: "Inband status ack timeout Bit 2",
            1: "Inband status ack timeout Bit 1",
            0: "Inband status ack timeout Bit 0"
        }
    },
    0x15: {  # Register 21
        "name": "PCIE Kstate Exit Timeouts Register",
        "bits": {
            15: "Reserved", 14: "Reserved", 13: "Reserved", 12: "Reserved",
            11: "K1 exit timeout Bit 5", 10: "K1 exit timeout Bit 4", 9: "K1 exit timeout Bit 3",
            8: "K1 exit timeout Bit 2", 7: "K1 exit timeout Bit 1", 6: "K1 exit timeout Bit 0",
            5: "K0s exit timeout Bit 5", 4: "K0s exit timeout Bit 4", 3: "K0s exit timeout Bit 3",
            2: "K0s exit timeout Bit 2", 1: "K0s exit timeout Bit 1", 0: "K0s exit timeout Bit 0"
        }
    },
    0x16: {  # Register 22
        "name": "Serial Auto-negotiation Register",
        "bits": default_bits()
    },
    0x17: {  # Register 23
        "name": "PCIE Kstate Minimum Duration Timeouts Register",
        "bits": default_bits()
    },
    0x1A: {  # Register 26
        "name": "Kumeran Misc Register",
        "bits": default_bits()
    },
    0x1B: {  # Register 27
        "name": "Kumeran IBIST Control Register",
        "bits": default_bits()
    },
    0x1C: {  # Register 28
        "name": "Kumeran IBIST Status Register",
        "bits": default_bits()
    }
}

PAGE_771_REGISTERS = {
    0x10: {  # Register 16
        "name": "Kumeran IBIST Symbol Buffer Low Register",
        "bits": default_bits()
    },
    0x11: {  # Register 17
        "name": "Kumeran IBIST Symbol Buffer High Register",
        "bits": default_bits()
    },
    0x12: {  # Register 18
        "name": "Kumeran IBIST Extended Control Register",
        "bits": default_bits()
    },
    0x13: {  # Register 19
        "name": "Kumeran IBIST Loop Counter Register",
        "bits": default_bits()
    }
}

# Page 772 Registers (0x304)
PAGE_772_REGISTERS = {
    0x10: {  # Register 16
        "name": "Probe Mode Control Register (Low)",
        "bits": default_bits()
    },
    0x11: {  # Register 17
        "name": "Probe Mode Control Register (High)",
        "bits": default_bits()
    },
    0x12: {  # Register 18
        "name": "Low Power Idle GPIO Control",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Auto EN LPI - Auto enable LPI after link up",
            10: "TX_LPI_GPIO0 - Route Tx LPI to GPIO 0",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Reserved",
            3: "Reserved",
            2: "Reserved",
            1: "Reserved",
            0: "Reserved"
        }
    },
    0x13: {  # Register 19
        "name": "Configuration Register",
        "bits": default_bits()
    },
    0x14: {  # Register 20
        "name": "Low Power Idle Control Register",
        "bits": {
            15: "Reserved",
            14: "1000Enable - Enable EEE on 1Gb/s",
            13: "100Enable - Enable EEE on 100Mb/s",
            12: "ForceLPI - Force LPI entry",
            11: "PostLPICount Bit 2",
            10: "PostLPICount Bit 1",
            9: "PostLPICount Bit 0",
            8: "EnRxInBand - Enable RX LPI inband",
            7: "FrcPllLockCnt - Force PLL Lock counter",
            6: "PllLockCnt Bit 2",
            5: "PllLockCnt Bit 1",
            4: "PllLockCnt Bit 0",
            3: "dis_rx_lpi_k1_cond - Disable LPI K1 condition",
            2: "Reserved",
            1: "Reserved",
            0: "Reserved"
        }
    },
    0x15: {  # Register 21
        "name": "Configuration Register",
        "bits": default_bits()
    },
    0x17: {  # Register 23
        "name": "Flow Control Refresh Threshold Value (FCRTV) Register",
        "bits": default_bits()
    },
    0x18: {  # Register 24
        "name": "Flow Control Thresholds (FCTH) Register",
        "bits": default_bits()
    },
    0x19: {  # Register 25
        "name": "Configuration Register",
        "bits": default_bits()
    },
    0x1A: {  # Register 26
        "name": "Buffers Load Drivers Configuration Register",
        "bits": default_bits()
    },
    0x1B: {  # Register 27
        "name": "Memories Power Modes Configuration Register",
        "bits": default_bits()
    },
    0x1C: {  # Register 28
        "name": "Configuration Register",
        "bits": default_bits()
    },
    0x1D: {  # Register 29
        "name": "Configuration Register",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "CS_Mode_Stay_In_K1",
            4: "Reserved",
            3: "Reserved",
            2: "Reserved",
            1: "ENMTAONPWRGD",
            0: "Reserved"
        }
    }
}

PAGE_774_REGISTERS = {
    0x10: {
        "name": "Kumeran BER Meter Register 16",
        "bits": default_bits()
    },
    0x11: {
        "name": "Kumeran BER Meter Register 17",
        "bits": default_bits()
    },
    0x12: {
        "name": "Kumeran BER Meter Register 18",
        "bits": default_bits()
    },
    0x13: {
        "name": "Kumeran BER Meter Register 19",
        "bits": default_bits()
    },
    0x14: {
        "name": "Kumeran BER Meter Register 20",
        "bits": default_bits()
    },
    0x15: {
        "name": "Kumeran BER Meter Register 21",
        "bits": default_bits()
    },
    0x17: {
        "name": "SERDES MDI Control Register (Low)",
        "bits": default_bits()
    },
    0x18: {
        "name": "SERDES MDI Control Register (High)",
        "bits": default_bits()
    },
    0x1A: {
        "name": "Probe Mode Trigger Register",
        "bits": default_bits()
    }
}

PAGE_776_REGISTERS = {
    0x10: {
        "name": "General MUX Data Control Register",
        "bits": default_bits()
    },
    0x11: {
        "name": "General Packet_gen Length Register",
        "bits": default_bits()
    },
    0x12: {
        "name": "ECO Register",
        "bits": default_bits()
    },
    0x14: {
        "name": "General Register 20",
        "bits": default_bits()
    },
    0x15: {
        "name": "General Register 21",
        "bits": default_bits()
    },
    0x17: {
        "name": "General IPG Adding on Jumbo Fix Register",
        "bits": default_bits()
    },
    0x12: {  # Register 18
        "name": "Jacksonville Energy Detect Mode",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Reserved",
            3: "Reserved",
            2: "Reserved",
            1: "Reserved",
            0: "Disable Energy Detect Mode"
        }
    },
    0x14: {  # Register 20 - TX Threshold
        "name": "TX Threshold Register",
        "bits": {
            15: "nreg_num_ipg_in_tx Bit 3",
            14: "nreg_num_ipg_in_tx Bit 2",
            13: "nreg_num_ipg_in_tx Bit 1",
            12: "nreg_num_ipg_in_tx Bit 0",
            11: "nreg_rd_wr_gap_tx_fifo Bit 9",
            10: "nreg_rd_wr_gap_tx_fifo Bit 8",
            9: "nreg_rd_wr_gap_tx_fifo Bit 7",
            8: "nreg_rd_wr_gap_tx_fifo Bit 6",
            7: "nreg_rd_wr_gap_tx_fifo Bit 5",
            6: "nreg_rd_wr_gap_tx_fifo Bit 4",
            5: "nreg_rd_wr_gap_tx_fifo Bit 3",
            4: "nreg_rd_wr_gap_tx_fifo Bit 2",
            3: "nreg_rd_wr_gap_tx_fifo Bit 1",
            2: "nreg_rd_wr_gap_tx_fifo Bit 0",
            1: "bond_to_reg Bit 1",
            0: "bond_to_reg Bit 0"
        }
    },
    0x18: {
        "name": "General Control Register",
        "bits": default_bits()
    },
    0x13: {  # Register 19
        "name": "Jacksonville Capability Register",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Intel AMT and Circuit Breaker",
            8: "802.1Q & 802.1p",
            7: "Receive Side Scaling (RSS)",
            6: "2 Tx and 2 Rx Queues",
            5: "Energy Detect",
            4: "AC/DC Auto Link Speed Connect",
            3: "Reserved",
            2: "ASF (Alert Standard Format)",
            1: "WfM (Wired-for-Manageability)",
            0: "Ability to initiate a team"
        }
    },
    0x19: {
        "name": "General Packet_gen RX Err Count Register",
        "bits": default_bits()
    },
    0x1A: {
        "name": "General Packet_gen CRC Err Count Register",
        "bits": default_bits()
    },
    0x1B: {
        "name": "General Packet_gen Align Err Count Register",
        "bits": default_bits()
    },
    0x1C: {
        "name": "General Packet_gen Counter Register",
        "bits": default_bits()
    }
}

PAGE_781_REGISTERS = {
    0x10: {
        "name": "SKU Control Register",
        "bits": default_bits()
    }
}

PAGE_800_REGISTERS = {
    0x00: {  # Register 0
        "name": "Receive Control (RCTL)",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "DPF - Discard Pause Frames",
            7: "RFCE - Receive Flow Control Enable",
            6: "PMCF - Pass MAC Control Frames",
            5: "BAM - Broadcast Accept Mode",
            4: "MO - Multicast Offset Bit 1",
            3: "MO - Multicast Offset Bit 0",
            2: "Slave Access Enable",
            1: "MPE - Multicast Promiscuous Enable",
            0: "UPE - Unicast Promiscuous Enable"
        }
    },
    0x01: {  # Register 1
        "name": "Wake Up Control (WUC)",
        "bits": {
            15: "FLX7 - Flexible filter 7 enable",
            14: "FLX6 - Flexible filter 6 enable",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "LSCWO - Link Status Change Wake Override",
            4: "LSCWE - Link Status Change Wake Enable",
            3: "Link Status change on Energy detect",
            2: "PME_Status",
            1: "PME_En - PME Enable",
            0: "APME - Advance Power Management Enable"
        }
    },
    0x02: {  # Register 2
        "name": "Wake Up Filter Control (WUFC)",
        "bits": {
            15: "FLX3 - Flexible filter 3 enable",
            14: "FLX2 - Flexible filter 2 enable",
            13: "FLX1 - Flexible filter 1 enable",
            12: "FLX0 - Flexible filter 0 enable",
            11: "NoTCO - Ignore TCO packets",
            10: "FLX5 - Flexible filter 5 enable",
            9: "FLX4 - Flexible filter 4 enable",
            8: "Reserved",
            7: "IPV6 - Directed IPv6 packet wake enable",
            6: "IPV4 - Directed IPv4 packet wake enable",
            5: "ARP - ARP/IPv4 request packet wake enable",
            4: "BC - Broadcast wake enable",
            3: "MC - Directed multicast wake enable",
            2: "EX - Directed exact wake enable",
            1: "MAG - Magic packet wake enable",
            0: "LNKC - Link status change wake enable"
        }
    },
    0x03: {  # Register 3
        "name": "Wake Up Status (WUS)",
        "bits": {
            15: "FLX3 - Flexible filter 3 match",
            14: "FLX2 - Flexible filter 2 match",
            13: "FLX1 - Flexible filter 1 match",
            12: "FLX0 - Flexible filter 0 match",
            11: "FLX7 - Flexible filter 7 match",
            10: "FLX6 - Flexible filter 6 match",
            9: "FLX5 - Flexible filter 5 match",
            8: "FLX4 - Flexible filter 4 match",
            7: "IPV6 - Directed IPv6 packet received",
            6: "IPV4 - Directed IPv4 packet received",
            5: "ARP - ARP/IPv4 request packet received",
            4: "BC - Broadcast packet received",
            3: "MC - Directed multicast packet received",
            2: "EX - Directed exact packet received",
            1: "MAG - Magic packet received",
            0: "LNKC - Link status changed"
        }
    },
    0x48: {
        "name": "Proxy Control 2 Register",
        "bits": default_bits()
    },
    0x49: {
        "name": "Proxy Control 3 Register",
        "bits": default_bits()
    },
    0x4A: {
        "name": "Proxy Control 4 Register",
        "bits": default_bits()
    }
}

PAGE_801_REGISTERS = {}

# Page 779 Registers (0x30B) - ULP Registers
PAGE_779_REGISTERS = {
    0x10: {  # Register 16
        "name": "ULP Configuration 1 PHY Address 01, Page 779, Register 16",
        "bits": {
            15: "RESET_ULP_IND",
            14: "FORCE_ULP",
            13: "RESERVED",
            12: "DISABLE_SMB_PERST",
            11: "DIS_CLR_STICKY_ON_PERST",
            10: "EN_ULP_LANPHYPC",
            9: "EN_1G_SMBUS",
            8: "RESET_TO_SMBUS",
            7: "WOL_ME",
            6: "WOL_HOST",
            5: "INBAND_EXIT",
            4: "STICKY_ULP", 
            3: "RESERVED",
            2: "ULP_IND",
            1: "SW_ACCESS",
            0: "START"
        }
    },
    0x11: {  # Register 17
        "name": "ULP Configuration 2",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "MESHADOW Bit 4",
            3: "MESHADOW Bit 3",
            2: "MESHADOW Bit 2",
            1: "MESHADOW Bit 1",
            0: "MESHADOW Bit 0"
        }
    },
    0x12: {  # Register 18
        "name": "ULP SW Control",
        "bits": {
            15: "ULP MAILBOX Bit 7",
            14: "ULP MAILBOX Bit 6", 
            13: "ULP MAILBOX Bit 5",
            12: "ULP MAILBOX Bit 4",
            11: "ULP MAILBOX Bit 3",
            10: "ULP MAILBOX Bit 2",
            9: "ULP MAILBOX Bit 1",
            8: "ULP MAILBOX Bit 0",
            7: "Reserved",
            6: "ULP SW READ TO REGISTER",
            5: "ULP SW WRITE FROM REGISTER",
            4: "SW GEN WRITE ENABLE",
            3: "SW BUS SELECTOR Bit 3",
            2: "SW BUS SELECTOR Bit 2",
            1: "SW BUS SELECTOR Bit 1",
            0: "SW BUS SELECTOR Bit 0"
        }
    },
    0x13: {  # Register 19
        "name": "ULP Software Control",
        "bits": {
            15: "gating_status - RX gating status",
            14: "stop_gate_rx_due2flex - Stop RX gating",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "str_wol_pkt_gating_timeout Bit 3",
            8: "str_wol_pkt_gating_timeout Bit 2",
            7: "str_wol_pkt_gating_timeout Bit 1",
            6: "str_wol_pkt_gating_timeout Bit 0",
            5: "str_wol_pkt_no_ind_from_fltr_timeout Bit 3",
            4: "str_wol_pkt_no_ind_from_fltr_timeout Bit 2",
            3: "str_wol_pkt_no_ind_from_fltr_timeout Bit 1",
            2: "str_wol_pkt_no_ind_from_fltr_timeout Bit 0",
            1: "sw_rd_pkt - SW ready to read WoL packet",
            0: "str_wol_pkt_feature_en - Store WoL pkt enable"
        }
    },
    0x14: {  # Register 20
        "name": "Off Board LAN Connected Device Control",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Reserved",
            3: "Reserved",
            2: "Reserved",
            1: "Reserved",
            0: "Reserved"
        }
    },
    0x1D: {  # Register 29 - Cable Status
        "name": "Cable Status Register PHY Address 01, Page 779, Register 29",
        "bits": {
            15: "Cable Status Bit 15",
            14: "Cable Status Bit 14",
            13: "Cable Status Bit 13",
            12: "Cable Status Bit 12",
            11: "Cable Status Bit 11",
            10: "Cable Status Bit 10",
            9: "Cable Status Bit 9",
            8: "Cable Status Bit 8",
            7: "Cable Status Bit 7",
            6: "Cable Status Bit 6",
            5: "Cable Status Bit 5",
            4: "Cable Status Bit 4",
            3: "Cable Status Bit 3",
            2: "Cable Status Bit 2",
            1: "Cable Status Bit 1",
            0: "Cable Status Bit 0"
        }
    }
}

# Jacksonville PHY Page 1 (Extended Registers)
PAGE_1_REGISTERS = {
    0x00: {
        "name": "Extended Control Register",
        "bits": {
            15: "Reserved",
            14: "Reserved", 
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Software Reset",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Reserved",
            3: "Reserved",
            2: "Reserved",
            1: "Reserved",
            0: "Reserved"
        }
    },
    0x01: {
        "name": "Extended Status Register",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved", 
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Extended Status",
            7: "Cable Diagnostic Status",
            6: "Energy Detect Status",
            5: "Link Status",
            4: "Speed Status - Bit 1",
            3: "Speed Status - Bit 0", 
            2: "Duplex Status",
            1: "Auto-Negotiation Status",
            0: "Reserved"
        }
    },
    0x04: {
        "name": "Test Register 1",
        "bits": {
            15: "Test Pattern - Bit 15", 14: "Test Pattern - Bit 14", 13: "Test Pattern - Bit 13", 12: "Test Pattern - Bit 12",
            11: "Test Pattern - Bit 11", 10: "Test Pattern - Bit 10", 9: "Test Pattern - Bit 9", 8: "Test Pattern - Bit 8",
            7: "Test Pattern - Bit 7", 6: "Test Pattern - Bit 6", 5: "Test Pattern - Bit 5", 4: "Test Pattern - Bit 4",
            3: "Test Pattern - Bit 3", 2: "Test Pattern - Bit 2", 1: "Test Pattern - Bit 1", 0: "Test Pattern - Bit 0"
        }
    },
    0x20: {
        "name": "Power Management Control",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Energy Detect Power Down",
            11: "Reserved",
            10: "Reserved", 
            9: "Auto Power Down Enable",
            8: "Reserved",
            7: "Reserved",
            6: "Wake-on-LAN Enable",
            5: "Magic Packet Enable",
            4: "Link Pulse Enable", 
            3: "Energy Detect Enable",
            2: "Reserved",
            1: "Power Down Mode",
            0: "Sleep Mode"
        }
    },
    0x21: {
        "name": "Power Management Status",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Energy Detect Power Down Status",
            11: "Reserved",
            10: "Reserved",
            9: "Auto Power Down Status", 
            8: "Reserved",
            7: "Reserved",
            6: "Wake-on-LAN Status",
            5: "Magic Packet Status",
            4: "Link Pulse Status",
            3: "Energy Detect Status", 
            2: "Reserved",
            1: "Power Down Status",
            0: "Sleep Status"
        }
    },
    0x40: {
        "name": "Cable Diagnostics Control",
        "bits": {
            15: "Cable Diagnostic Enable",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved", 
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Reserved",
            3: "Reserved",
            2: "Reserved",
            1: "Reserved",
            0: "Reserved"
        }
    },
    0x44: {
        "name": "Cable Diagnostics Status",
        "bits": {
            15: "Cable Diagnostic Complete",
            14: "Cable Diagnostic Error",
            13: "Reserved",
            12: "Reserved", 
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Pair A Status - Bit 1",
            6: "Pair A Status - Bit 0",
            5: "Pair B Status - Bit 1",
            4: "Pair B Status - Bit 0",
            3: "Pair C Status - Bit 1", 
            2: "Pair C Status - Bit 0",
            1: "Pair D Status - Bit 1",
            0: "Pair D Status - Bit 0"
        }
    },
    0x50: {
        "name": "Test Register 2 (Pattern 0x55)",
        "bits": {
            15: "Test Pattern - Bit 15", 14: "Test Pattern - Bit 14", 13: "Test Pattern - Bit 13", 12: "Test Pattern - Bit 12",
            11: "Test Pattern - Bit 11", 10: "Test Pattern - Bit 10", 9: "Test Pattern - Bit 9", 8: "Test Pattern - Bit 8",
            7: "Test Pattern - Bit 7", 6: "Test Pattern - Bit 6", 5: "Test Pattern - Bit 5", 4: "Test Pattern - Bit 4",
            3: "Test Pattern - Bit 3", 2: "Test Pattern - Bit 2", 1: "Test Pattern - Bit 1", 0: "Test Pattern - Bit 0"
        }
    },
    0x51: {
        "name": "Test Register 3 (Pattern 0xAA)",
        "bits": {
            15: "Test Pattern - Bit 15", 14: "Test Pattern - Bit 14", 13: "Test Pattern - Bit 13", 12: "Test Pattern - Bit 12",
            11: "Test Pattern - Bit 11", 10: "Test Pattern - Bit 10", 9: "Test Pattern - Bit 9", 8: "Test Pattern - Bit 8",
            7: "Test Pattern - Bit 7", 6: "Test Pattern - Bit 6", 5: "Test Pattern - Bit 5", 4: "Test Pattern - Bit 4",
            3: "Test Pattern - Bit 3", 2: "Test Pattern - Bit 2", 1: "Test Pattern - Bit 1", 0: "Test Pattern - Bit 0"
        }
    },
    0x60: {
        "name": "EEE Control Register",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "EEE Enable",
            7: "Reserved",
            6: "EEE Advertisement Enable",
            5: "EEE Link Partner Ability",
            4: "EEE Capability",
            3: "Reserved",
            2: "Reserved", 
            1: "EEE Status",
            0: "EEE Active"
        }
    },
    0x80: {
        "name": "Vendor Specific Register 1",
        "bits": {
            15: "Vendor Field - Bit 15", 14: "Vendor Field - Bit 14", 13: "Vendor Field - Bit 13", 12: "Vendor Field - Bit 12",
            11: "Vendor Field - Bit 11", 10: "Vendor Field - Bit 10", 9: "Vendor Field - Bit 9", 8: "Vendor Field - Bit 8",
            7: "Vendor Field - Bit 7", 6: "Vendor Field - Bit 6", 5: "Vendor Field - Bit 5", 4: "Vendor Field - Bit 4",
            3: "Vendor Field - Bit 3", 2: "Vendor Field - Bit 2", 1: "Vendor Field - Bit 1", 0: "Vendor Field - Bit 0"
        }
    },
    0x81: {
        "name": "Vendor Specific Register 2",
        "bits": {
            15: "Vendor Field - Bit 15", 14: "Vendor Field - Bit 14", 13: "Vendor Field - Bit 13", 12: "Vendor Field - Bit 12",
            11: "Vendor Field - Bit 11", 10: "Vendor Field - Bit 10", 9: "Vendor Field - Bit 9", 8: "Vendor Field - Bit 8",
            7: "Vendor Field - Bit 7", 6: "Vendor Field - Bit 6", 5: "Vendor Field - Bit 5", 4: "Vendor Field - Bit 4",
            3: "Vendor Field - Bit 3", 2: "Vendor Field - Bit 2", 1: "Vendor Field - Bit 1", 0: "Vendor Field - Bit 0"
        }
    }
}

# Status packet bit definitions for SMBus protocol
SMBUS_STATUS_BITS = {
    "phy_to_mac": {
        # Keys = status_value bit positions where status_value = (Wire[3]<<8)|Wire[4]
        5: "EI entry request",
        4: "RX in EEE LPI state",
        2: "Inband Host WoL indication",
        1: "TX off (MAC back pressure required)",
        0: "K1 entry request",
        15: "Reset complete (RSTC)",
        14: "Interrupt request (INT)",
        13: "PCIe Link Status (KLINK, reserved)",
        12: "PHY cable disconnected (CDIS)",
        11: "Ethernet Link up (ELINK)",
        10: "Full Duplex (DPX)",
        9: "Speed - Bit 1 (MSB)",
        8: "Speed - Bit 0 (LSB)"
    },
    "mac_to_phy": {
        5: "TX LPI Exit request",
        4: "TX LPI Entry request",
        3: "XON request",
        2: "EI entry request",
        1: "XOFF request",
        0: "K1 entry request",
        15: "Port reset",
        14: "Power down",
        8: "PINSTOP: Clear the LANWAKE# pin"
    }
}

# Page 96 Registers (0x60) - Copper PHY Specific Registers
# Vendor-specific copper PHY configuration and status registers
PAGE_96_REGISTERS = {
    0x02: {
        "name": "PHY Identifier 1",
        "bits": {15: "OUI[21:6] - Bit 15", 14: "OUI[21:6] - Bit 14", 13: "OUI[21:6] - Bit 13", 12: "OUI[21:6] - Bit 12",
                11: "OUI[21:6] - Bit 11", 10: "OUI[21:6] - Bit 10", 9: "OUI[21:6] - Bit 9", 8: "OUI[21:6] - Bit 8",
                7: "OUI[21:6] - Bit 7", 6: "OUI[21:6] - Bit 6", 5: "OUI[21:6] - Bit 5", 4: "OUI[21:6] - Bit 4",
                3: "OUI[21:6] - Bit 3", 2: "OUI[21:6] - Bit 2", 1: "OUI[21:6] - Bit 1", 0: "OUI[21:6] - Bit 0"}
    },
    0x03: {
        "name": "PHY Identifier 2",
        "bits": {15: "OUI[5:0] - Bit 5", 14: "OUI[5:0] - Bit 4", 13: "OUI[5:0] - Bit 3", 12: "OUI[5:0] - Bit 2",
                11: "OUI[5:0] - Bit 1", 10: "OUI[5:0] - Bit 0", 9: "Model Number - Bit 5", 8: "Model Number - Bit 4",
                7: "Model Number - Bit 3", 6: "Model Number - Bit 2", 5: "Model Number - Bit 1", 4: "Model Number - Bit 0",
                3: "Revision Number - Bit 3", 2: "Revision Number - Bit 2", 1: "Revision Number - Bit 1", 0: "Revision Number - Bit 0"}
    },
    0x10: {  # Register 16
        "name": "Copper Specific Control Register",
        "bits": {
            15: "Reset",
            14: "Reserved",
            13: "Speed Select MSB",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Auto-MDIX Enable",
            4: "Reserved",
            3: "Reserved",
            2: "Reserved",
            1: "Reserved",
            0: "Copper Enable"
        }
    },
    0x11: {  # Register 17 - Most frequently accessed on this page
        "name": "Copper Specific Status 1",
        "bits": {
            15: "Speed Bit 1",
            14: "Speed Bit 0",
            13: "Duplex (1=Full, 0=Half)",
            12: "Page Received",
            11: "Speed/Duplex Resolved",
            10: "Link (real-time)",
            9: "Reserved",
            8: "MDI Crossover Status",
            7: "Reserved",
            6: "Downshift Status",
            5: "Reserved",
            4: "Energy Detect Status",
            3: "Transmit Pause Enabled",
            2: "Receive Pause Enabled",
            1: "Polarity (1=Reversed)",
            0: "Jabber (real-time)"
        }
    },
    0x14: {  # Register 20
        "name": "Copper Specific Control 2",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Downshift Counter Bit 2",
            6: "Downshift Counter Bit 1",
            5: "Downshift Counter Bit 0",
            4: "Downshift Enable",
            3: "Reserved",
            2: "Reserved",
            1: "Force Link Good",
            0: "Energy Detect Mode"
        }
    },
    0x15: {  # Register 21
        "name": "Copper Specific Status 2",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Reserved",
            12: "MDI Crossover Status",
            11: "Reserved",
            10: "Link Partner DTE Power",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Reserved",
            3: "Pair Swap Resolution Bit 1",
            2: "Pair Swap Resolution Bit 0",
            1: "Reserved",
            0: "Reserved"
        }
    },
    0x17: {  # Register 23 - Most frequently accessed overall
        "name": "Copper Specific Interrupt Enable / Passthrough Control",
        "bits": {
            15: "Reserved",
            14: "Speed Changed",
            13: "Duplex Changed",
            12: "Page Received",
            11: "AN Complete",
            10: "Link Status Changed",
            9: "Symbol Error",
            8: "False Carrier",
            7: "Crossover Changed",
            6: "Downshift",
            5: "Energy Detect",
            4: "Reserved",
            3: "Reserved",
            2: "Polarity Changed",
            1: "Jabber",
            0: "Reserved"
        }
    },
    0x1B: {  # Register 27
        "name": "LED Timer Control",
        "bits": {
            15: "LED Active",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Reserved",
            3: "Timer Value Bit 3",
            2: "Timer Value Bit 2",
            1: "Timer Value Bit 1",
            0: "Timer Value Bit 0"
        }
    },
    0x1D: {  # Register 29
        "name": "Copper Specific Control 3",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Link Down Delay",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Reserved",
            7: "INT Polarity",
            6: "Reserved",
            5: "Reserved",
            4: "Reserved",
            3: "Reserved",
            2: "Reserved",
            1: "Reserved",
            0: "Reserved"
        }
    }
}

# Page 97 Registers (0x61) - Copper PHY Extended Configuration
PAGE_97_REGISTERS = {
    0x10: {  # Register 16
        "name": "PHY Extended Configuration 1",
        "bits": {
            15: "Reserved",
            14: "Reserved",
            13: "Config Mode Bit 1",
            12: "Config Mode Bit 0",
            11: "Reserved",
            10: "Reserved",
            9: "Reserved",
            8: "Config Enable",
            7: "Reserved",
            6: "Reserved",
            5: "Reserved",
            4: "Analog Bias Bit 4",
            3: "Analog Bias Bit 3",
            2: "Analog Bias Bit 2",
            1: "Analog Bias Bit 1",
            0: "Analog Bias Bit 0"
        }
    },
    0x11: {  # Register 17
        "name": "PHY Extended Configuration 2",
        "bits": default_bits()
    },
    0x12: {  # Register 18
        "name": "PHY Extended Configuration 3",
        "bits": default_bits()
    },
    0x13: {  # Register 19
        "name": "PHY Extended Configuration 4",
        "bits": default_bits()
    },
    0x14: {  # Register 20
        "name": "PHY Extended Configuration 5",
        "bits": default_bits()
    },
    0x15: {  # Register 21
        "name": "PHY Extended Configuration 6",
        "bits": default_bits()
    },
    0x17: {  # Register 23
        "name": "PHY Extended Configuration 7",
        "bits": default_bits()
    },
    0x18: {  # Register 24
        "name": "PHY Extended Configuration 8",
        "bits": default_bits()
    },
    0x19: {  # Register 25
        "name": "PHY Extended Configuration 9",
        "bits": default_bits()
    },
    0x1A: {  # Register 26
        "name": "PHY Extended Configuration 10",
        "bits": default_bits()
    },
    0x1B: {  # Register 27
        "name": "PHY Extended Configuration 11",
        "bits": default_bits()
    },
    0x1C: {  # Register 28
        "name": "PHY Extended Configuration 12",
        "bits": default_bits()
    },
    0x1D: {  # Register 29
        "name": "PHY Extended Configuration 13",
        "bits": default_bits()
    },
    0x1E: {  # Register 30
        "name": "PHY Extended Configuration 14",
        "bits": default_bits()
    }
}

# Page 100 Registers (0x64) - PHY Indirect Access Registers
# Used for indirect register access: reg 0x11 = address/control, reg 0x12 = data
PAGE_100_REGISTERS = {
    0x11: {  # Register 17 - Address/Control port
        "name": "PHY Indirect Access Control",
        "bits": {
            15: "Access Valid / Done",
            14: "Reserved",
            13: "Reserved",
            12: "Reserved",
            11: "Reserved",
            10: "Reserved",
            9: "Address/Command Bit 9",
            8: "Address/Command Bit 8",
            7: "Address/Command Bit 7",
            6: "Address/Command Bit 6",
            5: "Address/Command Bit 5",
            4: "Address/Command Bit 4",
            3: "Address/Command Bit 3",
            2: "Address/Command Bit 2",
            1: "Address/Command Bit 1",
            0: "Address/Command Bit 0"
        }
    },
    0x12: {  # Register 18 - Data port
        "name": "PHY Indirect Access Data",
        "bits": {
            15: "Data Bit 15",
            14: "Data Bit 14",
            13: "Data Bit 13",
            12: "Data Bit 12",
            11: "Data Bit 11",
            10: "Data Bit 10",
            9: "Data Bit 9",
            8: "Data Bit 8",
            7: "Data Bit 7",
            6: "Data Bit 6",
            5: "Data Bit 5",
            4: "Data Bit 4",
            3: "Data Bit 3",
            2: "Data Bit 2",
            1: "Data Bit 1",
            0: "Data Bit 0"
        }
    }
}

def get_register_info(page, register):
    """Get register information based on page and register number"""
    if page == 0 and register in PAGE_0_REGISTERS:
        return PAGE_0_REGISTERS[register]
    elif page == 1 and register in PAGE_1_REGISTERS:
        return PAGE_1_REGISTERS[register]
    elif page == 96 and register in PAGE_96_REGISTERS:
        return PAGE_96_REGISTERS[register]
    elif page == 97 and register in PAGE_97_REGISTERS:
        return PAGE_97_REGISTERS[register]
    elif page == 100 and register in PAGE_100_REGISTERS:
        return PAGE_100_REGISTERS[register]
    elif page == 768 and register in PAGE_768_REGISTERS:
        return PAGE_768_REGISTERS[register]
    elif page == 769 and register in PAGE_769_REGISTERS:
        return PAGE_769_REGISTERS[register]
    elif page == 770 and register in PAGE_770_REGISTERS:
        return PAGE_770_REGISTERS[register]
    elif page == 771 and register in PAGE_771_REGISTERS:
        return PAGE_771_REGISTERS[register]
    elif page == 772 and register in PAGE_772_REGISTERS:
        return PAGE_772_REGISTERS[register]
    elif page == 774 and register in PAGE_774_REGISTERS:
        return PAGE_774_REGISTERS[register]
    elif page == 776 and register in PAGE_776_REGISTERS:
        return PAGE_776_REGISTERS[register]
    elif page == 779 and register in PAGE_779_REGISTERS:
        return PAGE_779_REGISTERS[register]
    elif page == 781 and register in PAGE_781_REGISTERS:
        return PAGE_781_REGISTERS[register]
    elif page == 800 and register in PAGE_800_REGISTERS:
        return PAGE_800_REGISTERS[register]
    elif page == 801 and register in PAGE_801_REGISTERS:
        return PAGE_801_REGISTERS[register]
    else:
        return {
            "name": "Unknown Register",
            "bits": {i: f"Bit {i}" for i in range(16)}
        }