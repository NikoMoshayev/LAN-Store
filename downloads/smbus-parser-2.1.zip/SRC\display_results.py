import csv
import pandas as pd
from phy_definitions import format_register_display

def display_parsed_smbus_data(csv_file="SMBUS_Trace_After_Parsing.csv"):
    """Display the parsed SMBus data in a readable format"""
    
    try:
        # Read the CSV file, skipping malformed lines
        df = pd.read_csv(csv_file, on_bad_lines='skip')
        
        # Remove any rows with missing essential data
        df = df.dropna(subset=['message number', 'Time'])
        df = df[df['message number'] != '']
        
        print("="*80)
        print("ADVANCED SMBUS PARSER RESULTS")
        print("="*80)
        print(f"Total messages parsed: {len(df)}")
        print()
        
        # Show summary statistics
        print("MESSAGE TYPE SUMMARY:")
        print("-" * 40)
        message_counts = df['message type'].value_counts()
        for msg_type, count in message_counts.items():
            print(f"{msg_type}: {count}")
        
        print("\nDIRECTION SUMMARY:")
        print("-" * 40)
        direction_counts = df['message direction'].value_counts()
        for direction, count in direction_counts.items():
            print(f"{direction}: {count}")
        
        print("\nFIRST 10 PARSED MESSAGES:")
        print("-" * 80)
        
        # Display first 10 messages in a readable format
        for idx in range(min(10, len(df))):
            row = df.iloc[idx]
            print(f"[{row['message number']}] {row['Time']} ({row['Duration']})")
            print(f"    Direction: {row['message direction']}")
            print(f"    Type: {row['message type']}")
            
            if pd.notna(row['page']) and row['page'] != '':
                print(f"    Page: {row['page']}")
            if pd.notna(row['phy address']) and row['phy address'] != '':
                print(f"    PHY Address: {row['phy address']}")
            if pd.notna(row['register']) and row['register'] != '':
                register_display = None
                try:
                    page_val = int(row['page']) if pd.notna(row['page']) and row['page'] != '' else None
                    reg_val = int(row['register'])
                    register_display = format_register_display(page_val, reg_val, "Unknown Register")
                except Exception:
                    register_display = None
                if register_display:
                    print(f"    Register: {register_display}")
                else:
                    print(f"    Register: {row['register']}")
            if pd.notna(row['details']) and row['details'] != '':
                print(f"    Details: {row['details']}")
            print()
        
        print("\nREGISTER ACCESS ANALYSIS:")
        print("-" * 40)
        
        # Filter for register access messages
        reg_access = df[df['message type'].str.contains('MDIO', na=False)]
        if not reg_access.empty:
            # Group by page and register
            page_reg_counts = reg_access.groupby(['page', 'register']).size().sort_values(ascending=False)
            
            print("Most accessed page/register combinations:")
            for (page, reg), count in page_reg_counts.head(10).items():
                print(f"  Page {page}, Register {reg}: {count} accesses")
        
        print("\nSTATUS PACKET ANALYSIS:")
        print("-" * 40)
        status_packets = df[df['message type'].str.contains('Status Packet', na=False)]
        
        if not status_packets.empty:
            print(f"Total status packets: {len(status_packets)}")
            
            # Look for meaningful details
            detailed_status = status_packets[status_packets['details'].notna() & (status_packets['details'] != '')]
            if not detailed_status.empty:
                print("\nStatus packet details found:")
                for idx, row in detailed_status.head(5).iterrows():
                    print(f"  {row['Time']}: {row['details']}")
        
        print("\n" + "="*80)
        
    except Exception as e:
        print(f"Error reading CSV file: {e}")
        print("Make sure the advanced parser has been run first.")

if __name__ == "__main__":
    display_parsed_smbus_data()