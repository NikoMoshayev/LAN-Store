import csv
import os

def parse_smbus_trace(input_file):
    """
    Advanced SMBus parser based on the provided SMBus_Parser_1.py
    Handles MDIO register access, status packets, and wake-up messages
    """
    
    curr_page = '0'
    filename = os.path.splitext(input_file)[0]
    
    # Open the input CSV file for reading
    with open(input_file, 'r') as myFile:
        myReader = csv.reader(myFile)
        myList = list(myReader)
    
    # Skip the first 8 rows (Total Phase header)
    myList = myList[8:]
    
    # Open the output CSV file for writing
    output_file = f'{filename}_After_Parsing.csv'
    with open(output_file, 'w', newline='') as f:
        after_parsing = csv.writer(f)
        
        # Write header to the output CSV file
        header = ["message number", "Time", "Duration", "address", "message direction", "message type", "page", "phy address",
                "register", "data", "details"]
        after_parsing.writerow(header)

        KNOWN_ADDRESSES = {'64', '70'}
        unexpected_addresses = set()
        
        # Process each row in the CSV file
        for myItem in myList:
            details = ""
            ptmac = 0
            mtphy = 0
            
            # Initialize the line with the first three columns of the current row
            line = [myItem[1], myItem[2], myItem[3]]

            addr = myItem[7].strip()
            addr_clean = addr.rstrip('*').upper()
            line.append(addr)

            if addr_clean not in KNOWN_ADDRESSES:
                unexpected_addresses.add(addr)

            # Determine the message direction
            if addr_clean == '70':
                line.append("PHY -> MAC")
                ptmac = 1
            elif addr_clean not in KNOWN_ADDRESSES:
                nak_suffix = " (NAK)" if addr.endswith('*') else ""
                line.append(f"Addr 0x{addr_clean}{nak_suffix}")
                mtphy = 1
            else:
                line.append("MAC -> PHY (0x64, 0x70)")
                mtphy = 1
            
            # Process the data field
            data = myItem[9]
            big_endian = data.split()
            
            # Check for the length of big_endian and handle accordingly
            if len(big_endian) != 7:
                if len(big_endian) < 4:
                    line.extend(["", "", "", "", "", "", myItem[8] + ":" + myItem[9]])
                    after_parsing.writerow(line)
                    continue
                
                little_endian = tuple(big_endian[3] + big_endian[2] + big_endian[1] + big_endian[0])
                
                # Check if the message is a "Wake up Message"
                if big_endian[0] == "D5":
                    line.append("Wake up Message")
                    line.extend(["", "", "", ""])
                    
                    bin_data = str(bin(int(little_endian[0], 16))) + str(bin(int(little_endian[1], 16))) + str(bin(int(little_endian[2], 16))) \
                               + str(bin(int(little_endian[3], 16))) + str(bin(int(little_endian[4], 16))) + str(bin(int(little_endian[5], 16))) \
                               + str(bin(int(little_endian[6], 16))) + str(bin(int(little_endian[7], 16)))
                    bin_data = bin_data.split("0b")
                    bin_data = bin_data[1:]
                    
                    # Pad binary data to ensure correct length
                    for num in range(0, 8):
                        for num_2 in range(0, 4 - len(bin_data[num])):
                            bin_data[num] = str("0" + bin_data[num])
                    
                    tmp_data = bin_data[0]
                    for num in range(1, 8):
                        tmp_data = tmp_data + bin_data[num]
                    
                    bin_data = tuple(tmp_data)
                    imp_data = bin_data[8:16]
                    
                    # Determine wake-up indication based on binary data
                    if imp_data[7] == '1':
                        line.append("Host wake-up indication")
                    elif imp_data[6] == '1':
                        line.append("Me wakeup indication")
                    after_parsing.writerow(line)
                    continue
            
            # Process for messages other than "Wake up Message"
            little_endian = tuple(big_endian[6] + big_endian[5] + big_endian[4] + big_endian[3] + big_endian[2] + big_endian[1] + big_endian[0])
            bin_data = str(bin(int(little_endian[0], 16))) + str(bin(int(little_endian[1], 16))) + str(bin(int(little_endian[2], 16))) \
                       + str(bin(int(little_endian[3], 16))) + str(bin(int(little_endian[4], 16))) + str(bin(int(little_endian[5], 16))) \
                       + str(bin(int(little_endian[6], 16))) + str(bin(int(little_endian[7], 16))) + str(bin(int(little_endian[8], 16))) \
                       + str(bin(int(little_endian[9], 16))) + str(bin(int(little_endian[10], 16))) + str(bin(int(little_endian[11], 16))) \
                       + str(bin(int(little_endian[12], 16))) + str(bin(int(little_endian[13], 16)))
            bin_data = bin_data.split("0b")
            bin_data = bin_data[1:]
            
            # Pad binary data to ensure correct length
            for num in range(0, 14):
                for num_2 in range(0, 4 - len(bin_data[num])):
                    bin_data[num] = str("0" + bin_data[num])
            
            tmp_data = bin_data[0]
            for num in range(1, 14):
                tmp_data = tmp_data + bin_data[num]
            
            bin_data = tuple(tmp_data)
            imp_data = bin_data[8:40]
            reg_add_and_ctrl = imp_data[0:8]
            data_bytes = imp_data[8:24]
            phy_adress_arr = imp_data[27:32]
            
            # Determine MDIO register access message type and details
            if reg_add_and_ctrl[0] == '0':
                if reg_add_and_ctrl[1] == '0':
                    if reg_add_and_ctrl[2] == '1':
                        line.append("MDIO Write Request")
                    else:
                        line.append("MDIO Read Request")
                else:
                    if reg_add_and_ctrl[2] == '1':
                        line.append("MDIO Write Acknowledge")
                    else:
                        line.append("MDIO Read Response")
                
                # Calculate register address and PHY address
                reg_address = int(16 * int(reg_add_and_ctrl[3]) + 8 * int(reg_add_and_ctrl[4]) + 4 * int(reg_add_and_ctrl[5])
                                  + 2 * int(reg_add_and_ctrl[6]) + int(reg_add_and_ctrl[7]))
                phy_address = int(phy_adress_arr[0] + phy_adress_arr[1] + phy_adress_arr[2] + phy_adress_arr[3]
                                  + phy_adress_arr[4])
                
                if reg_address == 31 and phy_address == 1:
                    line.extend(["", "1", "31"])
                    page_check = data_bytes[0:11]
                    curr_page = '0'
                    
                    for num in range(0, 11):
                        curr_page = curr_page + page_check[num]
                    
                    line.append(str(data_bytes))
                    line.append("access to page " + str(int(curr_page, 2)))
                    after_parsing.writerow(line)
                    continue
                
                elif curr_page == '0':
                    line.append("")
                else:
                    line.append(str(int(curr_page, 2)))
                
                line.append(str(phy_address))
                line.append(str(reg_address))
                line.append(str(data_bytes))
                line.append("")
            
            else:
                # Determine status packet or acknowledge packet details
                if (ptmac == 1 and reg_add_and_ctrl[1] == '0') or (mtphy == 1 and reg_add_and_ctrl[1] == '1'):
                    if reg_add_and_ctrl[1] == '0':
                        line.append("Status Packet from PHY")
                    else:
                        line.append("Acknowledge Packet from the integrated LAN Controller")
                    
                    # Append details based on data bytes
                    if data_bytes[2] == '1':
                        details = details + "Inband Host Wol indication"
                    if data_bytes[3] == '1':
                        details = details + ",   RX in EEE LPI state"
                    else:
                        details = details + ",   RX Active"
                    if data_bytes[5] == '1':
                        details = details + ",   EI entry request"
                    if data_bytes[6] == '1':
                        details = details + ",   TX off (MAC back pressure required"
                    if data_bytes[7] == '1':
                        details = details + ",   K1 entry request"
                    if data_bytes[8] == '1':
                        details = details + ",   Reset complete"
                    if data_bytes[9] == '1':
                        details = details + ",   Interrupt request"
                    if data_bytes[10] == '1':
                        details = details + ",   Link up"
                    else:
                        details = details + ",   Link down"
                    if data_bytes[11] == '1':
                        details = details + ",   PHY cable disconnected"
                    if data_bytes[12] == '1':
                        details = details + ",   Link up"
                    else:
                        details = details + ",   Link down"
                    if data_bytes[13] == '1':
                        details = details + ",   Full Duplex"
                    else:
                        details = details + ",   Half Duplex"
                    if data_bytes[14] == '0':
                        if data_bytes[15] == '0':
                            details = details + ",   10 Mb/s"
                        else:
                            details = details + ",   100 Mb/s"
                    else:
                        if data_bytes[15] == '0':
                            details = details + ",   1000 Mb/s"
                elif (mtphy == 1 and reg_add_and_ctrl[1] == '0') or (ptmac == 1 and reg_add_and_ctrl[1] == '1'):
                    if reg_add_and_ctrl[1] == '0':
                        line.append("Status Packet from Integrated LAN Controller")
                        if data_bytes[2] == '1':
                            details = details + "TX LPI Exit request"
                        if data_bytes[3] == '1':
                            details = details + ",   TX LPI Entry request"
                        if data_bytes[4] == '1':
                            details = details + ",   XON request"
                        if data_bytes[5] == '1':
                            details = details + ",   EI entry request"
                        if data_bytes[6] == '1':
                            details = details + ",   XOFF request"
                        if data_bytes[7] == '1':
                            details = details + ",   K1 entry request"
                        if data_bytes[8] == '1':
                            details = details + ",   Port reset"
                        if data_bytes[9] == '1':
                            details = details + ",   Power down"
                        if data_bytes[15] == '1':
                            details = details + ",   PINSTOP: Clear the LANWAKE# pin"
                    else:
                        line.append("Acknowledge Packet from the PHY")
                        details = ""
                
                line.extend(["", "", "", "", str(details)])
            
            # Write the processed line to the output CSV file
            after_parsing.writerow(line)
    
    if unexpected_addresses:
        print(f"\n*** WARNING: Unexpected SMBus addresses detected: {', '.join('0x' + a for a in sorted(unexpected_addresses))} ***")
        print("Expected addresses are 0x64 (MAC->PHY) and 0x70 (PHY->MAC) only.")

    print(f"Advanced parsing complete! Output saved to: {output_file}")
    return output_file, unexpected_addresses

if __name__ == "__main__":
    # Default to the trace file we've been using
    input_file = "SMBUS_Trace.csv"
    
    # Check if file exists
    if not os.path.exists(input_file):
        # Prompt user for the input CSV file path
        input_file = input("Please enter the name of csv file: ").strip('"')
    
    if os.path.exists(input_file):
        output_file = parse_smbus_trace(input_file)
        print(f"\nParsed file created: {output_file}")
        print("\nThis parser provides detailed SMBus protocol analysis including:")
        print("- MDIO register access messages (read/write requests/responses)")
        print("- Status packets from PHY with link state, speed, duplex info")
        print("- Acknowledge packets from LAN Controller")
        print("- Wake-up messages with host/ME indications")
        print("- Page access tracking for extended registers")
    else:
        print(f"Error: File '{input_file}' not found!")