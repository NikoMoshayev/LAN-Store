@echo off
REM ================================================================
REM SMBus Parser - Portable Application Launcher
REM ================================================================
REM This batch file launches the SMBus Parser application
REM Automatically finds Python installation on the system
REM ================================================================

echo.
echo ================================================
echo    SMBus Parser - Jacksonville PHY Analyzer
echo ================================================
echo.

REM Check for Python in PATH
python --version >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Python found in PATH
    python main_app.py
    goto :end
)

REM Check common Python installation paths
set PYTHON_PATHS=^
    "C:\Program Files\Python314\python.exe" ^
    "C:\Program Files\Python313\python.exe" ^
    "C:\Program Files\Python312\python.exe" ^
    "C:\Program Files\Python311\python.exe" ^
    "C:\Program Files\Python310\python.exe" ^
    "C:\Python314\python.exe" ^
    "C:\Python313\python.exe" ^
    "C:\Python312\python.exe" ^
    "C:\Python311\python.exe" ^
    "C:\Python310\python.exe" ^
    "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" ^
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" ^
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" ^
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" ^
    "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"

for %%P in (%PYTHON_PATHS%) do (
    if exist %%P (
        echo [OK] Python found at %%P
        %%P main_app.py
        goto :end
    )
)

REM Python not found
echo [ERROR] Python not found on this system!
echo.
echo Please install Python 3.8 or later from:
echo https://www.python.org/downloads/
echo.
echo Make sure to check "Add Python to PATH" during installation
echo.
pause
goto :end

:end
REM Keep window open if there was an error
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Application exited with error code %errorlevel%
    pause
)
