"""Test the debug analyzer against the real trace"""
import sys, csv, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'SRC'))
from debug_analyzer import parse_smbus_csv, analyze_trace

trace = r'C:\Users\michaele\Downloads\NVLS_SMBUS_Trace_CableDisconnected_Restart_10Itr_Pass.csv'
if not os.path.exists(trace):
    print("Trace file not found")
    sys.exit(1)

try:
    results = analyze_trace(trace)
    print("analyze_trace OK")
    total = results['total_transactions']
    print(f"  Total transactions: {total}")
    issues = results['issues']
    print(f"  Issues: {len(issues)}")
    for iss in issues:
        print(f"    - [{iss.get('severity','?')}] {iss.get('type','?')}: {iss.get('note','')}")
    warnings = results['warnings']
    print(f"  Warnings: {len(warnings)}")
    for w in warnings[:5]:
        print(f"    - {w.get('type','?')}: {w.get('message','')}")
    link_hist = results['link_status_history']
    print(f"  Link history: {len(link_hist)} entries")
    if link_hist:
        first = link_hist[0]
        last = link_hist[-1]
        print(f"    First: link={first['link']}, speed={first['speed']}, cable={first['cable_disconnected']}")
        print(f"    Last:  link={last['link']}, speed={last['speed']}, cable={last['cable_disconnected']}")
    pages = results['page_accesses']
    print(f"  Page accesses: {pages}")
    print(f"  Wake events: {len(results['wake_events'])}")
    print(f"  NACK periods: {len(results['nack_periods'])}")
    print(f"  Reset events: {len(results['reset_events'])}")
except Exception as e:
    import traceback
    print(f"ERROR: {e}")
    traceback.print_exc()
