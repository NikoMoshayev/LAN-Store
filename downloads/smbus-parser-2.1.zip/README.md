# SMBus Parser - Portable Edition

**Jacksonville PHY SMBus Trace Analyzer**  
**Version**: 2.1 with Context-Aware Validation and CSV Pre-Check  
**Date**: February 1, 2026

---

## 📦 Quick Start

### Option 1: Windows Batch File (Easiest)
1. Copy the entire `SMBUS_PARSER_PORTABLE` folder to any Windows PC
2. Double-click **`RUN_APP.bat`**
3. The application will automatically find Python and launch

### Option 2: Direct Python Command
```cmd
python main_app.py
```

### Option 3: Command Line
```cmd
cd SMBUS_PARSER_PORTABLE
python main_app.py
```

---

## 🔧 System Requirements

### Required:
- **Operating System**: Windows 7/8/10/11 (64-bit recommended)
- **Python**: Version 3.8 or later
- **RAM**: 512 MB minimum (2 GB recommended for large traces)
- **Disk Space**: 50 MB

### Python Installation:
If Python is not installed:
1. Download from https://www.python.org/downloads/
2. Run installer
3. ✅ **IMPORTANT**: Check "Add Python to PATH" during installation
4. Click "Install Now"

### Verify Python Installation:
```cmd
python --version
```
Should display: `Python 3.x.x`

---

## 📁 Folder Structure

```
SMBUS_PARSER_PORTABLE/
├── RUN_APP.bat              ← Double-click to launch (Windows)
├── main_app.py              ← Main application entry point
├── requirements.txt         ← Python dependencies (none required!)
├── README.md                ← This file
├── USER_GUIDE.md            ← Detailed usage instructions
└── SRC/                     ← Source code modules
    ├── lightweight_analyzer.py   ← Main trace analyzer
    ├── debug_analyzer.py         ← Debug analysis with validation
    ├── phy_definitions.py        ← PHY register definitions
    └── (other modules...)
```

---

## 📖 Features

### Lightweight Analyzer
- **Fast CSV parsing** - Processes 10,000+ transactions per second
- **Event detection** - 30+ PHY event types (Reset, AN, Link, Speed, ULP, WOL)
- **HTML reports** - Visual timeline with color-coded events
- **Register decoding** - Bit-level field interpretation
- **Transaction filtering** - Filter by register, page, value

### Debug Analyzer (NEW)
- **Context-aware validation** - Detects Active vs S-State operation
- **Intelligent WOL validation** - Cable-aware Magic Packet checks
- **PHY capability detection** - Reads hardware support from registers
- **Comprehensive specs** - Jacksonville EAS 1.12, Clarksville T-Spec
- **No false positives** - Smart validation eliminates incorrect warnings

### UI Features
- **VS Code dark theme** - Professional color scheme
- **CSV pre-check** - Confirms the selected trace looks parseable before analysis
- **Global search** - Searches line, time, direction, raw bytes, data values, pages, registers, events, and message types
- **Quick filters** - Narrow traffic to wake messages, NACKs, MDIO config, reads/writes, page selects, or direction
- **Dual-pane layout** - Transaction list + register details
- **Copy to clipboard** - Export formatted data
- **Sort by column** - Click headers to sort
- **Progress indicators** - Real-time parsing feedback

---

## 🚀 Usage

### 1. Launch Application
Double-click `RUN_APP.bat` or run `python main_app.py`

### 2. Load CSV File
- Click **"Browse"** button
- Select your SMBus trace CSV file
- Review the file summary shown under the selected path
- Click **"Open Analyzer"**

The launcher checks the CSV before opening the analyzer. It reports recognized transactions, MDIO/status/NACK counts, observed SMBus addresses, and the visible time range. If the wrong file is selected, the launcher explains what is missing before the analyzer opens.

### 3. Analyze Results
- **Main View Tab**: See all transactions with register details
- **Events Tab**: Color-coded PHY events timeline
- **Debug Analyzer Tab**: Open detailed validation window
- Use **Search** for values like `0x001F`, raw SMBus bytes, register names, line numbers, wake events, or timestamps
- Use **Filter** for common trace views such as NACK/no response, wake messages, page selects, config reads/writes, and MAC/PHY direction

### 4. Debug Analysis (Advanced)
- Click **"Open Debug Analyzer"**
- View 4 tabs:
  - **Link Status**: Cable connection, speed changes over time
  - **Register Analysis**: Bit-level validation against specs
  - **Flow Detection**: Loopback, packet generator detection
  - **Register Access**: Statistics (read/write counts)

---

## 📋 CSV File Format

The application expects CSV files with SMBus transaction data:

```csv
Line,Time,S,Addr,Rd/Wr,Hex Data,ACK/NAK,Dec Data,ASCII
1,0:00.003.456,S,20,Wr,[D1 1B 14 00],ACK,,
2,0:00.003.789,S,20,Wr,[D1 00 11 40],ACK,,
```

**Required Columns**:
- `Line`: Transaction line number
- `Time`: Timestamp (format: `M:SS.mmm.uuu`)
- `S`: Start condition indicator
- `Addr`: SMBus address (hex)
- `Rd/Wr`: Read or Write operation
- `Hex Data`: Data bytes in brackets `[XX XX XX]`
- `ACK/NAK`: Acknowledgment status

---

## 🔍 Supported Register Pages

- **Page 0**: IEEE 802.3 standard registers (Control, Status, PHY ID, AN)
- **Page 1**: Extended IEEE 802.3 registers
- **Page 768**: External MDIO registers
- **Page 769**: Port control registers (MACPD, Wake enables, SMBus)
- **Page 770**: Kumeran registers (PCIe PM, K1, inband messaging)
- **Page 771**: Kumeran registers (additional controls)
- **Page 772**: Kumeran configuration registers (LPI/EEE configuration)
- **Page 774**: Kumeran BER meter registers
- **Page 776**: General registers (energy detect, capabilities)
- **Page 779**: ULP registers (Ultra Low Power mode)
- **Page 781**: SKU control registers
- **Page 800**: WOL registers (Wake-on-LAN configuration)
- **Page 801**: WOL registers (reserved/placeholder definitions)

---

## 🐛 Troubleshooting

### Application won't start
**Problem**: Double-clicking `RUN_APP.bat` does nothing  
**Solution**:
1. Open Command Prompt
2. Navigate to folder: `cd C:\path\to\SMBUS_PARSER_PORTABLE`
3. Run: `python main_app.py`
4. Check error messages

### Python not found
**Problem**: Error "Python is not recognized"  
**Solution**:
1. Verify Python is installed: `python --version`
2. If not found, install Python from https://www.python.org/
3. During installation, check "Add Python to PATH"
4. Restart Command Prompt after installation

### Tkinter missing
**Problem**: Error "No module named 'tkinter'"  
**Solution**:
1. Reinstall Python
2. In installer, click "Modify"
3. Check "tcl/tk and IDLE"
4. Click "Install"

### CSV file won't load
**Problem**: Error when loading CSV  
**Solution**:
1. Verify CSV format matches expected columns
2. Check for special characters in file path
3. Try copying CSV to same folder as `main_app.py`
4. Open CSV in text editor to verify format

### Application freezes
**Problem**: UI becomes unresponsive  
**Solution**:
1. Large files (>50,000 transactions) may take time
2. Wait for progress bar to complete
3. Try parsing smaller trace section first
4. Close other applications to free RAM

---

## 📊 Performance Tips

### For Large Traces (>100,000 transactions):
1. **Filter before parsing**: Use external tools to extract relevant sections
2. **Close other programs**: Free up RAM
3. **Use Debug Analyzer selectively**: Only open when needed
4. **Export to HTML**: Generate report, then close GUI

### Optimize Analysis:
1. **Focus on specific pages**: Filter by page number
2. **Search specific registers**: Use register filter
3. **Export results**: Save to HTML for offline review

---

## 🆘 Support

### Documentation:
- **USER_GUIDE.md**: Detailed feature documentation
- **PHY_REGISTER_AUDIT_REPORT.md**: Complete register reference

### Issues:
If you encounter bugs or issues:
1. Note the error message
2. Check Python version: `python --version`
3. Verify CSV file format
4. Try with sample CSV file

### Contact:
For support, provide:
- Python version
- Windows version
- Error message (full text)
- Sample CSV file (if possible)

---

## 📜 Version History

### Version 2.0 (February 1, 2026)
- ✅ Context-aware validation (Active/S-State detection)
- ✅ PHY capability detection
- ✅ Cable-aware WOL validation
- ✅ Eliminated false positives
- ✅ Enhanced UI with bold borders
- ✅ Hex-only register display format
- ✅ Comprehensive spec integration (Jacksonville EAS 1.12)

### Version 1.5 (January 2026)
- Added Debug Analyzer with 4 tabs
- Enhanced event detection (30+ event types)
- HTML report generation
- VS Code dark theme

### Version 1.0 (December 2025)
- Initial release
- Basic CSV parsing
- Register decoding
- Event timeline

---

## 📄 License

Internal Intel Corporation tool for PHY validation and debugging.  
**Not for external distribution.**

---

## 🎯 Quick Reference

### Keyboard Shortcuts:
- **Ctrl+O**: Open file browser
- **Ctrl+C**: Copy selected transaction
- **F5**: Refresh analysis
- **Esc**: Close dialog

### Common Tasks:
1. **Find Reset Events**: Click "Events" tab → Look for "PHY_RESET"
2. **Check Link Status**: Open Debug Analyzer → "Link Status" tab
3. **Validate WOL**: Debug Analyzer → "Register Analysis" tab → Page 800
4. **Check Power Down**: Search for Page 0, Register 0, Bit 11

### Color Coding:
- 🟢 **Green**: Success, Pass, Normal operation
- 🔴 **Red**: Error, Fail, Critical issue
- 🟡 **Yellow**: Warning, Attention needed
- 🔵 **Blue**: Info, Status message
- ⚪ **White**: Unknown, Not validated

---

**Ready to analyze SMBus traces!**  
Double-click `RUN_APP.bat` to start.
