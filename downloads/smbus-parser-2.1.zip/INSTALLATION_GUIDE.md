# SMBus Parser - Installation & Setup Guide

## 🚀 Deployment Instructions

### For the Current PC (Where files already exist):
The application is already set up and running. Use this portable version to copy to other PCs.

### For Another PC (Target machine):

#### Step 1: Copy Files
1. Copy the entire **`SMBUS_PARSER_PORTABLE`** folder to the target PC
2. Recommended locations:
   - Desktop: `C:\Users\<username>\Desktop\SMBUS_PARSER_PORTABLE`
   - Documents: `C:\Users\<username>\Documents\SMBUS_PARSER_PORTABLE`
   - Any folder without special characters in path

#### Step 2: Install Python (if not already installed)
1. Go to https://www.python.org/downloads/
2. Download Python 3.8 or later (3.14 recommended)
3. Run the installer
4. ✅ **CRITICAL**: Check **"Add Python to PATH"** checkbox
5. Click "Install Now"
6. Wait for installation to complete
7. Verify installation:
   ```cmd
   python --version
   ```
   Should display: `Python 3.x.x`

#### Step 3: Launch Application
**Method A** - Double-click launcher (Easiest):
1. Navigate to the `SMBUS_PARSER_PORTABLE` folder
2. Double-click **`RUN_APP.bat`**
3. Application will automatically find Python and launch

**Method B** - Command line:
1. Open Command Prompt (Win+R, type `cmd`, press Enter)
2. Navigate to folder:
   ```cmd
   cd C:\path\to\SMBUS_PARSER_PORTABLE
   ```
3. Run:
   ```cmd
   python main_app.py
   ```

#### Step 4: Verify Installation
1. Application window should open with "SMBus Trace Analyzer" title
2. Click "Browse" button to test file selection
3. Try loading a CSV file to verify parsing works

---

## 🔧 What's Included

### Core Files (Required):
```
SMBUS_PARSER_PORTABLE/
├── RUN_APP.bat                    ← Launch script (Windows)
├── main_app.py                    ← Main application
├── requirements.txt               ← Dependency info
├── README.md                      ← User guide
└── SRC/                           ← Source code folder
    ├── lightweight_analyzer.py    ← Main parser
    ├── debug_analyzer.py          ← Advanced validation
    ├── phy_definitions.py         ← Register definitions
    └── (other support modules)
```

### Dependencies:
**None!** - This application uses only Python standard library.

The following modules are built into Python:
- `tkinter` - GUI framework (included with Windows Python)
- `csv` - CSV file parsing
- `datetime` - Timestamp handling
- `re` - Regular expressions
- `os` - File system operations
- `collections` - Data structures

---

## 📋 System Requirements

### Minimum:
- **OS**: Windows 7/8/10/11 (64-bit)
- **Python**: 3.8 or later
- **CPU**: Any modern processor (Intel Core i3 or equivalent)
- **RAM**: 512 MB available
- **Disk**: 50 MB for application + space for CSV files

### Recommended:
- **OS**: Windows 10/11 (64-bit)
- **Python**: 3.14 (latest stable)
- **CPU**: Intel Core i5 or better
- **RAM**: 2 GB available (for large traces)
- **Disk**: 500 MB (for reports and temp files)
- **Screen**: 1920x1080 or higher resolution

---

## 🎯 Network/USB Drive Deployment

### Scenario: Deploy from Network Share
1. Copy folder to network location:
   ```
   \\server\share\Tools\SMBUS_PARSER_PORTABLE
   ```
2. Users can run directly from network:
   ```cmd
   \\server\share\Tools\SMBUS_PARSER_PORTABLE\RUN_APP.bat
   ```
3. Or copy to local drive for better performance

### Scenario: USB Drive Deployment
1. Copy `SMBUS_PARSER_PORTABLE` folder to USB drive
2. Plug USB into target PC
3. Navigate to `E:\SMBUS_PARSER_PORTABLE` (or USB drive letter)
4. Double-click `RUN_APP.bat`
5. Works without installation!

### Scenario: Email Deployment
1. **Warning**: Folder is ~2 MB (safe for email)
2. Zip the `SMBUS_PARSER_PORTABLE` folder:
   - Right-click folder → Send to → Compressed (zipped) folder
3. Email the .zip file
4. Recipient extracts and runs `RUN_APP.bat`

---

## 🔍 Verification Checklist

After copying to a new PC, verify:

- [ ] All files copied correctly (check SRC folder exists)
- [ ] Python 3.8+ is installed (`python --version`)
- [ ] Python is in PATH (can run `python` from any folder)
- [ ] Tkinter is available (included with Python on Windows)
- [ ] `RUN_APP.bat` launches without errors
- [ ] Application window opens with UI
- [ ] Can browse and select CSV files
- [ ] Sample CSV file parses successfully
- [ ] Debug Analyzer opens without errors

---

## 🐛 Troubleshooting Common Issues

### Issue: "Python is not recognized as an internal or external command"
**Cause**: Python not in system PATH  
**Solution**:
1. Option A: Reinstall Python with "Add to PATH" checked
2. Option B: Add Python manually to PATH:
   - Right-click "This PC" → Properties → Advanced System Settings
   - Click "Environment Variables"
   - Under "System variables", find "Path"
   - Click "Edit" → "New"
   - Add: `C:\Program Files\Python314` (or your Python path)
   - Add: `C:\Program Files\Python314\Scripts`
   - Click OK on all dialogs
   - Restart Command Prompt

### Issue: "No module named 'tkinter'"
**Cause**: Tkinter not installed with Python  
**Solution**:
1. Reinstall Python
2. In installer, click "Modify"
3. Ensure "tcl/tk and IDLE" is checked
4. Click "Install"
5. Restart application

### Issue: Application window is blank or corrupted
**Cause**: Graphics driver or DPI scaling issue  
**Solution**:
1. Right-click `main_app.py` → Properties → Compatibility
2. Check "Disable display scaling on high DPI settings"
3. Click OK and relaunch

### Issue: CSV file fails to parse
**Cause**: Incorrect CSV format or encoding  
**Solution**:
1. Open CSV in Notepad to verify format
2. Ensure UTF-8 encoding
3. Check column headers match expected format
4. Try parsing a smaller section first

### Issue: Application is slow with large files
**Cause**: Large trace files (>100,000 transactions)  
**Solution**:
1. Close other applications to free RAM
2. Use external tools to filter CSV first
3. Parse only relevant time range
4. Consider upgrading RAM if working with large traces regularly

---

## 📦 Portable vs. Installed Comparison

### Portable Version (This Package):
✅ **Pros**:
- No installation required
- Copy to any PC
- Run from USB drive
- No admin rights needed (if Python already installed)
- No registry changes
- Easy to update (just replace files)
- Multiple versions can coexist

❌ **Cons**:
- Requires Python pre-installed on target PC
- No desktop shortcut (can create manually)
- No file association (.csv files)
- No auto-updates

### When to Use Portable:
- Testing on multiple PCs
- Lab/validation environment
- Temporary analysis tasks
- No admin access
- USB drive deployment
- Quick sharing with colleagues

---

## 🔐 Security Considerations

### Safe to Deploy:
- ✅ Pure Python code (source visible)
- ✅ No external dependencies
- ✅ No network access
- ✅ No registry modifications
- ✅ No system file changes
- ✅ Reads/writes only in app folder

### IT Department Approval:
If your IT requires approval:
1. **Language**: Python (interpreted, not compiled)
2. **Dependencies**: None (uses standard library only)
3. **Network**: No network access
4. **Privileges**: Runs as normal user (no admin needed)
5. **Installation**: Portable (no installer)
6. **Vendor**: Intel internal tool

---

## 📝 Creating Desktop Shortcut (Optional)

### On Target PC:
1. Right-click `RUN_APP.bat`
2. Click "Create shortcut"
3. Drag shortcut to Desktop
4. Right-click shortcut → Properties
5. Change icon if desired (optional)
6. Click OK

---

## 🔄 Updating the Application

### To Update:
1. Copy new `SMBUS_PARSER_PORTABLE` folder
2. Option A: Delete old folder, use new one
3. Option B: Rename old folder (keep as backup), use new one

### Version Checking:
- Check `README.md` for version number
- Look for version in application title bar
- Check `main_app.py` docstring for version info

---

## 📞 Support

### Self-Help Resources:
1. Read `README.md` (user guide)
2. Check `PHY_REGISTER_AUDIT_REPORT.md` (register reference)
3. View source code comments in `SRC/` folder
4. Search Python documentation for tkinter issues

### Internal Support:
Contact the tool developer or your team's PHY validation lead.

---

## ✅ Final Checklist

Before distributing to another PC:

- [ ] Verify all files copied to `SMBUS_PARSER_PORTABLE` folder
- [ ] Test `RUN_APP.bat` on source PC
- [ ] Create README with Python installation link
- [ ] Include sample CSV file for testing (optional)
- [ ] Document any special configuration needed
- [ ] Note Python version compatibility (3.8+)
- [ ] Test on target PC if possible
- [ ] Provide contact info for support

---

**Ready to Deploy!**  
Copy the `SMBUS_PARSER_PORTABLE` folder to any Windows PC with Python 3.8+.
