import csv
import os
from phy_definitions import get_register_info, SMBUS_STATUS_BITS, format_register_display

MAC_TO_PHY_DIRECTION = "MAC -> PHY (0x64, 0x70)"
PHY_TO_MAC_DIRECTION = "PHY -> MAC"

def analyze_smbus_with_full_details(filename="SMBUS_Trace.csv"):
    """
    Advanced SMBus analyzer with complete register and bit-level information
    """
    
    if not os.path.exists(filename):
        print(f"Error: File '{filename}' not found!")
        return
    
    print("=" * 100)
    print("JACKSONVILLE PHY SMBUS PROTOCOL ANALYZER - COMPLETE ANALYSIS")
    print("=" * 100)
    
    transactions = []
    curr_page = 0
    
    # Parse the trace file
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        data = list(reader)[8:]  # Skip Total Phase header
        
        for i, row in enumerate(data):
            if len(row) < 10:
                continue
                
            trans = parse_smbus_transaction(row, i + 1, curr_page)
            
            # Update page tracking for register 31 accesses
            if trans.get('register') == 31 and 'page_access' in trans:
                curr_page = trans['page_access']
                
            transactions.append(trans)
    
    # Display summary
    display_analysis_summary(transactions)
    
    # Display detailed transaction analysis
    display_detailed_transactions(transactions)
    
    # Display register usage analysis
    display_register_usage(transactions)
    
    # Display bit-level analysis
    display_bit_level_analysis(transactions)
    
    return transactions

def parse_smbus_transaction(row, index, current_page):
    """Parse a single SMBus transaction with complete decoding"""
    
    trans = {
        'index': index,
        'time': row[2],
        'duration': row[3],
        'direction': PHY_TO_MAC_DIRECTION if row[7] == '70' else MAC_TO_PHY_DIRECTION,
        'raw_data': row[9].split(),
        'page': None,
        'register': None,
        'register_name': None,
        'data_value': None,
        'bit_analysis': [],
        'message_type': 'Unknown'
    }
    
    try:
        if len(trans['raw_data']) == 7:
            # Standard MDIO message
            decoded = decode_mdio_message(trans['raw_data'], current_page)
            trans.update(decoded)
            
        elif len(trans['raw_data']) == 4:
            # Status or wake message
            decoded = decode_status_message(trans['raw_data'], trans['direction'])
            trans.update(decoded)
            
    except Exception as e:
        trans['message_type'] = f'Parse Error: {str(e)}'
    
    return trans

def decode_mdio_message(data_bytes, current_page):
    """Decode MDIO register access with full bit analysis"""
    
    # Convert hex bytes to binary
    little_endian = ''.join(data_bytes[::-1])
    hex_value = int(little_endian, 16)
    bin_data = format(hex_value, '056b')
    
    # Extract protocol fields
    reg_ctrl = bin_data[8:16]
    data_field = bin_data[16:32]  
    phy_addr_bits = bin_data[35:40]
    
    # Decode message type
    if reg_ctrl[0] == '0':
        if reg_ctrl[1] == '0':
            msg_type = 'Write Request' if reg_ctrl[2] == '1' else 'Read Request'
        else:
            msg_type = 'Write Acknowledge' if reg_ctrl[2] == '1' else 'Read Response'
    else:
        msg_type = 'Status/Control Packet'
    
    # Extract addresses and data
    reg_addr = int(reg_ctrl[3:], 2)
    phy_addr = int(phy_addr_bits, 2)
    data_value = int(data_field, 2)
    
    # Handle page access (register 31)
    if reg_addr == 31:
        page_value = int(data_field[:11], 2)
        return {
            'message_type': f'MDIO {msg_type}',
            'page': None,
            'register': reg_addr,
            'register_name': 'Page Select Register',
            'data_value': data_value,
            'page_access': page_value,
            'bit_analysis': [f"Page Access: {page_value}"],
            'binary_data': data_field
        }
    
    # Get register definition
    reg_info = get_register_info(current_page, reg_addr)
    
    # Perform detailed bit analysis
    bit_analysis = []
    active_bits = []
    
    for bit_pos in range(16):
        bit_value = (data_value >> bit_pos) & 1
        bit_name = reg_info['bits'].get(bit_pos, f'Bit {bit_pos}')
        
        if bit_value:
            bit_analysis.append(f"Bit {bit_pos:2d}: {bit_name} = 1")
            active_bits.append(bit_pos)
        else:
            bit_analysis.append(f"Bit {bit_pos:2d}: {bit_name} = 0")
    
    return {
        'message_type': f'MDIO {msg_type}',
        'page': current_page,
        'register': reg_addr,
        'register_name': reg_info['name'],
        'data_value': data_value,
        'bit_analysis': bit_analysis,
        'active_bits': active_bits,
        'binary_data': data_field
    }

def decode_status_message(data_bytes, direction):
    """Decode status/control messages with bit details"""
    
    if data_bytes[0] == 'D5':
        return {
            'message_type': 'Wake-up Message',
            'bit_analysis': ['Wake-up indication detected'],
            'status_info': 'System wake-up event'
        }
    
    # Parse status packet
    little_endian = ''.join(data_bytes[::-1])
    hex_value = int(little_endian, 16)
    bin_data = format(hex_value, '032b')
    
    status_bits = SMBUS_STATUS_BITS.get(
        'phy_to_mac' if direction == 'PHY -> MAC' else 'mac_to_phy', {}
    )
    
    bit_analysis = []
    status_info = []
    
    for bit_pos, description in status_bits.items():
        if bit_pos < len(bin_data):
            bit_value = bin_data[-(bit_pos+1)]
            bit_analysis.append(f"Bit {bit_pos:2d}: {description} = {bit_value}")
            if bit_value == '1':
                status_info.append(description)
    
    return {
        'message_type': f'Status Packet ({direction})',
        'bit_analysis': bit_analysis,
        'status_info': status_info,
        'binary_data': bin_data
    }

def display_analysis_summary(transactions):
    """Display comprehensive analysis summary"""
    
    print("\nANALYSIS SUMMARY")
    print("=" * 50)
    
    total = len(transactions)
    mdio_count = len([t for t in transactions if 'MDIO' in t['message_type']])
    status_count = len([t for t in transactions if 'Status' in t['message_type']])
    wake_count = len([t for t in transactions if 'Wake' in t['message_type']])
    
    print(f"Total Transactions: {total}")
    print(f"MDIO Messages: {mdio_count}")
    print(f"Status Messages: {status_count}")
    print(f"Wake Messages: {wake_count}")
    print()
    
    print("COMMUNICATION BREAKDOWN:")
    mac_to_phy = len([t for t in transactions if t['direction'] == MAC_TO_PHY_DIRECTION])
    phy_to_mac = len([t for t in transactions if t['direction'] == PHY_TO_MAC_DIRECTION])
    print(f"MAC -> PHY (0x64, 0x70): {mac_to_phy}")
    print(f"PHY -> MAC: {phy_to_mac}")
    print()
    
    # Register access summary
    print("TOP ACCESSED REGISTERS:")
    reg_counts = {}
    for t in transactions:
        if t.get('page') is not None and t.get('register') is not None:
            key = (t['page'], t['register'], t.get('register_name', 'Unknown'))
            reg_counts[key] = reg_counts.get(key, 0) + 1
    
    for (page, reg, name), count in sorted(reg_counts.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"  Page {page}, Reg 0x{reg:02X} ({name}): {count} accesses")

def display_detailed_transactions(transactions):
    """Display first 10 transactions with full details"""
    
    print("\n" + "=" * 100)
    print("DETAILED TRANSACTION ANALYSIS (First 10 Messages)")
    print("=" * 100)
    
    for i, trans in enumerate(transactions[:10]):
        print(f"\n[{trans['index']:3d}] {trans['time']} ({trans['duration']})")
        print(f"      Direction: {trans['direction']}")
        print(f"      Type: {trans['message_type']}")
        
        if trans.get('register') is not None and trans.get('page') is not None:
            register_display = format_register_display(
                trans.get('page'),
                trans.get('register'),
                trans.get('register_name', 'Unknown Register')
            )
            if register_display:
                print(f"      Register: {register_display}")
        elif trans.get('register') is not None:
            print(f"      Register: 0x{trans['register']:02X}")
            if trans.get('register_name'):
                print(f"      Register Name: {trans['register_name']}")
        if trans.get('data_value') is not None:
            print(f"      Data Value: 0x{trans['data_value']:04X} ({trans['data_value']})")
            print(f"      Binary: {trans['data_value']:016b}")
        
        if trans.get('active_bits'):
            print(f"      Active Bits: {trans['active_bits']}")
        
        if trans.get('status_info'):
            print(f"      Status: {', '.join(trans['status_info'])}")
            
        print(f"      Raw Data: {' '.join(trans['raw_data'])}")

def display_register_usage(transactions):
    """Display register usage patterns"""
    
    print("\n" + "=" * 100)
    print("REGISTER USAGE PATTERNS")
    print("=" * 100)
    
    # Group by register
    register_usage = {}
    for trans in transactions:
        if trans.get('register') is not None and trans.get('data_value') is not None:
            key = (trans.get('page', 0), trans['register'], trans.get('register_name', 'Unknown'))
            if key not in register_usage:
                register_usage[key] = {'values': set(), 'count': 0}
            register_usage[key]['values'].add(trans['data_value'])
            register_usage[key]['count'] += 1
    
    for (page, reg, name), info in register_usage.items():
        register_display = format_register_display(page, reg, name)
        print(f"\n{register_display}")
        print(f"  Access Count: {info['count']}")
        print(f"  Unique Values: {len(info['values'])}")
        
        for value in sorted(info['values']):
            reg_info = get_register_info(page, reg)
            print(f"    0x{value:04X} ({value:5d}) {value:016b}")
            
            # Show active bits for this value
            active_bits = []
            for bit_pos in range(16):
                if (value >> bit_pos) & 1:
                    bit_name = reg_info['bits'].get(bit_pos, f'Bit {bit_pos}')
                    active_bits.append(f"Bit{bit_pos:2d}")
            
            if active_bits:
                print(f"      Active: {', '.join(active_bits)}")

def display_bit_level_analysis(transactions):
    """Display bit-level analysis of all data"""
    
    print("\n" + "=" * 100)
    print("BIT-LEVEL ANALYSIS")
    print("=" * 100)
    
    # Collect bit usage statistics
    bit_stats = {}
    
    for trans in transactions:
        if trans.get('register') is not None and trans.get('data_value') is not None:
            reg_key = (trans.get('page', 0), trans['register'])
            if reg_key not in bit_stats:
                bit_stats[reg_key] = {i: {'set_count': 0, 'clear_count': 0} for i in range(16)}
            
            for bit_pos in range(16):
                if (trans['data_value'] >> bit_pos) & 1:
                    bit_stats[reg_key][bit_pos]['set_count'] += 1
                else:
                    bit_stats[reg_key][bit_pos]['clear_count'] += 1
    
    # Display statistics
    for (page, reg), bits in bit_stats.items():
        reg_info = get_register_info(page, reg)
        register_display = format_register_display(page, reg, reg_info['name'])
        print(f"\n{register_display}")
        print("  Bit | Name                           | Set | Clear | Description")
        print("  ----+--------------------------------+-----+-------+-------------")
        
        for bit_pos in range(15, -1, -1):  # Show MSB first
            bit_name = reg_info['bits'].get(bit_pos, f'Bit {bit_pos}')
            set_count = bits[bit_pos]['set_count']
            clear_count = bits[bit_pos]['clear_count']
            
            if set_count > 0 or clear_count > 0:  # Only show bits that were accessed
                print(f"  {bit_pos:2d}  | {bit_name[:30]:30} | {set_count:3d} | {clear_count:5d} |")

if __name__ == "__main__":
    print("Starting Jacksonville PHY SMBus Analysis...")
    transactions = analyze_smbus_with_full_details()
    print(f"\nAnalysis complete! Processed {len(transactions) if transactions else 0} transactions.")