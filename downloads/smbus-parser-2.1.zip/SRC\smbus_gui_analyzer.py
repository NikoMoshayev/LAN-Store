import csv
import tkinter as tk
from tkinter import ttk, scrolledtext
import os
from phy_definitions import get_register_info, SMBUS_STATUS_BITS, format_register_display

MAC_TO_PHY_DIRECTION = "MAC -> PHY (0x64, 0x70)"
PHY_TO_MAC_DIRECTION = "PHY -> MAC"
KNOWN_ADDRESSES = {'64', '70'}

class SMBusAnalyzerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Jacksonville PHY SMBus Protocol Analyzer")
        self.root.geometry("1200x800")
        
        # Create main frame
        main_frame = ttk.Frame(root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, text="Jacksonville PHY SMBus Protocol Analyzer", 
                               font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 20))
        
        # Warning banner (hidden by default)
        self.warning_frame = tk.Frame(main_frame, bg='#CC0000', padx=10, pady=8)
        self.warning_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        self.warning_label = tk.Label(self.warning_frame, text="", fg='white', bg='#CC0000',
                                      font=("Arial", 12, "bold"), wraplength=1100, justify=tk.LEFT)
        self.warning_label.pack(fill=tk.X)
        self.warning_frame.grid_remove()

        # Control frame
        control_frame = ttk.LabelFrame(main_frame, text="Analysis Control", padding="10")
        control_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))
        
        # File selection
        ttk.Label(control_frame, text="SMBus Trace File:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.file_var = tk.StringVar(value="SMBUS_Trace.csv")
        file_entry = ttk.Entry(control_frame, textvariable=self.file_var, width=30)
        file_entry.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=5)
        
        # Analyze button
        analyze_btn = ttk.Button(control_frame, text="Analyze Trace", command=self.analyze_trace)
        analyze_btn.grid(row=2, column=0, pady=10)
        
        # Summary frame
        summary_frame = ttk.LabelFrame(control_frame, text="Summary", padding="10")
        summary_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=10)
        
        self.summary_text = tk.Text(summary_frame, height=15, width=40, wrap=tk.WORD)
        scrollbar_summary = ttk.Scrollbar(summary_frame, orient=tk.VERTICAL, command=self.summary_text.yview)
        self.summary_text.configure(yscrollcommand=scrollbar_summary.set)
        self.summary_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar_summary.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        summary_frame.columnconfigure(0, weight=1)
        summary_frame.rowconfigure(0, weight=1)
        control_frame.columnconfigure(0, weight=1)
        
        # Results frame
        results_frame = ttk.LabelFrame(main_frame, text="Detailed Analysis Results", padding="10")
        results_frame.grid(row=2, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(results_frame)
        self.notebook.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Results text widget
        self.results_text = scrolledtext.ScrolledText(self.notebook, wrap=tk.WORD, font=("Consolas", 10))
        self.notebook.add(self.results_text, text="Transaction Details")
        
        # Register map tab
        self.register_text = scrolledtext.ScrolledText(self.notebook, wrap=tk.WORD, font=("Consolas", 10))
        self.notebook.add(self.register_text, text="Register Map")
        
        # Bit analysis tab
        self.bits_text = scrolledtext.ScrolledText(self.notebook, wrap=tk.WORD, font=("Consolas", 10))
        self.notebook.add(self.bits_text, text="Bit Analysis")
        
        results_frame.columnconfigure(0, weight=1)
        results_frame.rowconfigure(0, weight=1)
        
        self.transactions = []
        main_frame.rowconfigure(2, weight=1)        
    def analyze_trace(self):
        """Analyze the SMBus trace file"""
        filename = self.file_var.get()
        if not os.path.exists(filename):
            self.summary_text.delete(1.0, tk.END)
            self.summary_text.insert(tk.END, f"Error: File '{filename}' not found!")
            return
            
        try:
            self.transactions = self.parse_smbus_trace(filename)
            self.show_address_warnings()
            self.display_summary()
            self.display_detailed_analysis()
            self.display_register_map()
            self.display_bit_analysis()
            
        except Exception as e:
            self.summary_text.delete(1.0, tk.END)
            self.summary_text.insert(tk.END, f"Error analyzing file: {str(e)}")

    def show_address_warnings(self):
        """Show red warning banner if unexpected addresses are found"""
        unexpected = {}
        for t in self.transactions:
            if t.get('unexpected_address'):
                addr = t['address']
                unexpected[addr] = unexpected.get(addr, 0) + 1

        if unexpected:
            addr_list = ', '.join(f"0x{a} ({c} transactions)" for a, c in sorted(unexpected.items()))
            msg = (f"\u26a0 WARNING: Unexpected SMBus addresses detected: {addr_list}\n"
                   f"Expected addresses: 0x64 (MAC\u2192PHY) and 0x70 (PHY\u2192MAC) only. "
                   f"Review these transactions for possible issues.")
            self.warning_label.config(text=msg)
            self.warning_frame.grid()
        else:
            self.warning_frame.grid_remove()

    def parse_smbus_trace(self, filename):
        """Parse the SMBus trace and extract meaningful information"""
        transactions = []
        curr_page = 0
        
        with open(filename, 'r') as f:
            reader = csv.reader(f)
            data = list(reader)[8:]  # Skip Total Phase header
            
            for i, row in enumerate(data):
                if len(row) < 10:
                    continue
                    
                addr_raw = row[7].strip()
                addr_clean = addr_raw.rstrip('*').upper()
                is_nak = addr_raw.endswith('*')
                is_unexpected = addr_clean not in KNOWN_ADDRESSES

                if is_unexpected:
                    nak_suffix = " (NAK)" if is_nak else ""
                    direction = f"Addr 0x{addr_clean}{nak_suffix}"
                else:
                    direction = PHY_TO_MAC_DIRECTION if addr_clean == '70' else MAC_TO_PHY_DIRECTION

                trans = {
                    'index': i + 1,
                    'time': row[2],
                    'duration': row[3],
                    'address': addr_raw,
                    'direction': direction,
                    'raw_data': row[9].split(),
                    'page': None,
                    'register': None,
                    'register_name': None,
                    'data_value': None,
                    'bit_analysis': [],
                    'message_type': 'Unknown',
                    'unexpected_address': is_unexpected
                }
                
                # Parse the message
                if len(trans['raw_data']) == 7:
                    # Standard MDIO message
                    trans.update(self.decode_mdio_message(trans['raw_data'], curr_page))
                    
                    # Update page tracking
                    if trans.get('register') == 31 and 'page_access' in trans:
                        curr_page = trans['page_access']
                        
                elif len(trans['raw_data']) == 4:
                    # Status or wake message
                    trans.update(self.decode_status_message(trans['raw_data'], trans['direction']))
                    
                transactions.append(trans)
        
        return transactions
    
    def decode_mdio_message(self, data_bytes, current_page):
        """Decode MDIO register access message"""
        try:
            # Convert to binary and parse
            little_endian = ''.join(data_bytes[::-1])
            hex_value = int(little_endian, 16)
            bin_data = format(hex_value, '056b')
            
            # Extract fields
            reg_ctrl = bin_data[8:16]
            data_field = bin_data[16:32]
            phy_addr_bits = bin_data[35:40]
            
            # Decode message type
            if reg_ctrl[0] == '0':
                if reg_ctrl[1] == '0':
                    msg_type = 'Write Request' if reg_ctrl[2] == '1' else 'Read Request'
                else:
                    msg_type = 'Write Acknowledge' if reg_ctrl[2] == '1' else 'Read Response'
            else:
                msg_type = 'Status/Control Packet'
            
            # Extract register and PHY addresses
            reg_addr = int(reg_ctrl[3:], 2)
            phy_addr = int(phy_addr_bits, 2)
            data_value = int(data_field, 2)
            
            # Handle page access (register 31)
            if reg_addr == 31:
                page_value = int(data_field[:11], 2)
                return {
                    'message_type': f'MDIO {msg_type}',
                    'page': None,
                    'register': reg_addr,
                    'register_name': 'Page Select Register',
                    'data_value': data_value,
                    'page_access': page_value,
                    'bit_analysis': [f"Page Access: {page_value}"]
                }
            
            # Get register info
            reg_info = get_register_info(current_page, reg_addr)
            
            # Analyze bits
            bit_analysis = []
            for bit_pos in range(16):
                if (data_value >> bit_pos) & 1:
                    bit_name = reg_info['bits'].get(bit_pos, f'Bit {bit_pos}')
                    bit_analysis.append(f"Bit {bit_pos}: {bit_name}")
            
            return {
                'message_type': f'MDIO {msg_type}',
                'page': current_page,
                'register': reg_addr, 
                'register_name': reg_info['name'],
                'data_value': data_value,
                'bit_analysis': bit_analysis
            }
            
        except Exception as e:
            return {'message_type': f'Parse Error: {str(e)}'}
    
    def decode_status_message(self, data_bytes, direction):
        """Decode status/control messages"""
        try:
            if data_bytes[0] == 'D5':
                return {
                    'message_type': 'Wake-up Message',
                    'bit_analysis': ['Wake-up indication detected']
                }
            
            # Status packet
            little_endian = ''.join(data_bytes[::-1])
            hex_value = int(little_endian, 16)
            bin_data = format(hex_value, '032b')
            
            status_bits = SMBUS_STATUS_BITS.get(
                'phy_to_mac' if direction == 'PHY -> MAC' else 'mac_to_phy', {}
            )
            
            bit_analysis = []
            for bit_pos, description in status_bits.items():
                if bit_pos < len(bin_data) and bin_data[-(bit_pos+1)] == '1':
                    bit_analysis.append(f"Bit {bit_pos}: {description}")
            
            return {
                'message_type': f'Status Packet ({direction})',
                'bit_analysis': bit_analysis
            }
            
        except Exception as e:
            return {'message_type': f'Status Parse Error: {str(e)}'}
    
    def display_summary(self):
        """Display analysis summary"""
        self.summary_text.delete(1.0, tk.END)
        self.summary_text.tag_configure('warning', foreground='#CC0000', font=('TkDefaultFont', 9, 'bold'))

        total = len(self.transactions)
        mdio_msgs = len([t for t in self.transactions if 'MDIO' in t['message_type']])
        status_msgs = len([t for t in self.transactions if 'Status' in t['message_type']])

        summary = f"""ANALYSIS SUMMARY
================
Total Messages: {total}
MDIO Messages: {mdio_msgs}
Status Messages: {status_msgs}

COMMUNICATION:
MAC -> PHY (0x64, 0x70): {len([t for t in self.transactions if t['direction'] == MAC_TO_PHY_DIRECTION])}
PHY -> MAC: {len([t for t in self.transactions if t['direction'] == PHY_TO_MAC_DIRECTION])}
"""
        self.summary_text.insert(tk.END, summary)

        # Count unexpected addresses
        unexpected = {}
        for t in self.transactions:
            if t.get('unexpected_address'):
                addr = t['address']
                unexpected[addr] = unexpected.get(addr, 0) + 1
        if unexpected:
            warn_text = "\n*** UNEXPECTED ADDRESSES ***\n"
            for addr, cnt in sorted(unexpected.items()):
                warn_text += f"0x{addr}: {cnt} transactions\n"
            self.summary_text.insert(tk.END, warn_text, 'warning')

        addr_summary = "\nADDRESS DISTRIBUTION:\n"
        addr_counts = {}
        for t in self.transactions:
            a = t.get('address', '??')
            addr_counts[a] = addr_counts.get(a, 0) + 1
        for addr, cnt in sorted(addr_counts.items()):
            marker = " *** UNEXPECTED" if addr.rstrip('*').upper() not in KNOWN_ADDRESSES else ""
            addr_summary += f"0x{addr}: {cnt} transactions{marker}\n"
        self.summary_text.insert(tk.END, addr_summary)

        reg_section = "\nREGISTER ACCESS:\n"

        # Count register accesses
        reg_counts = {}
        for t in self.transactions:
            if t.get('page') is not None and t.get('register') is not None:
                key = f"Page {t['page']}, Reg {t['register']}"
                reg_counts[key] = reg_counts.get(key, 0) + 1
        
        for reg, count in sorted(reg_counts.items(), key=lambda x: x[1], reverse=True)[:10]:
            reg_section += f"{reg}: {count} accesses\n"
        
        self.summary_text.insert(tk.END, reg_section)
    
    def display_detailed_analysis(self):
        """Display detailed transaction analysis"""
        self.results_text.delete(1.0, tk.END)
        self.results_text.tag_configure('unexpected', foreground='#CC0000', font=('Consolas', 10, 'bold'))

        output_header = "DETAILED TRANSACTION ANALYSIS\n"
        output_header += "=" * 80 + "\n\n"
        self.results_text.insert(tk.END, output_header)

        for trans in self.transactions:
            is_unexpected = trans.get('unexpected_address', False)

            entry = f"[{trans['index']}] {trans['time']} ({trans['duration']})\n"
            entry += f"    Address: 0x{trans.get('address', '??')}\n"
            entry += f"    Direction: {trans['direction']}\n"
            entry += f"    Type: {trans['message_type']}\n"
            
            if trans.get('register') is not None and trans.get('page') is not None:
                register_display = format_register_display(
                    trans.get('page'),
                    trans.get('register'),
                    trans.get('register_name', 'Unknown Register')
                )
                if register_display:
                    output += f"    Register: {register_display}\n"
            elif trans.get('register') is not None:
                output += f"    Register: {trans['register']}\n"
                if trans.get('register_name'):
                    output += f"    Register Name: {trans['register_name']}\n"
            if trans.get('data_value') is not None:
                entry += f"    Data Value: 0x{trans['data_value']:04X} ({trans['data_value']})\n"
            
            if trans.get('bit_analysis'):
                entry += f"    Active Bits:\n"
                for bit_info in trans['bit_analysis']:
                    entry += f"        {bit_info}\n"
            
            entry += f"    Raw Data: {' '.join(trans['raw_data'])}\n"

            if is_unexpected:
                entry += f"    >>> UNEXPECTED ADDRESS - NOT 0x6E or 0x70 <<<\n"

            entry += "\n"

            if is_unexpected:
                self.results_text.insert(tk.END, entry, 'unexpected')
            else:
                self.results_text.insert(tk.END, entry)
    
    def display_register_map(self):
        """Display register map information"""
        self.register_text.delete(1.0, tk.END)
        
        from phy_definitions import PAGE_0_REGISTERS, PAGE_1_REGISTERS
        
        output = "JACKSONVILLE PHY REGISTER MAP\n"
        output += "=" * 60 + "\n\n"
        
        output += "PAGE 0 - IEEE 802.3 STANDARD REGISTERS\n"
        output += "-" * 45 + "\n"
        for reg_addr, reg_info in PAGE_0_REGISTERS.items():
            output += f"0x{reg_addr:02X}: {reg_info['name']}\n"
            for bit_pos, bit_desc in reg_info['bits'].items():
                output += f"    Bit {bit_pos:2d}: {bit_desc}\n"
            output += "\n"
        
        output += "\nPAGE 1 - EXTENDED JACKSONVILLE REGISTERS\n"
        output += "-" * 45 + "\n"
        for reg_addr, reg_info in PAGE_1_REGISTERS.items():
            output += f"0x{reg_addr:02X}: {reg_info['name']}\n"
            for bit_pos, bit_desc in reg_info['bits'].items():
                output += f"    Bit {bit_pos:2d}: {bit_desc}\n"
            output += "\n"
        
        self.register_text.insert(tk.END, output)
    
    def display_bit_analysis(self):
        """Display bit-level analysis of actual data"""
        self.bits_text.delete(1.0, tk.END)
        
        output = "BIT-LEVEL ANALYSIS OF TRACE DATA\n"
        output += "=" * 50 + "\n\n"
        
        # Group by register and show unique data values
        register_data = {}
        for trans in self.transactions:
            if trans.get('page') is not None and trans.get('register') is not None and trans.get('data_value') is not None:
                key = (trans['page'], trans['register'], trans['register_name'])
                if key not in register_data:
                    register_data[key] = set()
                register_data[key].add(trans['data_value'])
        
        for (page, reg, reg_name), values in register_data.items():
            register_display = format_register_display(page, reg, reg_name)
            output += f"{register_display}\n"
            output += "-" * 60 + "\n"
            
            for value in sorted(values):
                output += f"  Data Value: 0x{value:04X} ({value})\n"
                output += f"  Binary: {value:016b}\n"
                
                reg_info = get_register_info(page, reg)
                active_bits = []
                for bit_pos in range(16):
                    if (value >> bit_pos) & 1:
                        bit_name = reg_info['bits'].get(bit_pos, f'Bit {bit_pos}')
                        active_bits.append(f"Bit {bit_pos}: {bit_name}")
                
                if active_bits:
                    output += "  Active Bits:\n"
                    for bit_info in active_bits:
                        output += f"    {bit_info}\n"
                else:
                    output += "  No bits set\n"
                output += "\n"
            
            output += "\n"
        
        self.bits_text.insert(tk.END, output)

def main():
    root = tk.Tk()
    app = SMBusAnalyzerGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()