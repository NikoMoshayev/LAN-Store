import csv
import os
import math
import tkinter.font as tkfont
import webbrowser
import tempfile
from tkinter import filedialog, messagebox, ttk
import tkinter as tk
from phy_definitions import get_register_info, get_page_name, SMBUS_STATUS_BITS, format_register_display

MAC_TO_PHY_DIRECTION = "MAC(0x70)-> PHY(0x64)"
PHY_TO_MAC_DIRECTION = "PHY(0x64)-> MAC(0x70)"
KNOWN_ADDRESSES = {'64', '70'}
MAX_HTML_TRANSACTIONS = 2000
BIT_ANALYSIS_LIMIT = 500

# Event type definitions for flow analysis
EVENT_TYPES = {
    'WAKE_HOST': {'icon': '🔔', 'color': '#4ec9b0', 'name': 'Host Wake'},
    'WAKE_ME': {'icon': '🔔', 'color': '#dcdcaa', 'name': 'ME Wake'},
    'LINK_UP': {'icon': '🔗', 'color': '#4ec9b0', 'name': 'Link UP'},
    'LINK_DOWN': {'icon': '⛓️', 'color': '#f14c4c', 'name': 'Link DOWN'},
    'SPEED_10': {'icon': '🐢', 'color': '#808080', 'name': 'Speed: 10 Mbps'},
    'SPEED_100': {'icon': '🚗', 'color': '#dcdcaa', 'name': 'Speed: 100 Mbps'},
    'SPEED_1000': {'icon': '🚀', 'color': '#4ec9b0', 'name': 'Speed: 1 Gbps'},
    'DUPLEX_FULL': {'icon': '⇆', 'color': '#4ec9b0', 'name': 'Full Duplex'},
    'DUPLEX_HALF': {'icon': '→', 'color': '#dcdcaa', 'name': 'Half Duplex'},
    'RESET_START': {'icon': '🔄', 'color': '#f14c4c', 'name': 'SW Reset Started'},
    'RESET_COMPLETE': {'icon': '✅', 'color': '#4ec9b0', 'name': 'Reset Complete'},
    'AN_START': {'icon': '🤝', 'color': '#007acc', 'name': 'Auto-Negotiation Started'},
    'AN_COMPLETE': {'icon': '✓', 'color': '#4ec9b0', 'name': 'Auto-Negotiation Complete'},
    'PCIE_MODE': {'icon': '🔌', 'color': '#ce9178', 'name': 'PCIe Mode'},
    'SMBUS_MODE': {'icon': '📡', 'color': '#007acc', 'name': 'SMBus Mode'},
    'RX_ACTIVE': {'icon': '📥', 'color': '#4ec9b0', 'name': 'RX Active'},
    'TX_LPI_EXIT': {'icon': '⚡', 'color': '#dcdcaa', 'name': 'TX LPI Exit Request'},
    'PORT_RESET': {'icon': '🔃', 'color': '#f14c4c', 'name': 'Port Reset'},
    'LANWAKE_CLEAR': {'icon': '💤', 'color': '#808080', 'name': 'LANWAKE# Cleared (PINSTOP)'},
    'CABLE_DISCONNECT': {'icon': '🔌', 'color': '#f14c4c', 'name': 'Cable Disconnected'},
    'ULP_ENTRY': {'icon': '😴', 'color': '#ce9178', 'name': 'ULP Entry'},
    'ULP_EXIT': {'icon': '⏰', 'color': '#4ec9b0', 'name': 'ULP Exit'},
    'PHY_READY': {'icon': '✔️', 'color': '#4ec9b0', 'name': 'PHY Ready'},
    'NACK_START': {'icon': '❌', 'color': '#f14c4c', 'name': 'PHY Not Responding (NACK)'},
    'NACK_END': {'icon': '✔️', 'color': '#4ec9b0', 'name': 'PHY Responding Again'},
    'PAGE_ACCESS': {'icon': '📄', 'color': '#007acc', 'name': 'Page Access'},
}

def get_set_bits_summary(data_value, reg_info):
    """Return list of (bit_pos, bit_name) for bits that are set (=1)."""
    if not reg_info or 'bits' not in reg_info:
        return []
    set_bits = []
    for bit_pos in range(15, -1, -1):
        if (data_value >> bit_pos) & 1:
            bit_name = reg_info['bits'].get(bit_pos, f'Bit {bit_pos}')
            set_bits.append((bit_pos, bit_name))
    return set_bits


def get_status_set_bits_summary(data_value, direction):
    """Return list of (bit_pos, bit_name) for set bits in a status packet."""
    if direction and 'PHY' in direction and 'MAC' in direction:
        # PHY-to-MAC
        bit_defs = SMBUS_STATUS_BITS.get('phy_to_mac', {})
    else:
        bit_defs = SMBUS_STATUS_BITS.get('mac_to_phy', {})
    set_bits = []
    for bit_pos in range(15, -1, -1):
        if (data_value >> bit_pos) & 1:
            bit_name = bit_defs.get(bit_pos, f'Bit {bit_pos}')
            set_bits.append((bit_pos, bit_name))
    return set_bits


def format_set_bits_text(set_bits):
    """Format set bits as a compact string for display."""
    if not set_bits:
        return "(none)"
    return ", ".join(f"[{pos}]{name}" for pos, name in set_bits)


def format_bit_analysis_block(data_value, reg_info):
    """Format bit analysis in grouped rows to match HTML-style output."""
    if not reg_info or 'bits' not in reg_info:
        return f"Binary: {data_value:016b}"

    bit_details = []
    for bit_pos in range(15, -1, -1):  # MSB to LSB
        bit_value = (data_value >> bit_pos) & 1
        bit_name = reg_info['bits'].get(bit_pos, f'Bit {bit_pos}')
        marker = " ◄" if bit_value else ""
        bit_details.append(f"Bit[{bit_pos}][{bit_name}] = {bit_value}{marker}")

    rows = []
    for i in range(0, len(bit_details), 4):
        row_bits = bit_details[i:i+4]
        rows.append("| " + " | ".join(row_bits) + " |")
        if i + 4 < len(bit_details):
            rows.append("---")

    return "\n".join(rows)


def is_meaningful_bit_name(bit_name):
    """Return True for named bits that are useful in a plain-English summary."""
    if not bit_name:
        return False
    normalized_name = str(bit_name).strip().lower()
    return not (
        normalized_name.startswith('reserved')
        or normalized_name.startswith('bit ')
        or normalized_name.startswith('bit[')
    )


def format_bit_state_summary(data_value, bit_definitions, max_items=8):
    """Summarize enabled/disabled named bits without flooding the details pane."""
    enabled_bits = []

    for bit_pos in range(15, -1, -1):
        bit_name = bit_definitions.get(bit_pos, f'Bit {bit_pos}') if bit_definitions else f'Bit {bit_pos}'
        if not is_meaningful_bit_name(bit_name):
            continue

        bit_entry = f"Bit[{bit_pos}] {bit_name}"
        if (data_value >> bit_pos) & 1:
            enabled_bits.append(bit_entry)

    lines = []
    if enabled_bits:
        enabled_text = "; ".join(enabled_bits[:max_items])
        if len(enabled_bits) > max_items:
            enabled_text += f"; +{len(enabled_bits) - max_items} more"
        lines.append(f"Enabled/set: {enabled_text}.")
        lines.append("All other named bits are clear unless shown in the full bit table below.")
    else:
        lines.append("No named control/status bits are set in this value.")

    return lines


def build_plain_english_summary(trans):
    """Build a short user-facing explanation for the selected SMBus access."""
    message_type = trans.get('message_type', 'Unknown')
    direction = trans.get('direction', 'Unknown direction')
    data_value = trans.get('data_value')
    raw_data = trans.get('raw_data', [])

    lines = []

    if message_type == 'NACK':
        return [
            "The PHY did not return data for this SMBus access.",
            "Treat this as a no-response point; check whether the PHY is powered, held in reset, switching modes, or temporarily unavailable."
        ]

    if message_type == 'Wake-up Message':
        wake_type = trans.get('wake_type', 'Unknown wake')
        return [
            f"This is a wake indication on SMBus: {wake_type}.",
            "It means the PHY/management side is signaling a wake-related event rather than configuring an MDIO register."
        ]

    if trans.get('is_status'):
        lines.append(f"This is a status packet sent on {direction}.")
        if data_value is not None:
            if direction and 'PHY' in direction and 'MAC' in direction:
                bit_definitions = SMBUS_STATUS_BITS.get('phy_to_mac', {})
            else:
                bit_definitions = SMBUS_STATUS_BITS.get('mac_to_phy', {})
            lines.extend(format_bit_state_summary(data_value, bit_definitions, max_items=6))
        return lines

    if trans.get('page_access') is not None:
        page_access = trans.get('page_access')
        page_name = trans.get('page_name', get_page_name(page_access))
        lines.append(f"This access selects MDIO page {page_access} ({page_name}).")
        lines.append("Following register accesses use this page until another Page Select access appears.")
        return lines

    page = trans.get('page')
    register = trans.get('register')
    register_name = trans.get('register_name', 'Unknown register')
    page_name = trans.get('page_name', get_page_name(page) if page is not None else 'Unknown page')
    register_text = f"page {page} ({page_name}), register 0x{register:02X} ({register_name})" if page is not None and register is not None else "an unknown register"

    if 'Config Write Ack' in message_type:
        lines.append(f"The PHY acknowledges that it accepted the previous write for {register_text}.")
    elif 'Config Write' in message_type:
        lines.append(f"This write configures {register_text}.")
    elif 'Config Read Response' in message_type:
        lines.append(f"The PHY returns the current value of {register_text}.")
    elif 'Config Read Request' in message_type:
        lines.append(f"The MAC requests the current value of {register_text}.")
    elif 'Unknown' in message_type:
        lines.append("The transaction format was parsed, but the message type is not recognized by this decoder.")
    else:
        lines.append(f"This SMBus transaction is decoded as: {message_type}.")

    if data_value is not None:
        lines.append(f"Value on the bus is 0x{data_value:04X} ({data_value}).")
        reg_info = trans.get('register_info') or get_register_info(page, register)
        bit_definitions = reg_info.get('bits', {}) if reg_info else {}
        lines.extend(format_bit_state_summary(data_value, bit_definitions, max_items=6))
    elif raw_data:
        lines.append("The access has raw bytes, but no register data value was decoded from it.")

    return lines


def detect_flow_events(transactions):
    """Detect important flow events from transactions for timeline display"""
    events = []
    
    # State tracking
    last_link_status = None
    last_speed = None
    last_duplex = None
    last_reset_state = None
    in_nack_period = False
    nack_start_index = None
    last_an_status = None
    last_page_access = None
    
    for trans in transactions:
        index = trans.get('index', 0)
        time_str = trans.get('time', '')
        msg_type = trans.get('message_type', '')
        data_value = trans.get('data_value')
        page = trans.get('page')
        register = trans.get('register')
        raw_data = trans.get('raw_data', [])
        
        # Detect NACK periods (no data = PHY not responding)
        is_nack = data_value is None and register is None and len(raw_data) == 0
        if is_nack and not in_nack_period:
            in_nack_period = True
            nack_start_index = index
            events.append({
                'index': index,
                'time': time_str,
                'type': 'NACK_START',
                'description': 'PHY stopped responding'
            })
        elif not is_nack and in_nack_period:
            in_nack_period = False
            events.append({
                'index': index,
                'time': time_str,
                'type': 'NACK_END',
                'description': f'PHY responding again (NACK period: lines {nack_start_index}-{index-1})'
            })
        
        # Wake-up Messages (D5 command)
        if msg_type == 'Wake-up Message':
            wake_type = trans.get('wake_type', 'Unknown')
            if wake_type == 'Host Wake':
                events.append({
                    'index': index,
                    'time': time_str,
                    'type': 'WAKE_HOST',
                    'description': 'Host Wake-up message received'
                })
            elif wake_type == 'ME Wake':
                events.append({
                    'index': index,
                    'time': time_str,
                    'type': 'WAKE_ME',
                    'description': 'ME Wake-up message received'
                })
        
        # Parse PtM messages (D3 command)
        if len(raw_data) >= 7 and raw_data[0].upper() == 'D3':
            try:
                msg_type_byte = int(raw_data[2], 16)

                if msg_type_byte == 0x00:
                    # PtM Status packet per Jacksonville EAS 1.12
                    status_hi = int(raw_data[3], 16)
                    status_lo = int(raw_data[4], 16)
                    status_value = (status_hi << 8) | status_lo

                    # Parse status bits per Jacksonville EAS 1.12 Tables 13-14
                    # status_value = (Status2nd << 8) | Status1st
                    # Bit 15=RSTC, 12=CDIS, 11=ELINK, 10=DPX, 9:8=SPD, 5=EI, 2=WoL
                    link_up = (status_value >> 11) & 1       # ELINK
                    cable_disc = (status_value >> 12) & 1    # CDIS
                    duplex = (status_value >> 10) & 1        # DPX
                    speed = (status_value >> 8) & 0x03       # SPD[1:0]
                    reset_done = (status_value >> 15) & 1    # RSTC

                    # Reset Complete
                    if reset_done and last_reset_state != 'ready':
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'RESET_COMPLETE',
                            'description': f'PHY Reset Complete - Status: 0x{status_value:04X}'
                        })
                        last_reset_state = 'ready'

                    # Link change
                    if link_up != last_link_status:
                        if link_up:
                            events.append({
                                'index': index,
                                'time': time_str,
                                'type': 'LINK_UP',
                                'description': f'Link established - Status: 0x{status_value:04X}'
                            })
                        else:
                            events.append({
                                'index': index,
                                'time': time_str,
                                'type': 'LINK_DOWN',
                                'description': f'Link lost - Status: 0x{status_value:04X}'
                            })
                        last_link_status = link_up

                    # Cable disconnect
                    if cable_disc:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'CABLE_DISCONNECT',
                            'description': f'Cable disconnected - Status: 0x{status_value:04X}'
                        })

                    # Speed change
                    if speed != last_speed:
                        speed_map = {0: 'SPEED_10', 1: 'SPEED_100', 2: 'SPEED_1000'}
                        speed_names = {0: '10 Mbps', 1: '100 Mbps', 2: '1 Gbps'}
                        if speed in speed_map:
                            events.append({
                                'index': index,
                                'time': time_str,
                                'type': speed_map[speed],
                                'description': f'Link speed: {speed_names[speed]}'
                            })
                        last_speed = speed

                    # Duplex change
                    if duplex != last_duplex:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'DUPLEX_FULL' if duplex else 'DUPLEX_HALF',
                            'description': f'Duplex mode: {"Full" if duplex else "Half"}'
                        })
                        last_duplex = duplex

                elif msg_type_byte in (0x01, 0x02):
                    # Config Ack or Read Response from PHY
                    # Wire[4]=MSB Data, Wire[3]=LSB Data, Wire[5]=Addr&Ctrl
                    reg_byte = int(raw_data[5], 16)
                    reg = reg_byte & 0x1F
                    value = (int(raw_data[4], 16) << 8) | int(raw_data[3], 16)

                    # PHY Specific Status (Page 769 Reg 17)
                    if page == 769 and reg == 17:
                        rt_link = (value >> 10) & 1
                        an_complete = (value >> 11) & 1
                        if an_complete and last_an_status == 'enabled':
                            events.append({
                                'index': index,
                                'time': time_str,
                                'type': 'AN_COMPLETE',
                                'description': f'Auto-Negotiation complete - Value: 0x{value:04X}'
                            })
                            last_an_status = 'complete'

            except (ValueError, IndexError):
                pass
        
        # Parse C3 (MtP) Config messages for specific events
        if len(raw_data) >= 7 and raw_data[0].upper() == 'C3':
            try:
                msg_type_byte = int(raw_data[2], 16)

                # MtP Control (TYPE=0x00) - PINSTOP/LANWAKE detection
                # Wire[3] = Command 2nd Byte: bit 0=PINSTOP, bit 6=PWDN, bit 7=RST
                if msg_type_byte == 0x00:
                    cmd_2nd_byte = int(raw_data[3], 16)
                    pinstop = (cmd_2nd_byte & 0x01) != 0
                    if pinstop:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'LANWAKE_CLEAR',
                            'description': f'PINSTOP: Clear the LANWAKE# pin - Cmd2nd: 0x{cmd_2nd_byte:02X}'
                        })
                    continue  # Don't process as regular C3 message

                if msg_type_byte in (0x01, 0x02):
                    # Config Write or Read Request from MAC
                    # Wire[4]=MSB Data, Wire[3]=LSB Data, Wire[5]=Addr&Ctrl
                    reg_byte = int(raw_data[5], 16)
                    reg = reg_byte & 0x1F
                    value = (int(raw_data[4], 16) << 8) | int(raw_data[3], 16)

                    # Page access detection (Reg 31 = page select register)
                    if reg == 31:
                        page_num = value >> 5  # Page number in bits [15:5]
                        if page_num != last_page_access:
                            events.append({
                                'index': index,
                                'time': time_str,
                                'type': 'PAGE_ACCESS',
                                'description': f'Access to page {page_num}'
                            })
                            last_page_access = page_num
                
                # SW Reset (Page 0 Reg 0, bit 15) - IEEE Control Register
                if page == 0 and reg == 0 and (value >> 15) & 1:
                    events.append({
                        'index': index,
                        'time': time_str,
                        'type': 'RESET_START',
                        'description': f'Software Reset initiated - Value: 0x{value:04X}'
                    })
                    last_reset_state = 'resetting'
                
                # Auto-Negotiation Enable (Page 0 Reg 0, bit 12)
                if page == 0 and reg == 0:
                    an_enable = (value >> 12) & 1
                    if an_enable and last_an_status != 'enabled':
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'AN_START',
                            'description': f'Auto-Negotiation enabled - Value: 0x{value:04X}'
                        })
                        last_an_status = 'enabled'
                
                # Page 779 (ULP Control) accesses
                if page == 779:
                    # Register 16 - ULP Config
                    if reg == 16:
                        wol_me = (value >> 7) & 1
                        wol_host = (value >> 6) & 1
                        if wol_me or wol_host:
                            events.append({
                                'index': index,
                                'time': time_str,
                                'type': 'ULP_ENTRY',
                                'description': f'ULP Config: WOL_ME={wol_me}, WOL_HOST={wol_host} - Value: 0x{value:04X}'
                            })
                    
                    # Register 29 - Cable Status
                    if reg == 29:
                        if value in [0x00FF, 0xFF00, 0xFFFF]:
                            events.append({
                                'index': index,
                                'time': time_str,
                                'type': 'CABLE_DISCONNECT',
                                'description': f'Cable disconnected detected - Value: 0x{value:04X}'
                            })
                
                # Page 769 Register 16 - PHY Specific Control
                if page == 769 and reg == 16:
                    # TX LPI Exit (bit related to EEE)
                    if (value >> 10) & 1:  # Example bit position
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'TX_LPI_EXIT',
                            'description': f'TX LPI Exit request - Value: 0x{value:04X}'
                        })
                
                # Page 769 Register 17 - PHY Specific Status
                if page == 769 and reg == 17:
                    # RX Active detection
                    rx_active = (value >> 9) & 1
                    if rx_active:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'RX_ACTIVE',
                            'description': f'RX Activity detected - Value: 0x{value:04X}'
                        })
                    
                    # AN Complete
                    an_complete = (value >> 11) & 1
                    if an_complete and last_an_status == 'enabled':
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'AN_COMPLETE',
                            'description': f'Auto-Negotiation complete - Value: 0x{value:04X}'
                        })
                        last_an_status = 'complete'
                
                # Page 776 - Packet Generator / Test modes (PCIe/SMBus transition)
                if page == 776:
                    if reg == 0:
                        if (value >> 0) & 1:  # Example: mode bit
                            events.append({
                                'index': index,
                                'time': time_str,
                                'type': 'PCIE_MODE',
                                'description': f'PCIe mode indicated - Value: 0x{value:04X}'
                            })
                
                # SMBus Mode (Page 769 Reg 23, bit 0 - Force SMBus)
                if page == 769 and reg == 23:
                    force_smbus = value & 0x01
                    if force_smbus:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'SMBUS_MODE',
                            'description': f'SMBus Mode forced - Value: 0x{value:04X}'
                        })
                    else:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'PCIE_MODE',
                            'description': f'PCIe Mode (SMBus not forced) - Value: 0x{value:04X}'
                        })
                
                # EEE/LPI Control (Page 772 Reg 20)
                if page == 772 and reg == 20:
                    eee_1000 = (value >> 14) & 1
                    eee_100 = (value >> 13) & 1
                    force_lpi = (value >> 12) & 1
                    if eee_1000 or eee_100:
                        speed_text = []
                        if eee_1000:
                            speed_text.append("1G")
                        if eee_100:
                            speed_text.append("100M")
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'TX_LPI_EXIT',
                            'description': f'EEE Enabled on {",".join(speed_text)} - Value: 0x{value:04X}'
                        })
                    if force_lpi:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'TX_LPI_EXIT',
                            'description': f'Force LPI mode - Value: 0x{value:04X}'
                        })
                
                # WOL Wake Up Control (Page 800 Reg 1)
                if page == 800 and reg == 1:
                    pme_status = (value >> 2) & 1
                    pme_en = (value >> 1) & 1
                    apme = value & 1
                    if pme_status:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'WAKE_HOST',
                            'description': f'PME Wake Event detected - Value: 0x{value:04X}'
                        })
                    if pme_en or apme:
                        mode_text = []
                        if pme_en:
                            mode_text.append("PME")
                        if apme:
                            mode_text.append("APM")
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'WAKE_HOST',
                            'description': f'Wake enabled: {",".join(mode_text)} - Value: 0x{value:04X}'
                        })
                
                # WOL Filter Control (Page 800 Reg 2)
                if page == 800 and reg == 2:
                    filter_types = []
                    if (value >> 1) & 1:
                        filter_types.append("Magic")
                    if (value >> 0) & 1:
                        filter_types.append("Link")
                    if (value >> 2) & 1:
                        filter_types.append("Exact")
                    if (value >> 3) & 1:
                        filter_types.append("MC")
                    if (value >> 4) & 1:
                        filter_types.append("BC")
                    if (value >> 5) & 1:
                        filter_types.append("ARP")
                    if (value >> 6) & 1:
                        filter_types.append("IPv4")
                    if (value >> 7) & 1:
                        filter_types.append("IPv6")
                    if filter_types:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'WAKE_HOST',
                            'description': f'WOL Filters enabled: {",".join(filter_types)} - Value: 0x{value:04X}'
                        })
                
                # WOL Wake Up Status (Page 800 Reg 3)
                if page == 800 and reg == 3:
                    wake_types = []
                    if (value >> 1) & 1:
                        wake_types.append("Magic")
                    if (value >> 0) & 1:
                        wake_types.append("Link")
                    if (value >> 2) & 1:
                        wake_types.append("Exact")
                    if (value >> 3) & 1:
                        wake_types.append("MC")
                    if (value >> 4) & 1:
                        wake_types.append("BC")
                    if (value >> 5) & 1:
                        wake_types.append("ARP")
                    if (value >> 6) & 1:
                        wake_types.append("IPv4")
                    if (value >> 7) & 1:
                        wake_types.append("IPv6")
                    if wake_types:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'WAKE_HOST',
                            'description': f'WOL Wake detected: {",".join(wake_types)} - Value: 0x{value:04X}'
                        })
                
                # PINSTOP / LANWAKE# control
                if page == 769 and reg == 18:
                    lanwake_clear = (value >> 3) & 1
                    if lanwake_clear:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'LANWAKE_CLEAR',
                            'description': f'LANWAKE# pin cleared (PINSTOP) - Value: 0x{value:04X}'
                        })
                
                # Port Reset detection (Page 769 Reg 20)
                if page == 769 and reg == 20:
                    if (value >> 15) & 1:
                        events.append({
                            'index': index,
                            'time': time_str,
                            'type': 'PORT_RESET',
                            'description': f'Port Reset detected - Value: 0x{value:04X}'
                        })
                        
            except (ValueError, IndexError):
                pass
    
    return events


def detect_transaction_event(trans, state):
    """Detect event for a single transaction, updating state. Returns event string or empty."""
    index = trans.get('index', 0)
    msg_type = trans.get('message_type', '')
    data_value = trans.get('data_value')
    page = trans.get('page')
    register = trans.get('register')
    raw_data = trans.get('raw_data', [])
    
    events_list = []
    
    # Detect NACK (no data = PHY not responding)
    is_nack = data_value is None and register is None and len(raw_data) == 0
    if is_nack and not state.get('in_nack'):
        state['in_nack'] = True
        state['nack_start'] = index
        return "❌ NACK Start"
    elif not is_nack and state.get('in_nack'):
        state['in_nack'] = False
        return "✔️ PHY Responding"
    
    # Wake-up Messages (D5 command)
    if msg_type == 'Wake-up Message':
        wake_type = trans.get('wake_type', 'Unknown')
        if wake_type == 'Host Wake':
            return "🔔 HOST WAKE"
        elif wake_type == 'ME Wake':
            return "🔔 ME WAKE"
    
    # Parse D3 (PtM) messages
    if len(raw_data) >= 7 and raw_data[0].upper() == 'D3':
        try:
            msg_type_byte = int(raw_data[2], 16)

            if msg_type_byte == 0x00:
                # PtM Status packet
                status_hi = int(raw_data[3], 16)
                status_lo = int(raw_data[4], 16)
                status_value = (status_hi << 8) | status_lo

                # Parse status bits per Jacksonville EAS 1.12 Tables 13-14
                link_up = (status_value >> 11) & 1       # ELINK
                cable_disc = (status_value >> 12) & 1    # CDIS
                duplex = (status_value >> 10) & 1        # DPX
                speed = (status_value >> 8) & 0x03       # SPD[1:0]
                reset_done = (status_value >> 15) & 1    # RSTC

                # Reset Complete
                if reset_done and state.get('reset_state') != 'ready':
                    state['reset_state'] = 'ready'
                    events_list.append("✅ Reset Complete")

                # Cable disconnect
                if cable_disc:
                    events_list.append("🔌 Cable Disconn")

                # Link change
                if link_up != state.get('link_status'):
                    if link_up:
                        events_list.append("🔗 LINK UP")
                    else:
                        events_list.append("⛓️ LINK DOWN")
                    state['link_status'] = link_up

                # Speed change
                if speed != state.get('speed'):
                    speed_names = {0: '🐢 10M', 1: '🚗 100M', 2: '🚀 1G'}
                    if speed in speed_names:
                        events_list.append(speed_names[speed])
                    state['speed'] = speed

                # Duplex change
                if duplex != state.get('duplex'):
                    events_list.append("⇆ Full" if duplex else "→ Half")
                    state['duplex'] = duplex

                if events_list:
                    return " | ".join(events_list)

            elif msg_type_byte in (0x01, 0x02):
                # Config Ack or Read Response from PHY
                # Wire[4]=MSB Data, Wire[3]=LSB Data, Wire[5]=Addr&Ctrl
                reg_byte = int(raw_data[5], 16)
                reg = reg_byte & 0x1F
                value = (int(raw_data[4], 16) << 8) | int(raw_data[3], 16)

                # PHY Specific Status (Page 769 Reg 17)
                if page == 769 and reg == 17:
                    rt_link = (value >> 10) & 1
                    rt_speed = (value >> 14) & 0x03
                    an_complete = (value >> 11) & 1

                    if rt_link != state.get('link_status_rt'):
                        if rt_link:
                            events_list.append("🔗 Link Detected")
                        state['link_status_rt'] = rt_link

                    if rt_speed != state.get('speed_rt') and rt_speed in [0, 1, 2]:
                        speed_names = {0: '🐢 10M', 1: '🚗 100M', 2: '🚀 1G'}
                        events_list.append(speed_names.get(rt_speed, ''))
                        state['speed_rt'] = rt_speed

                    if an_complete and state.get('an_status') == 'enabled':
                        events_list.append("✓ AN Complete")
                        state['an_status'] = 'complete'

                if events_list:
                    return " | ".join(events_list)
        except Exception:
            pass
    
    # Parse C3 (MtP) Config messages
    if len(raw_data) >= 7 and raw_data[0].upper() == 'C3':
        try:
            msg_type_byte = int(raw_data[2], 16)

            # MtP Control (TYPE=0x00) - PINSTOP/LANWAKE detection
            # Wire[3] = Command 2nd Byte: bit 0=PINSTOP, bit 6=PWDN, bit 7=RST
            if msg_type_byte == 0x00:
                cmd_2nd_byte = int(raw_data[3], 16)
                pinstop = (cmd_2nd_byte & 0x01) != 0
                if pinstop:
                    events_list.append("💤 LANWAKE# Clear")
                return " | ".join(events_list) if events_list else None

            if msg_type_byte in (0x01, 0x02):
                # Config Write or Read Request from MAC
                # Wire[4]=MSB Data, Wire[3]=LSB Data, Wire[5]=Addr&Ctrl
                reg_byte = int(raw_data[5], 16)
                reg = reg_byte & 0x1F
                value = (int(raw_data[4], 16) << 8) | int(raw_data[3], 16)

                # Page access detection (Reg 31 = page select register)
                if reg == 31:
                    page_num = value >> 5  # Page number in bits [15:5]
                    return f"📄 Page {page_num}"

                # SW Reset (Page 0 Reg 0, bit 15) - IEEE Control Register
                if page == 0 and reg == 0 and (value >> 15) & 1:
                    events_list.append("🔄 SW RESET")
                    state['reset_state'] = 'resetting'

                # Auto-Negotiation Enable (Page 0 Reg 0, bit 12)
                if page == 0 and reg == 0:
                    an_enable = (value >> 12) & 1
                    if an_enable and state.get('an_status') != 'enabled':
                        events_list.append("🤝 AN Start")
                        state['an_status'] = 'enabled'

                # ULP Config (Page 779 Reg 16)
                if page == 779 and reg == 16:
                    wol_me = (value >> 7) & 1
                    wol_host = (value >> 6) & 1
                    if wol_me or wol_host:
                        events_list.append(f"😴 ULP (ME={wol_me},Host={wol_host})")

                # Cable Status (Page 779 Reg 29)
                if page == 779 and reg == 29:
                    if value in [0x00FF, 0xFF00, 0xFFFF]:
                        events_list.append("🔌 Cable Disconn")

                # TX LPI Exit (Page 769 Reg 16, bit 10)
                if page == 769 and reg == 16:
                    if (value >> 10) & 1:
                        events_list.append("⚡ TX LPI Exit")

                # RX Active (Page 769 Reg 17, bit 9)
                if page == 769 and reg == 17:
                    rx_active = (value >> 9) & 1
                    if rx_active:
                        events_list.append("📥 RX Active")
                    # AN Complete (bit 11)
                    if (value >> 11) & 1 and state.get('an_status') == 'enabled':
                        events_list.append("✓ AN Complete")
                        state['an_status'] = 'complete'

                # LANWAKE# Clear (Page 769 Reg 18, bit 3)
                if page == 769 and reg == 18:
                    if (value >> 3) & 1:
                        events_list.append("💤 LANWAKE# Clear")

                # Port Reset (Page 769 Reg 20, bit 15)
                if page == 769 and reg == 20:
                    if (value >> 15) & 1:
                        events_list.append("🔃 Port Reset")

                # SMBus Mode (Page 769 Reg 23, bit 0 - Force SMBus)
                if page == 769 and reg == 23:
                    force_smbus = value & 0x01
                    if force_smbus and not state.get('smbus_mode'):
                        events_list.append("📡 SMBus Mode")
                        state['smbus_mode'] = True
                        state['pcie_mode'] = False
                    elif not force_smbus and state.get('smbus_mode'):
                        events_list.append("🔌 PCIe Mode")
                        state['pcie_mode'] = True
                        state['smbus_mode'] = False

                # EEE/LPI Control (Page 772 Reg 20)
                if page == 772 and reg == 20:
                    eee_1000 = (value >> 14) & 1
                    eee_100 = (value >> 13) & 1
                    force_lpi = (value >> 12) & 1
                    if eee_1000 or eee_100:
                        speed_text = []
                        if eee_1000:
                            speed_text.append("1G")
                        if eee_100:
                            speed_text.append("100M")
                        events_list.append(f"⚡ EEE Enable ({','.join(speed_text)})")
                    if force_lpi:
                        events_list.append("⚡ Force LPI")

                # WOL Wake Up Control (Page 800 Reg 1)
                if page == 800 and reg == 1:
                    pme_status = (value >> 2) & 1
                    pme_en = (value >> 1) & 1
                    apme = value & 1
                    if pme_status:
                        events_list.append("🌟 PME Wake Event")
                    if pme_en:
                        events_list.append("🔔 PME Enabled")
                    if apme:
                        events_list.append("🔔 APM Enabled")

                # WOL Filter Control (Page 800 Reg 2)
                if page == 800 and reg == 2:
                    filter_types = []
                    if (value >> 1) & 1:
                        filter_types.append("Magic")
                    if (value >> 0) & 1:
                        filter_types.append("Link")
                    if (value >> 2) & 1:
                        filter_types.append("Exact")
                    if (value >> 3) & 1:
                        filter_types.append("MC")
                    if (value >> 4) & 1:
                        filter_types.append("BC")
                    if (value >> 5) & 1:
                        filter_types.append("ARP")
                    if (value >> 6) & 1:
                        filter_types.append("IPv4")
                    if (value >> 7) & 1:
                        filter_types.append("IPv6")
                    if filter_types:
                        events_list.append(f"🔍 WOL Filters: {','.join(filter_types)}")

                # WOL Wake Up Status (Page 800 Reg 3)
                if page == 800 and reg == 3:
                    wake_types = []
                    if (value >> 1) & 1:
                        wake_types.append("Magic")
                    if (value >> 0) & 1:
                        wake_types.append("Link")
                    if (value >> 2) & 1:
                        wake_types.append("Exact")
                    if (value >> 3) & 1:
                        wake_types.append("MC")
                    if (value >> 4) & 1:
                        wake_types.append("BC")
                    if (value >> 5) & 1:
                        wake_types.append("ARP")
                    if (value >> 6) & 1:
                        wake_types.append("IPv4")
                    if (value >> 7) & 1:
                        wake_types.append("IPv6")
                    if wake_types:
                        events_list.append(f"🌟 WOL Wake: {','.join(wake_types)}")

                # PCIe Mode (Page 776) - alternative detection
                if page == 776 and reg == 0:
                    if (value >> 0) & 1:
                        events_list.append("🔌 PCIe Mode")

                if events_list:
                    return " | ".join(events_list)
        except Exception:
            pass
    
    return ""


def format_page_register_label(page, page_name, register, register_name):
    """Format register name as: page <page>- <page name>[0x<reg>- <name>]."""
    if page is None or register is None:
        return register_name or ""

    cleaned_name = register_name or ""
    if " PHY Address" in cleaned_name:
        cleaned_name = cleaned_name.split(" PHY Address")[0].strip() + " PHY"

    page_label = f"page {page}- {page_name}" if page_name else f"page {page}"
    reg_num = f"0x{register:02X}"
    reg_label = f"{reg_num}- {cleaned_name}" if cleaned_name else reg_num
    return f"{page_label}[{reg_label}]"

def format_bit_analysis(data_value, reg_info):
    """Format detailed bit analysis showing each bit's name and value in Jacksonville EAS format"""
    if not reg_info or 'bits' not in reg_info:
        return f"Binary: {data_value:016b}"
    
    bit_details = []
    for bit_pos in range(15, -1, -1):  # MSB to LSB
        bit_value = (data_value >> bit_pos) & 1
        bit_name = reg_info['bits'].get(bit_pos, f'Bit {bit_pos}')
        # Use Jacksonville EAS format: Bit[4][Host_WU_Active] = 1
        bit_details.append(f"Bit[{bit_pos}][{bit_name}] = {bit_value}")
    
    # Group bits into rows of 5 with separators and line between groups
    rows = []
    for i in range(0, len(bit_details), 5):
        row_bits = bit_details[i:i+5]
        rows.append("| " + " | ".join(row_bits) + " |")
        # Add line separator after each group of 5 bits (except last)
        if i + 5 < len(bit_details):
            rows.append("---")
    
    return "<br>".join(rows)

def create_lightweight_html_report(filename=None):
    """Create a lightweight HTML report with file selection dialog"""
    
    # If no filename provided, open file dialog
    if not filename:
        root = tk.Tk()
        root.withdraw()  # Hide the main window
        
        filename = filedialog.askopenfilename(
            title="Select SMBus Trace CSV File",
            filetypes=[
                ("CSV files", "*.csv"),
                ("All files", "*.*")
            ],
            initialdir=os.getcwd()
        )
        
        root.destroy()
        
        if not filename:
            print("❌ No file selected!")
            return
    
    if not os.path.exists(filename):
        print(f"Error: File '{filename}' not found!")
        print(f"Current directory: {os.getcwd()}")
        print("Available files:")
        for f in os.listdir("."):
            if f.endswith('.csv'):
                print(f"  - {f}")
        return
    
    print(f"📊 Analyzing {filename}...")
    print(f"📁 Processing entire file (no transaction limits)")
    
    # Parse transactions
    transactions = []
    curr_page = 0
    
    try:
        with open(filename, 'r') as f:
            reader = csv.reader(f)
            data = list(reader)[8:]  # Skip Total Phase header
            
            print(f"📈 Found {len(data)} data rows to process")
            
            # Process ALL transactions, no limits
            for i, row in enumerate(data):
                if len(row) < 10:
                    continue
                    
                trans = parse_transaction_simple(row, i + 1, curr_page)
                
                if trans is None:
                    continue
                
                # Update page tracking
                if trans.get('register') == 31 and 'page_access' in trans:
                    curr_page = trans['page_access']
                    
                transactions.append(trans)
                
                # Progress indicator for large files
                if i % 100 == 0 and i > 0:
                    print(f"  📊 Processed {i} transactions...")
    
    except Exception as e:
        print(f"Error reading file: {e}")
        return
    
    print(f"✅ Successfully processed {len(transactions)} transactions")
    
    # Limit HTML size for performance
    total_transactions = len(transactions)
    truncated = total_transactions > MAX_HTML_TRANSACTIONS
    display_transactions = transactions[:MAX_HTML_TRANSACTIONS] if truncated else transactions

    # Create HTML report
    html_content = generate_html_report(display_transactions, filename, total_transactions, truncated)
    
    # Save to temp file and open in browser
    temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False)
    temp_file.write(html_content)
    temp_file.close()
    
    print(f"\n🚀 Complete HTML report created!")
    print(f"📊 Total transactions analyzed: {len(transactions)}")
    print(f"🌐 Opening in browser: {temp_file.name}")
    webbrowser.open('file://' + temp_file.name)
    
    return transactions

def parse_transaction_simple(row, index, current_page, include_bit_analysis=False):
    """Simplified transaction parsing for better performance"""
    
    # Skip capture metadata rows ("Capture started", "Capture stopped")
    record_field = row[8] if len(row) > 8 else ''
    if 'Capture' in record_field:
        return None

    addr_raw = row[7].strip()
    addr_clean = addr_raw.rstrip('*').upper()
    is_nak = addr_raw.endswith('*')
    is_unexpected = addr_clean not in KNOWN_ADDRESSES

    if is_unexpected:
        nak_suffix = " (NAK)" if is_nak else ""
        direction = f"Addr 0x{addr_clean}{nak_suffix}"
    else:
        direction = PHY_TO_MAC_DIRECTION if addr_clean == '70' else MAC_TO_PHY_DIRECTION

    trans = {
        'index': index,
        'time': row[2],
        'duration': row[3],
        'address': addr_raw,
        'direction': direction,
        'raw_data': row[9].split(),
        'message_type': 'Unknown',
        'register_info': None,
        'unexpected_address': is_unexpected
    }

    # Empty data = NACK (PHY not responding)
    if not trans['raw_data']:
        trans['message_type'] = 'NACK'
        return trans
    
    try:
        if len(trans['raw_data']) == 7:
            # SMBus Block Write transaction
            decoded = decode_smbus_block_write(trans['raw_data'], current_page, include_bit_analysis)
            trans.update(decoded)
        
        elif len(trans['raw_data']) == 4:
            # Check for Wake-up message (D5 command)
            cmd_byte = trans['raw_data'][0].upper()
            if cmd_byte == 'D5':
                trans['message_type'] = 'Wake-up Message'
                try:
                    wake_byte = int(trans['raw_data'][2], 16)
                    trans['wake_indication'] = wake_byte
                    if wake_byte == 0x01:
                        trans['wake_type'] = 'Host Wake'
                    elif wake_byte == 0x02:
                        trans['wake_type'] = 'ME Wake'
                    else:
                        trans['wake_type'] = 'No Wake'
                except Exception:
                    trans['wake_type'] = 'Unknown'
            else:
                trans['message_type'] = 'Status Packet'
            
    except Exception:        pass  # Keep as unknown on error
    
    return trans

def decode_smbus_block_write(data_bytes, current_page, include_bit_analysis=False):
    """Decode SMBus Block Write transaction per Jacksonville EAS 1.12

    Format: CMD(C3/D3) BYTECNT(04) TYPE(00/01/02) B3 B4 B5 PEC
    Wire order: [Cmd][BC][Type/Aux][Wire3][Wire4][Wire5=Addr&Ctrl][PEC]
    - TYPE 0x00: Status message, status_value = (Wire3<<8)|Wire4 (Status2nd|Status1st)
    - TYPE 0x01: Config Write (C3=MtP) / Config Write Ack (D3=PtM)
    - TYPE 0x02: Config Read Request (C3=MtP) / Config Read Response (D3=PtM)
    - For Config types: register = Wire5 & 0x1F, data = (Wire4<<8)|Wire3 (MSB|LSB)
    """
    try:
        cmd = int(data_bytes[0], 16)
        msg_type_byte = int(data_bytes[2], 16)
        b3 = int(data_bytes[3], 16)
        b4 = int(data_bytes[4], 16)
        b5 = int(data_bytes[5], 16)

        is_ptm = (cmd == 0xD3)

        if msg_type_byte == 0x00:
            # Status message
            status_value = (b3 << 8) | b4
            direction = "PtM" if is_ptm else "MtP"
            return {
                'message_type': f'{direction} Status',
                'data_value': status_value,
                'status_value': status_value,
                'status_extra': b5,
                'is_status': True
            }

        elif msg_type_byte in (0x01, 0x02):
            # Config transaction - b4=Wire[4]=MSB Data, b3=Wire[3]=LSB Data
            reg_addr = b5 & 0x1F
            data_value = (b4 << 8) | b3

            if msg_type_byte == 0x01:
                msg_label = "Config Write" if not is_ptm else "Config Write Ack"
            else:
                msg_label = "Config Read Request" if not is_ptm else "Config Read Response"

            # Page Select register
            if reg_addr == 31:
                page_value = data_value >> 5  # Page number in bits [15:5]
                return {
                    'message_type': msg_label,
                    'register': reg_addr,
                    'register_name': 'Page Select',
                    'data_value': data_value,
                    'page_access': page_value,
                    'page_name': get_page_name(page_value),
                    'bit_analysis': f"Page Access: {page_value} ({get_page_name(page_value)})" if include_bit_analysis else None
                }

            reg_info = get_register_info(current_page, reg_addr)
            bit_analysis = format_bit_analysis(data_value, reg_info) if include_bit_analysis else None

            return {
                'message_type': msg_label,
                'page': current_page,
                'page_name': get_page_name(current_page),
                'register': reg_addr,
                'register_name': reg_info['name'],
                'data_value': data_value,
                'register_info': reg_info,
                'bit_analysis': bit_analysis
            }

        else:
            return {'message_type': f'Unknown Type 0x{msg_type_byte:02X}'}

    except Exception:
        return {'message_type': 'Parse Error'}

def generate_html_report(transactions, filename, total_count, truncated):
    """Generate lightweight HTML report"""
    total = total_count
    config_count = len([t for t in transactions if 'Config' in t['message_type']])
    show_bit_analysis = total_count <= BIT_ANALYSIS_LIMIT
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>SMBus Analysis - {filename}</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; font-size: 12px; }}
            .container {{ max-width: 1400px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }}
            .header {{ background: #2c5aa0; color: white; padding: 15px; margin: -20px -20px 20px -20px; font-size: 16px; }}
            .summary {{ background: #e8f4f8; padding: 15px; border-radius: 5px; margin-bottom: 20px; font-size: 13px; }}
            .transaction {{ background: #f9f9f9; margin: 8px 0; padding: 10px; border-left: 4px solid #2c5aa0; }}
            .main-data {{ min-width: 400px; }}
            .transaction-header {{ font-size: 14px; font-weight: bold; color: #2c5aa0; margin-bottom: 8px; }}
            .register-info {{ background: #fff9e6; padding: 8px; border-radius: 3px; margin: 5px 0; font-size: 11px; }}
            .bit-info {{ font-family: monospace; font-size: 10px; color: #666; line-height: 1.2; }}
            .bit-detail {{ background: #f0f8ff; padding: 8px; margin: 3px 0; border-radius: 3px; font-family: monospace; font-size: 10px; line-height: 1.3; }}
            details {{ margin-top: 6px; }}
            summary {{ cursor: pointer; color: #2c5aa0; font-weight: bold; }}
            .page-info {{ color: #2c5aa0; font-weight: bold; font-size: 12px; }}
            .mdio {{ border-left-color: #28a745; }}
            .status {{ border-left-color: #ffc107; }}
            .error {{ border-left-color: #dc3545; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Jacksonville PHY SMBus Analysis</h1>
                <p>Lightweight Browser-based Report</p>
            </div>
            
            <div class="summary">
                <h2>Analysis Summary</h2>
                <p><strong>File:</strong> {filename}</p>
                <p><strong>Total Transactions:</strong> {total}</p>
                <p><strong>Config Messages (in view):</strong> {config_count}</p>
                <p><strong>Status Messages (in view):</strong> {len(transactions) - config_count}</p>
                <p><strong>Rendered Transactions:</strong> {len(transactions)}</p>
                <p><strong>Bit Analysis:</strong> {'Enabled' if show_bit_analysis else 'Disabled (large file)'}</p>
                {"<p><strong>Note:</strong> Report is truncated for performance.</p>" if truncated else ""}
            </div>
            
            <h2>Transaction Details</h2>
    """
    
    for trans in transactions:  # Show ALL transactions
        css_class = 'mdio' if 'Config' in trans['message_type'] else 'status' if 'Status' in trans['message_type'] else 'error'
        
        html += f"""
        <div class="transaction {css_class}">
            <div class="main-data">
                <div class="transaction-header">[{trans['index']}] {trans['time']} ({trans['duration']})</div>
                <strong>Direction:</strong> {trans['direction']}<br>
                <strong>Type:</strong> {trans['message_type']}<br>
        """
        
        # Display page first, then register
        if trans.get('page') is not None:
            page_name = trans.get('page_name', 'Unknown Page')
            html += f"<span class='page-info'>Page {trans['page']}: {page_name}</span><br>"
            
        if trans.get('register') is not None:
            register_display = format_register_display(
                trans.get('page'),
                trans.get('register'),
                trans.get('register_name', 'Unknown Register')
            )
            if register_display:
                html += f"<strong>Register:</strong> {register_display}<br>"
            else:
                html += f"<strong>Register:</strong> 0x{trans['register']:02X}"
                if trans.get('register_name'):
                    html += f" - {trans['register_name']}"
                html += "<br>"
            
        if trans.get('data_value') is not None:
            html += f"<strong>Data:</strong> 0x{trans['data_value']:04X} ({trans['data_value']})<br>"
            html += f"<span class='bit-info'>Binary: {trans['data_value']:016b}</span><br>"
            
        html += f"<span class='bit-info'>Raw: {' '.join(trans['raw_data'])}</span>"
        if show_bit_analysis and trans.get('bit_analysis'):
            html += f"<details><summary>Bit Analysis</summary><div class='bit-detail'>{trans['bit_analysis']}</div></details>"
        html += "</div>"
        
        html += "</div>"
    
    html += f"""
            <p style='margin-top: 20px; color: #666;'><em>Report shows all {len(transactions)} transactions from selected file.</em></p>
        </div>
    </body>
    </html>
    """
    
    return html

def create_in_app_report(filename=None, page_size=500, window_size="1200x800", tab_font_size=10, table_font_size=9):
    """Create an in-app report viewer with pagination and on-demand bit analysis"""

    if not filename:
        root = tk.Tk()
        root.withdraw()
        filename = filedialog.askopenfilename(
            title="Select SMBus Trace CSV File",
            filetypes=[
                ("CSV files", "*.csv"),
                ("All files", "*.*")
            ],
            initialdir=os.getcwd()
        )
        root.destroy()

        if not filename:
            return

    if not os.path.exists(filename):
        messagebox.showerror("File Not Found", f"File '{filename}' not found.")
        return

    transactions = []
    curr_page = 0

    try:
        with open(filename, 'r') as f:
            reader = csv.reader(f)
            data = list(reader)[8:]

            for i, row in enumerate(data):
                if len(row) < 10:
                    continue
                trans = parse_transaction_simple(row, i + 1, curr_page, include_bit_analysis=False)
                if trans is None:
                    continue
                if trans.get('register') == 31 and 'page_access' in trans:
                    curr_page = trans['page_access']
                transactions.append(trans)
    except Exception as e:
        messagebox.showerror("Error", f"Error reading file: {e}")
        return

    total = len(transactions)
    total_pages = max(1, math.ceil(total / page_size))

    root = tk._default_root
    window = tk.Toplevel(root) if root else tk.Tk()
    window.title("Jacksonville PHY SMBus Analyzer")
    window.geometry(window_size)
    window.minsize(1100, 750)

    # VS Code dark theme colors
    colors = {
        'bg': '#1e1e1e',
        'surface': '#252526',
        'surface_light': '#2d2d2d',
        'accent': '#007acc',
        'accent_hover': '#1c97ea',
        'text': '#cccccc',
        'text_bright': '#ffffff',
        'text_dim': '#808080',
        'success': '#4ec9b0',
        'border': '#3c3c3c',
        'header_bg': '#323233',
        'row_alt': '#2a2d2e',
        'row_border': '#ffffff',
        'selection': '#264f78',
        'tab_active': '#1e1e1e',
        'tab_inactive': '#2d2d2d'
    }

    window.configure(bg=colors['bg'])

    # VS Code styling
    style = ttk.Style(window)
    style.theme_use('clam')
    
    style.configure(".", background=colors['bg'], foreground=colors['text'])
    style.configure("TFrame", background=colors['bg'])
    style.configure("TLabelframe", background=colors['surface'], foreground=colors['text'])
    style.configure("TLabelframe.Label", background=colors['surface'], foreground=colors['accent'], font=("Segoe UI", 10))
    
    style.configure("Report.TNotebook", background=colors['header_bg'], borderwidth=2, tabmargins=[2, 2, 2, 0])
    style.configure("Report.TNotebook.Tab", 
                    font=("Segoe UI", 10, "bold"), 
                    padding=[18, 10],
                    background=colors['tab_inactive'],
                    foreground=colors['text_dim'],
                    borderwidth=2,
                    relief='raised')
    style.map("Report.TNotebook.Tab",
              background=[('selected', colors['tab_active'])],
              foreground=[('selected', colors['text_bright'])],
              borderwidth=[('selected', 2)],
              relief=[('selected', 'solid')],
              expand=[('selected', [2, 2, 2, 3])])
    
    style.configure("Treeview", 
                    font=("Consolas", 10), 
                    rowheight=34,
                    background='#ffffff',
                    foreground=colors['text'],
                    fieldbackground=colors['surface'],
                    borderwidth=3,
                    relief='solid',
                    bordercolor='#ffffff')
    style.configure("Treeview.Heading", 
                    font=("Segoe UI", 10, "bold"),
                    background=colors['header_bg'],
                    foreground='#ffffff',
                    padding=[10, 8],
                    borderwidth=3,
                    relief='raised')
    style.map("Treeview", 
              background=[('selected', colors['selection'])],
              foreground=[('selected', colors['text_bright'])])
    style.map("Treeview.Heading",
              background=[('active', colors['surface_light'])])
    
    style.configure("Vertical.TScrollbar", 
                    background=colors['surface_light'], 
                    troughcolor=colors['surface'],
                    borderwidth=0,
                    arrowsize=14)
    style.map("Vertical.TScrollbar",
              background=[('active', colors['text_dim'])])
    style.configure("TPanedwindow", background=colors['border'])
    style.configure("Sash", sashthickness=4, gripcount=0)
    
    # Configure notebook tabs with spacing
    style.configure("TNotebook", tabmargins=[2, 5, 2, 0])
    style.configure("TNotebook.Tab", padding=[20, 10], font=("Segoe UI", 9))

    # VS Code style title bar
    header = tk.Frame(window, bg=colors['header_bg'], height=35)
    header.pack(fill=tk.X)
    header.pack_propagate(False)

    header_inner = tk.Frame(header, bg=colors['header_bg'])
    header_inner.pack(fill=tk.BOTH, expand=True, padx=10, pady=6)

    tk.Label(header_inner, text="Jacksonville PHY SMBus Analyzer", 
             font=("Segoe UI", 11), bg=colors['header_bg'], fg=colors['text']).pack(side=tk.LEFT)
    
    tk.Label(header_inner, text=f"{os.path.basename(filename)}  —  {total:,} transactions", 
             font=("Segoe UI", 10), bg=colors['header_bg'], fg=colors['text_dim']).pack(side=tk.RIGHT)

    # VS Code style toolbar
    toolbar = tk.Frame(window, bg=colors['surface'], height=40)
    toolbar.pack(fill=tk.X)
    toolbar.pack_propagate(False)

    # Red warning banner for unexpected addresses
    unexpected_addrs = {}
    for t in transactions:
        if t.get('unexpected_address'):
            a = t['address']
            unexpected_addrs[a] = unexpected_addrs.get(a, 0) + 1
    if unexpected_addrs:
        addr_list = ', '.join(f"0x{a} ({c}x)" for a, c in sorted(unexpected_addrs.items()))
        warn_frame = tk.Frame(window, bg='#CC0000')
        warn_frame.pack(fill=tk.X)
        tk.Label(warn_frame,
                 text=f"\u26a0  WARNING: Unexpected SMBus addresses detected: {addr_list}  —  "
                      f"Expected: 0x64 (MAC\u2192PHY) and 0x70 (PHY\u2192MAC) only. "
                      f"Use the \"Unexpected addresses\" filter to review.",
                 font=("Segoe UI", 10, "bold"), bg='#CC0000', fg='white',
                 wraplength=1100, justify=tk.LEFT, padx=10, pady=6).pack(fill=tk.X)

    toolbar_inner = tk.Frame(toolbar, bg=colors['surface'])
    toolbar_inner.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

    # Search
    tk.Label(toolbar_inner, text="🔍 Search:", font=("Segoe UI", 10), bg=colors['surface'], fg=colors['text']).pack(side=tk.LEFT)
    search_var = tk.StringVar()
    search_entry = tk.Entry(toolbar_inner, textvariable=search_var, width=25, font=("Segoe UI", 10),
                            bg=colors['bg'], fg=colors['text'], relief='solid', bd=1)
    search_entry.pack(side=tk.LEFT, padx=(8, 10))

    filtered_transactions = transactions.copy()
    quick_filter_var = tk.StringVar(value="All traffic")
    quick_filter_options = [
        "All traffic",
        "MAC -> PHY",
        "PHY -> MAC",
        "Unexpected addresses",
        "MDIO config",
        "Config writes",
        "Config reads",
        "Status packets",
        "Wake messages",
        "NACK / no response",
        "Page selects",
        "Unknown decode",
    ]

    def transaction_search_text(trans):
        """Build searchable text from every field users naturally look for."""
        data_value = trans.get('data_value')
        data_text = ""
        if data_value is not None:
            data_text = f"0x{data_value:04x} {data_value}"

        register = trans.get('register')
        register_text = ""
        if register is not None:
            register_text = f"reg {register} register {register} 0x{register:02x}"

        page = trans.get('page')
        page_text = ""
        if page is not None:
            page_text = f"page {page} 0x{page:x}"

        page_access = trans.get('page_access')
        page_access_text = ""
        if page_access is not None:
            page_access_text = f"page select {page_access} 0x{page_access:x}"

        event_text = transaction_events.get(trans.get('index'), "") if 'transaction_events' in locals() else ""

        fields = [
            trans.get('index'),
            trans.get('time'),
            trans.get('duration'),
            f"0x{trans.get('address', '')}" if trans.get('address') else None,
            "unexpected" if trans.get('unexpected_address') else None,
            trans.get('direction'),
            trans.get('message_type'),
            trans.get('page_name'),
            trans.get('register_name'),
            trans.get('wake_type'),
            trans.get('details'),
            event_text,
            data_text,
            register_text,
            page_text,
            page_access_text,
            " ".join(trans.get('raw_data', [])),
        ]
        return " ".join(str(field).lower() for field in fields if field is not None)

    def transaction_matches_quick_filter(trans):
        selected_filter = quick_filter_var.get()
        if selected_filter == "All traffic":
            return True

        direction = str(trans.get('direction', ''))
        message_type = str(trans.get('message_type', ''))
        raw_data = trans.get('raw_data', [])

        if selected_filter == "MAC -> PHY":
            return direction == MAC_TO_PHY_DIRECTION
        if selected_filter == "PHY -> MAC":
            return direction == PHY_TO_MAC_DIRECTION
        if selected_filter == "Unexpected addresses":
            return trans.get('unexpected_address', False)
        if selected_filter == "MDIO config":
            return len(raw_data) == 7 or "Config" in message_type
        if selected_filter == "Config writes":
            return "Write" in message_type
        if selected_filter == "Config reads":
            return "Read" in message_type
        if selected_filter == "Status packets":
            return "Status" in message_type
        if selected_filter == "Wake messages":
            return message_type == "Wake-up Message"
        if selected_filter == "NACK / no response":
            return message_type == "NACK"
        if selected_filter == "Page selects":
            return trans.get('register') == 31 or trans.get('page_access') is not None
        if selected_filter == "Unknown decode":
            return message_type == "Unknown"

        return True

    def do_search():
        nonlocal filtered_transactions, total_pages
        query = search_var.get().strip().lower()
        if not query:
            filtered_transactions = [
                t for t in transactions
                if transaction_matches_quick_filter(t)
            ]
        else:
            terms = query.split()
            filtered_transactions = [
                t for t in transactions
                if transaction_matches_quick_filter(t)
                and all(term in transaction_search_text(t) for term in terms)
            ]
        total_pages = max(1, math.ceil(len(filtered_transactions) / page_size))
        page_var.set(1)
        render_page()
        results_label.config(text=f"{len(filtered_transactions)} / {total} results")
        notebook.select(0)

    search_btn = tk.Button(toolbar_inner, text="Search", command=do_search, font=("Segoe UI", 9),
                           bg=colors['accent'], fg='white', relief='flat', padx=10, pady=2, cursor='hand2')
    search_btn.pack(side=tk.LEFT, padx=(8, 0))
    
    clear_btn = tk.Button(toolbar_inner, text="Clear", command=lambda: (search_var.set(''), do_search()), 
                          font=("Segoe UI", 9), bg=colors['surface_light'], fg=colors['text'], relief='flat', 
                          padx=10, pady=2, cursor='hand2')
    clear_btn.pack(side=tk.LEFT, padx=(4, 0))
    search_entry.bind("<Return>", lambda event: do_search())
    window.bind("<Control-f>", lambda event: (search_entry.focus_set(), search_entry.select_range(0, tk.END), "break"))

    tk.Label(toolbar_inner, text="Filter:", font=("Segoe UI", 9), bg=colors['surface'], fg=colors['text_dim']).pack(side=tk.LEFT, padx=(12, 4))
    quick_filter_menu = tk.OptionMenu(toolbar_inner, quick_filter_var, *quick_filter_options, command=lambda value: do_search())
    quick_filter_menu.config(font=("Segoe UI", 9), bg=colors['surface_light'], fg=colors['text'],
                             activebackground=colors['border'], activeforeground=colors['text'],
                             relief='flat', bd=0, highlightthickness=0, width=15)
    quick_filter_menu["menu"].config(bg=colors['surface_light'], fg=colors['text'], activebackground=colors['selection'])
    quick_filter_menu.pack(side=tk.LEFT, padx=(0, 0))

    results_label = tk.Label(toolbar_inner, text=f"{total} results", font=("Consolas", 9), 
                             bg=colors['surface'], fg=colors['success'])
    results_label.pack(side=tk.LEFT, padx=(12, 0))

    # Separator
    tk.Frame(toolbar_inner, width=1, bg=colors['border']).pack(side=tk.LEFT, fill=tk.Y, padx=15)

    # Page navigation
    page_var = tk.IntVar(value=1)
    page_label = tk.Label(toolbar_inner, text="Page 1 / 1", font=("Consolas", 9), bg=colors['surface'], fg=colors['text_dim'])
    page_label.pack(side=tk.LEFT, padx=(0, 8))

    def update_page_label():
        page_label.config(text=f"Page {page_var.get()} / {total_pages}")

    # Pre-compute events for all transactions
    event_state = {}
    transaction_events = {}
    for trans in transactions:
        event_text = detect_transaction_event(trans, event_state)
        if event_text:
            transaction_events[trans.get('index')] = event_text

    # Configure alternating row colors
    style.configure("Treeview", rowheight=28)
    
    def render_page():
        tree.delete(*tree.get_children())
        current_page = page_var.get()
        start = (current_page - 1) * page_size
        end = min(start + page_size, len(filtered_transactions))
        for i in range(start, end):
            trans = filtered_transactions[i]
            idx = transactions.index(trans)
            
            # Get event for this transaction
            event_display = transaction_events.get(trans.get('index'), "")
            
            # Separate page and register display
            if trans.get('register') == 31 and trans.get('page_access') is not None:
                page_num = trans.get('page_access')
                page_name = get_page_name(page_num)
                page_display = f"{page_num} - {page_name}"
                register_display = "Page Select"
            else:
                page_num = trans.get('page')
                page_name = trans.get('page_name', '')
                page_display = f"{page_num} - {page_name}" if page_num is not None else ""
                
                reg_num = trans.get('register')
                reg_name = trans.get('register_name', '')
                if reg_name and " PHY Address" in reg_name:
                    reg_name = reg_name.split(" PHY Address")[0].strip()
                register_display = f"0x{reg_num:02X} - {reg_name}" if reg_num is not None else ""
            
            data_display = ""
            if trans.get('data_value') is not None:
                data_display = f"0x{trans['data_value']:04X}"
            
            # Alternate row colors for better readability
            row_tag = 'unexpected' if trans.get('unexpected_address') else ('evenrow' if i % 2 == 0 else 'oddrow')
            
            tree.insert(
                "",
                "end",
                iid=str(idx),
                values=(
                    trans.get('index'),
                    trans.get('time'),
                    event_display,
                    data_display,
                    trans.get('direction'),
                    trans.get('message_type'),
                    page_display,
                    register_display
                ),
                tags=(row_tag,)
            )
        update_page_label()

    def prev_page():
        if page_var.get() > 1:
            page_var.set(page_var.get() - 1)
            render_page()

    def next_page():
        if page_var.get() < total_pages:
            page_var.set(page_var.get() + 1)
            render_page()

    prev_btn = tk.Button(toolbar_inner, text="◀", command=prev_page, font=("Segoe UI", 9),
                         bg=colors['surface_light'], fg=colors['text'], relief='flat', padx=8, pady=2, cursor='hand2')
    prev_btn.pack(side=tk.LEFT)
    
    next_btn = tk.Button(toolbar_inner, text="▶", command=next_page, font=("Segoe UI", 9),
                         bg=colors['surface_light'], fg=colors['text'], relief='flat', padx=8, pady=2, cursor='hand2')
    next_btn.pack(side=tk.LEFT, padx=(2, 0))

    # Jump to page
    tk.Label(toolbar_inner, text="Go to:", font=("Segoe UI", 9), bg=colors['surface'], fg=colors['text_dim']).pack(side=tk.LEFT, padx=(12, 4))
    jump_var = tk.StringVar()
    jump_entry = tk.Entry(toolbar_inner, textvariable=jump_var, width=4, font=("Consolas", 10),
                          bg=colors['surface_light'], fg=colors['text'], relief='flat', bd=0)
    jump_entry.pack(side=tk.LEFT)
    
    def jump_to_page():
        try:
            p = int(jump_var.get())
            if 1 <= p <= total_pages:
                page_var.set(p)
                render_page()
        except Exception:            pass
    
    go_btn = tk.Button(toolbar_inner, text="Go", command=jump_to_page, font=("Segoe UI", 9),
                       bg=colors['accent'], fg='white', relief='flat', padx=8, pady=2, cursor='hand2')
    go_btn.pack(side=tk.LEFT, padx=(4, 0))

    # Main content with PanedWindow for resizable details
    main_paned = tk.PanedWindow(window, orient=tk.VERTICAL, sashwidth=4, sashrelief=tk.FLAT, 
                                 bg=colors['border'], bd=0)
    main_paned.pack(fill=tk.BOTH, expand=True, padx=0, pady=0)

    # Top section - Notebook with tabs
    top_frame = tk.Frame(main_paned, bg=colors['bg'])
    main_paned.add(top_frame, minsize=200)

    notebook = ttk.Notebook(top_frame, style="Report.TNotebook")
    notebook.pack(fill=tk.BOTH, expand=True)

    # Transactions tab
    tree_frame = tk.Frame(notebook, bg=colors['surface'])
    notebook.add(tree_frame, text="  Transactions  ")

    # Statistics tab
    stats_tab = tk.Frame(notebook, bg=colors['surface'])
    notebook.add(stats_tab, text="  Statistics  ")

    stats_canvas = tk.Canvas(stats_tab, bg=colors['surface'], highlightthickness=0, bd=0)
    stats_scrollbar = ttk.Scrollbar(stats_tab, orient=tk.VERTICAL, command=stats_canvas.yview)
    stats_canvas.configure(yscrollcommand=stats_scrollbar.set)
    stats_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    stats_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    stats_content = tk.Frame(stats_canvas, bg=colors['surface'], padx=20, pady=20)
    stats_window = stats_canvas.create_window((0, 0), window=stats_content, anchor="nw")

    def update_stats_scrollregion(event=None):
        stats_canvas.configure(scrollregion=stats_canvas.bbox("all"))

    def resize_stats_content(event):
        stats_canvas.itemconfigure(stats_window, width=event.width)

    def stats_mousewheel(event):
        if event.num == 4:
            stats_canvas.yview_scroll(-3, "units")
        elif event.num == 5:
            stats_canvas.yview_scroll(3, "units")
        else:
            stats_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    stats_content.bind("<Configure>", update_stats_scrollregion)
    stats_canvas.bind("<Configure>", resize_stats_content)
    stats_canvas.bind("<Enter>", lambda event: stats_canvas.bind_all("<MouseWheel>", stats_mousewheel))
    stats_canvas.bind("<Leave>", lambda event: stats_canvas.unbind_all("<MouseWheel>"))
    stats_canvas.bind("<Button-4>", stats_mousewheel)
    stats_canvas.bind("<Button-5>", stats_mousewheel)

    # Build statistics
    direction_counts = {}
    page_counts = {}
    register_counts = {}
    wake_counts = {'Host Wake': 0, 'ME Wake': 0, 'No Wake': 0}
    address_counts = {}

    for t in transactions:
        d = t.get('direction', 'Unknown')
        direction_counts[d] = direction_counts.get(d, 0) + 1
        a = t.get('address', '??')
        address_counts[a] = address_counts.get(a, 0) + 1
        p = t.get('page')
        if p is not None:
            pn = f"{p} - {t.get('page_name', 'Unknown')}"
            page_counts[pn] = page_counts.get(pn, 0) + 1
        r = t.get('register_name', '')
        if r:
            register_counts[r] = register_counts.get(r, 0) + 1
        # Track wake events
        if t.get('message_type') == 'Wake-up Message':
            wake_type = t.get('wake_type', 'Unknown')
            if wake_type in wake_counts:
                wake_counts[wake_type] += 1

    # VS Code style stats layout
    stats_left = tk.Frame(stats_content, bg=colors['surface'])
    stats_left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 30))

    # Address distribution
    tk.Label(stats_left, text="Address Distribution", font=("Segoe UI", 12),
             bg=colors['surface'], fg=colors['accent']).pack(anchor=tk.W, pady=(0, 8))
    for a, c in sorted(address_counts.items()):
        a_clean = a.rstrip('*').upper()
        is_unexpected = a_clean not in KNOWN_ADDRESSES
        fg = '#ff3333' if is_unexpected else colors['text']
        suffix = "  ⚠️ UNEXPECTED" if is_unexpected else ""
        tk.Label(stats_left, text=f"0x{a}: {c:,}{suffix}", font=("Consolas", 10),
                 bg=colors['surface'], fg=fg).pack(anchor=tk.W, pady=1)

    tk.Frame(stats_left, bg=colors['border'], height=1).pack(fill=tk.X, pady=10)

    tk.Label(stats_left, text="Direction Summary", font=("Segoe UI", 12), 
             bg=colors['surface'], fg=colors['accent']).pack(anchor=tk.W, pady=(0, 8))
    for d, c in sorted(direction_counts.items(), key=lambda x: -x[1]):
        tk.Label(stats_left, text=f"{d}: {c:,}", font=("Consolas", 10), 
                 bg=colors['surface'], fg=colors['text']).pack(anchor=tk.W, pady=1)

    # Wake Events Summary
    total_wakes = wake_counts['Host Wake'] + wake_counts['ME Wake']
    tk.Label(stats_left, text="\n🔔 Wake Events", font=("Segoe UI", 12), 
             bg=colors['surface'], fg=colors['accent']).pack(anchor=tk.W, pady=(12, 8))
    
    if total_wakes > 0:
        if wake_counts['Host Wake'] > 0:
            tk.Label(stats_left, text=f"Host Wake: {wake_counts['Host Wake']}", font=("Consolas", 10, "bold"), 
                     bg=colors['surface'], fg='#4ec9b0').pack(anchor=tk.W, pady=1)
        if wake_counts['ME Wake'] > 0:
            tk.Label(stats_left, text=f"ME Wake: {wake_counts['ME Wake']}", font=("Consolas", 10, "bold"), 
                     bg=colors['surface'], fg='#dcdcaa').pack(anchor=tk.W, pady=1)
        tk.Label(stats_left, text=f"Total Wake Messages: {total_wakes}", font=("Consolas", 10), 
                 bg=colors['surface'], fg=colors['text']).pack(anchor=tk.W, pady=1)
    else:
        tk.Label(stats_left, text="No wake events detected", font=("Consolas", 10), 
                 bg=colors['surface'], fg=colors['text_dim']).pack(anchor=tk.W, pady=1)

    tk.Label(stats_left, text="\nTop Pages Accessed", font=("Segoe UI", 12), 
             bg=colors['surface'], fg=colors['accent']).pack(anchor=tk.W, pady=(12, 8))
    for p, c in sorted(page_counts.items(), key=lambda x: -x[1])[:10]:
        tk.Label(stats_left, text=f"{p}: {c:,}", font=("Consolas", 10), 
                 bg=colors['surface'], fg=colors['text']).pack(anchor=tk.W, pady=1)

    stats_right = tk.Frame(stats_content, bg=colors['surface'])
    stats_right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    
    tk.Label(stats_right, text="Top Registers Accessed", font=("Segoe UI", 12), 
             bg=colors['surface'], fg=colors['accent']).pack(anchor=tk.W, pady=(0, 8))
    for r, c in sorted(register_counts.items(), key=lambda x: -x[1])[:15]:
        short_name = r[:45] + "..." if len(r) > 45 else r
        tk.Label(stats_right, text=f"{short_name}: {c:,}", font=("Consolas", 10), 
                 bg=colors['surface'], fg=colors['text']).pack(anchor=tk.W, pady=1)

    # ==================== EVENTS TAB ====================
    events_tab = tk.Frame(notebook, bg=colors['surface'])
    notebook.add(events_tab, text="  📋 Events  ")
    
    # Detect flow events
    flow_events = detect_flow_events(transactions)
    
    # Events header
    events_header = tk.Frame(events_tab, bg=colors['header_bg'], pady=8, padx=15)
    events_header.pack(fill=tk.X)
    
    tk.Label(events_header, text=f"Flow Events Timeline ({len(flow_events)} events detected)", 
             font=("Segoe UI", 11, "bold"), bg=colors['header_bg'], fg=colors['text_bright']).pack(side=tk.LEFT)
    
    # Events list with scrollbar
    events_container = tk.Frame(events_tab, bg=colors['surface'])
    events_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    # Create Treeview for events
    events_columns = ("line", "time", "event", "description")
    # Create frame for events tree with scrollbars
    events_tree_frame = tk.Frame(events_container, bg=colors['surface'])
    events_tree_frame.pack(fill=tk.BOTH, expand=True)
    
    events_tree = ttk.Treeview(events_tree_frame, columns=events_columns, show="headings", height=20)
    
    events_tree.heading("line", text="Line #")
    events_tree.heading("time", text="Time")
    events_tree.heading("event", text="Event")
    events_tree.heading("description", text="Description")
    
    events_tree.column("line", width=70, anchor=tk.CENTER)
    events_tree.column("time", width=120, anchor=tk.W)
    events_tree.column("event", width=200, anchor=tk.W)
    events_tree.column("description", width=450, anchor=tk.W)
    
    # Add vertical and horizontal scrollbars
    events_scrollbar_y = ttk.Scrollbar(events_tree_frame, orient=tk.VERTICAL, command=events_tree.yview)
    events_scrollbar_x = ttk.Scrollbar(events_tree_frame, orient=tk.HORIZONTAL, command=events_tree.xview)
    events_tree.configure(yscrollcommand=events_scrollbar_y.set, xscrollcommand=events_scrollbar_x.set)
    
    events_tree.grid(row=0, column=0, sticky='nsew')
    events_scrollbar_y.grid(row=0, column=1, sticky='ns')
    events_scrollbar_x.grid(row=1, column=0, sticky='ew')
    
    events_tree_frame.grid_rowconfigure(0, weight=1)
    events_tree_frame.grid_columnconfigure(0, weight=1)
    
    # Configure alternating row colors for events with border effect
    events_tree.tag_configure('oddrow', background=colors['surface'])
    events_tree.tag_configure('evenrow', background=colors['row_alt'])
    # Simulate row borders with contrasting colors
    
    # Populate events
    for idx, event in enumerate(flow_events):
        event_type = event.get('type', 'UNKNOWN')
        event_info = EVENT_TYPES.get(event_type, {'icon': '❓', 'name': event_type})
        event_display = f"{event_info['icon']} {event_info['name']}"
        
        # Alternate row colors
        tag = 'evenrow' if idx % 2 == 0 else 'oddrow'
        
        events_tree.insert("", "end", values=(
            event.get('index', ''),
            event.get('time', ''),
            event_display,
            event.get('description', '')
        ), tags=(tag,))
    
    # Event summary at bottom
    events_summary = tk.Frame(events_tab, bg=colors['surface_light'], pady=8, padx=15)
    events_summary.pack(fill=tk.X, side=tk.BOTTOM)
    
    # Count events by type category
    wake_events = len([e for e in flow_events if 'WAKE' in e.get('type', '')])
    link_events = len([e for e in flow_events if 'LINK' in e.get('type', '') or 'SPEED' in e.get('type', '') or 'DUPLEX' in e.get('type', '')])
    reset_events = len([e for e in flow_events if 'RESET' in e.get('type', '')])
    mode_events = len([e for e in flow_events if 'MODE' in e.get('type', '')])
    other_events = len(flow_events) - wake_events - link_events - reset_events - mode_events
    
    summary_text = f"🔔 Wake: {wake_events}  |  🔗 Link/Speed: {link_events}  |  🔄 Reset: {reset_events}  |  📡 Mode: {mode_events}  |  📋 Other: {other_events}"
    tk.Label(events_summary, text=summary_text, font=("Consolas", 10), 
             bg=colors['surface_light'], fg=colors['text']).pack(side=tk.LEFT)
    
    # Function to jump to transaction when event is clicked
    def on_event_select(event_widget):
        selected = events_tree.selection()
        if selected:
            item = events_tree.item(selected[0])
            line_num = item['values'][0]
            if line_num:
                # Switch to Transactions tab
                notebook.select(0)
                # Find the transaction index in filtered_transactions
                target_idx = None
                for i, trans in enumerate(filtered_transactions):
                    if trans.get('index') == line_num:
                        target_idx = i
                        break
                
                if target_idx is not None:
                    # Calculate which page this transaction is on
                    target_page = (target_idx // page_size) + 1
                    # Navigate to the correct page
                    page_var.set(target_page)
                    render_page()
                    update_page_label()
                    
                    # Now find and select the transaction in the tree
                    for item_id in tree.get_children():
                        if tree.set(item_id, 'index') == str(line_num):
                            tree.selection_set(item_id)
                            tree.see(item_id)
                            tree.focus(item_id)
                            show_details()
                            break
    
    events_tree.bind('<Double-1>', on_event_select)

    # Columns - data next to event for quick scanning
    columns = ("index", "time", "event", "data", "direction", "type", "page", "register")
    tree = ttk.Treeview(tree_frame, columns=columns, show="headings")

    headings = {
        "index": "Line #",
        "time": "Time",
        "event": "🔔 Event",
        "data": "Data",
        "direction": "Direction",
        "type": "Type",
        "page": "Page",
        "register": "Register"
    }

    col_widths = {
        "index": 60,
        "time": 100,
        "event": 180,
        "data": 100,
        "direction": 140,
        "type": 95,
        "page": 180,
        "register": 250
    }

    for col in columns:
        tree.heading(col, text=headings[col])
        tree.column(col, width=col_widths.get(col, 100), anchor=tk.W, stretch=True)
    
    # Configure row colors for alternating backgrounds with border effect
    tree.tag_configure('oddrow', background=colors['surface'])
    tree.tag_configure('evenrow', background=colors['row_alt'])
    tree.tag_configure('unexpected', background='#3d1111', foreground='#ff6666')
    # Simulate row borders through alternating colors

    def autosize_column(col):
        font = tkfont.nametofont("TkDefaultFont")
        max_width = font.measure(headings.get(col, col))
        for item in tree.get_children(""):
            value = tree.set(item, col)
            max_width = max(max_width, font.measure(str(value)))
        tree.column(col, width=max_width + 24)

    def on_double_click(event):
        region = tree.identify_region(event.x, event.y)
        if region == "heading":
            col = tree.identify_column(event.x)
            col_index = int(col.replace("#", "")) - 1
            if col_index >= 0 and col_index < len(columns):
                autosize_column(columns[col_index])
        elif region == "separator":
            col = tree.identify_column(event.x)
            col_index = int(col.replace("#", "")) - 1
            if col_index >= 0 and col_index < len(columns):
                autosize_column(columns[col_index])

    tree.bind("<Double-1>", on_double_click)

    # Add both vertical and horizontal scrollbars
    scrollbar_y = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=tree.yview)
    scrollbar_x = ttk.Scrollbar(tree_frame, orient=tk.HORIZONTAL, command=tree.xview)
    tree.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)
    
    tree.grid(row=0, column=0, sticky='nsew')
    scrollbar_y.grid(row=0, column=1, sticky='ns')
    scrollbar_x.grid(row=1, column=0, sticky='ew')
    
    tree_frame.grid_rowconfigure(0, weight=1)
    tree_frame.grid_columnconfigure(0, weight=1)

    # Bottom section - Details (resizable via PanedWindow sash)
    bottom_frame = tk.Frame(main_paned, bg=colors['surface'])
    main_paned.add(bottom_frame, minsize=120)

    details_header = tk.Frame(bottom_frame, bg=colors['header_bg'], pady=6, padx=10)
    details_header.pack(fill=tk.X)
    
    tk.Label(details_header, text="DETAILS", font=("Segoe UI", 9),
             bg=colors['header_bg'], fg=colors['text_dim']).pack(side=tk.LEFT)

    copy_frame = tk.Frame(details_header, bg=colors['header_bg'])
    copy_frame.pack(side=tk.RIGHT)

    details_inner = tk.Frame(bottom_frame, bg=colors['surface'])
    details_inner.pack(fill=tk.BOTH, expand=True)

    details_text = tk.Text(details_inner, wrap=tk.WORD, font=("Consolas", 10),
                           bg=colors['surface'], fg=colors['text'], insertbackground=colors['text'],
                           relief='flat', bd=0, selectbackground=colors['selection'], padx=12, pady=10)
    details_scroll = ttk.Scrollbar(details_inner, orient=tk.VERTICAL, command=details_text.yview)
    details_text.configure(yscrollcommand=details_scroll.set)
    details_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    details_scroll.pack(side=tk.RIGHT, fill=tk.Y)

    def copy_selected_row():
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Copy", "No row selected")
            return
        idx = int(selected[0])
        trans = transactions[idx]
        page_display = f"{trans.get('page')} - {trans.get('page_name', '')}"
        reg_num = trans.get('register')
        reg_name = trans.get('register_name', '')
        if reg_name and " PHY Address" in reg_name:
            reg_name = reg_name.split(" PHY Address")[0].strip()
        reg_display = f"0x{reg_num:02X} - {reg_name}" if reg_num is not None else ""
        data_display = ""
        if trans.get('data_value') is not None:
            data_display = f"0x{trans['data_value']:04X}"
        row_text = (
            f"[{trans.get('index')}] {trans.get('time')} {trans.get('duration')} | "
            f"{trans.get('direction')} | {trans.get('message_type')} | Page: {page_display} | Reg: {reg_display} | {data_display}"
        )
        window.clipboard_clear()
        window.clipboard_append(row_text)

    def copy_details():
        text_value = details_text.get("1.0", tk.END).strip()
        if not text_value:
            messagebox.showinfo("Copy", "No details to copy")
            return
        window.clipboard_clear()
        window.clipboard_append(text_value)

    def copy_selected_details_line():
        """Copy the current line where cursor is in details text"""
        try:
            line_start = details_text.index("insert linestart")
            line_end = details_text.index("insert lineend")
            line_text = details_text.get(line_start, line_end).strip()
            if line_text:
                window.clipboard_clear()
                window.clipboard_append(line_text)
        except Exception:            pass

    def copy_selection():
        """Copy selected text from details"""
        try:
            selected_text = details_text.get(tk.SEL_FIRST, tk.SEL_LAST)
            if selected_text:
                window.clipboard_clear()
                window.clipboard_append(selected_text)
        except Exception:            pass

    # Right-click context menu for details text
    details_menu = tk.Menu(details_text, tearoff=0, bg=colors['surface_light'], fg=colors['text'],
                           activebackground=colors['selection'], activeforeground=colors['text_bright'],
                           relief='flat', bd=0)
    details_menu.add_command(label="Copy Selection", command=copy_selection)
    details_menu.add_command(label="Copy Current Line", command=copy_selected_details_line)
    details_menu.add_command(label="Copy All Details", command=copy_details)

    def show_details_menu(event):
        details_menu.post(event.x_root, event.y_root)

    details_text.bind("<Button-3>", show_details_menu)

    # Right-click context menu for tree (table)
    tree_menu = tk.Menu(tree, tearoff=0, bg=colors['surface_light'], fg=colors['text'],
                        activebackground=colors['selection'], activeforeground=colors['text_bright'],
                        relief='flat', bd=0)
    tree_menu.add_command(label="Copy Selected Row", command=copy_selected_row)

    def show_tree_menu(event):
        tree_menu.post(event.x_root, event.y_root)

    tree.bind("<Button-3>", show_tree_menu)

    # VS Code style copy buttons
    copy_btn1 = tk.Button(copy_frame, text="Copy Row", command=copy_selected_row, font=("Segoe UI", 8),
                          bg=colors['header_bg'], fg=colors['text_dim'], relief='flat', padx=8, pady=2, cursor='hand2',
                          activebackground=colors['surface_light'], activeforeground=colors['text'])
    copy_btn1.pack(side=tk.LEFT)
    
    copy_btn2 = tk.Button(copy_frame, text="Copy Line", command=copy_selected_details_line, font=("Segoe UI", 8),
                          bg=colors['header_bg'], fg=colors['text_dim'], relief='flat', padx=8, pady=2, cursor='hand2',
                          activebackground=colors['surface_light'], activeforeground=colors['text'])
    copy_btn2.pack(side=tk.LEFT, padx=(4, 0))
    
    copy_btn3 = tk.Button(copy_frame, text="Copy All", command=copy_details, font=("Segoe UI", 8),
                          bg=colors['header_bg'], fg=colors['text_dim'], relief='flat', padx=8, pady=2, cursor='hand2',
                          activebackground=colors['surface_light'], activeforeground=colors['text'])
    copy_btn3.pack(side=tk.LEFT, padx=(4, 0))

    def show_details(event=None):
        selected = tree.selection()
        if not selected:
            return
        idx = int(selected[0])
        trans = transactions[idx]
        details_text.delete("1.0", tk.END)

        details_text.insert(tk.END, "═" * 60 + "\n")
        details_text.insert(tk.END, f"  📍 Line: {trans.get('index')}\n")
        details_text.insert(tk.END, "═" * 60 + "\n\n")
        
        details_text.insert(tk.END, f"⏱️  Time:      {trans.get('time')}\n")
        details_text.insert(tk.END, f"⏳ Duration:  {trans.get('duration')}\n")
        details_text.insert(tk.END, f"📬 Address:   0x{trans.get('address', '??')}\n")
        details_text.insert(tk.END, f"↔️  Direction: {trans.get('direction')}\n")
        details_text.insert(tk.END, f"📨 Type:      {trans.get('message_type')}\n")

        if trans.get('unexpected_address'):
            details_text.tag_configure('red_warn', foreground='#ff3333', font=('Consolas', 11, 'bold'))
            details_text.insert(tk.END,
                "\n⚠️  UNEXPECTED ADDRESS 0x{} — Expected 0x64 or 0x70 only!\n".format(trans.get('address', '??')),
                'red_warn')

        details_text.insert(tk.END, "\n")
        
        if trans.get('page') is not None:
            details_text.insert(tk.END, f"📑 Page:      {trans.get('page')} - {trans.get('page_name', 'Unknown')}\n")
        if trans.get('register') is not None:
            reg_num = trans.get('register')
            reg_name = trans.get('register_name', '')
            if reg_name and " PHY Address" in reg_name:
                reg_name = reg_name.split(" PHY Address")[0].strip()
            details_text.insert(tk.END, f"📝 Register:  0x{reg_num:02X} - {reg_name}\n")

        english_summary = build_plain_english_summary(trans)
        if english_summary:
            details_text.insert(tk.END, "\n" + "═" * 60 + "\n")
            details_text.insert(tk.END, "Plain English Summary:\n")
            details_text.insert(tk.END, "═" * 60 + "\n")
            for summary_line in english_summary:
                details_text.insert(tk.END, f"  - {summary_line}\n")
        
        if trans.get('data_value') is not None:
            details_text.insert(tk.END, f"\n💾 Data:      0x{trans['data_value']:04X} (decimal: {trans['data_value']})\n")
            details_text.insert(tk.END, f"   Binary:    {trans['data_value']:016b}\n")

            # Show SET BITS summary prominently
            is_status = trans.get('is_status', False)
            if is_status:
                set_bits = get_status_set_bits_summary(trans['data_value'], trans.get('direction', ''))
            else:
                reg_info = trans.get('register_info') or get_register_info(trans.get('page'), trans.get('register'))
                set_bits = get_set_bits_summary(trans['data_value'], reg_info)

            details_text.insert(tk.END, "\n" + "═" * 60 + "\n")
            details_text.insert(tk.END, "🟢 SET BITS (=1):\n")
            details_text.insert(tk.END, "═" * 60 + "\n")
            if set_bits:
                for bit_pos, bit_name in set_bits:
                    details_text.insert(tk.END, f"  ✅ Bit[{bit_pos}]  {bit_name}\n")
            else:
                details_text.insert(tk.END, "  (no bits set)\n")
            details_text.insert(tk.END, "═" * 60 + "\n")

            # Full bit analysis below
            if not is_status:
                reg_info = trans.get('register_info') or get_register_info(trans.get('page'), trans.get('register'))
            else:
                # Build a reg_info-like dict from status bit defs
                direction = trans.get('direction', '')
                if 'PHY' in direction and 'MAC' in direction:
                    bit_defs = SMBUS_STATUS_BITS.get('phy_to_mac', {})
                else:
                    bit_defs = SMBUS_STATUS_BITS.get('mac_to_phy', {})
                reg_info = {'bits': {i: bit_defs.get(i, f'Bit {i}') for i in range(16)}}
            details_text.insert(tk.END, "\n" + "─" * 60 + "\n")
            details_text.insert(tk.END, "🔍 Full Bit Analysis:\n")
            details_text.insert(tk.END, "─" * 60 + "\n")
            details_text.insert(tk.END, format_bit_analysis_block(trans['data_value'], reg_info))
        
        if trans.get('raw_data'):
            details_text.insert(tk.END, f"\n\n📦 Raw: {' '.join(trans['raw_data'])}\n")

    tree.bind("<<TreeviewSelect>>", show_details)
    render_page()

    # Modern status bar at bottom
    status_bar = tk.Frame(window, bg=colors['surface'], height=30)
    status_bar.pack(fill=tk.X, side=tk.BOTTOM)
    status_bar.pack_propagate(False)
    
    tk.Label(status_bar, text="💡 Double-click headers to auto-size  •  Right-click for copy  •  Drag borders to resize", 
             font=("Segoe UI", 9), bg=colors['surface'], fg=colors['text_dim']).pack(side=tk.LEFT, padx=15, pady=5)
    
    tk.Label(status_bar, text="© 2026 Intel Corporation", 
             font=("Segoe UI", 8), bg=colors['surface'], fg=colors['text_dim']).pack(side=tk.RIGHT, padx=15, pady=5)

    if not root:
        window.mainloop()

if __name__ == "__main__":
    print("🚀 Starting Jacksonville PHY SMBus Analyzer...")
    print("\nChoose analysis mode:")
    print("1. In-app report viewer")
    print("2. HTML report with file selection dialog")
    
    choice = input("\nEnter choice (1 or 2) [default: 1]: ").strip() or "1"
    
    if choice == "2":
        create_lightweight_html_report()
    else:
        create_in_app_report()