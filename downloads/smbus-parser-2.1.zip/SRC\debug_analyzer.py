"""
Jacksonville PHY Debug Analyzer
Analyzes SMBus traces against Jacksonville EAS 1.12 specification
Checks configuration flows, register values, and bit settings

Enhanced with comprehensive register definitions from:
- Jacksonville EAS 1.12 (Jacksonville External Architecture Specification)
- Clarksville T-Spec rev 0.9 (Component Testability Specification)
- Nahum HAS 1.1 (GbE LAN Controller Hardware Architecture Specification)
- PHY_REGISTER_AUDIT_REPORT.md (Comprehensive register audit)

Key capabilities:
- Validate register access types (RW, RO, RO/SC, etc.)
- Check configuration flows against spec-defined sequences
- Detect missing critical register definitions
- Verify bit field values against expected ranges
- Track link state changes and speed transitions
- Analyze ULP/WOL configuration compliance
- Identify reset events and initialization sequences
"""

import os
import sys
import csv
import tkinter as tk
from tkinter import ttk, messagebox
import tkinter.font as tkfont

# Import definitions - handle both direct run and import
# Add SRC directory to path if running from SMBUS_PARSER root
# Add SRC directory to path if running from SMBUS_PARSER root
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

try:
    from phy_definitions import PAGE_NAMES, get_page_name, get_register_info
except ImportError:
    from SRC.phy_definitions import PAGE_NAMES, get_page_name, get_register_info


def parse_smbus_csv(filename):
    """Parse SMBus trace CSV file and return list of transactions"""
    transactions = []
    current_page = 0
    
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        data = list(reader)[8:]  # Skip Total Phase header
        
        for i, row in enumerate(data):
            if len(row) < 10:
                continue
            
            trans = {
                'index': i + 1,
                'time': row[0] if len(row) > 0 else '',
                'duration': row[1] if len(row) > 1 else '',
                'address': row[7].strip() if len(row) > 7 else '',
                'unexpected_address': (row[7].strip().rstrip('*').upper() if len(row) > 7 else '') not in ('64', '70', ''),
                'page': current_page,
                'register': None,
                'data_value': None,
                'direction': '',
                'message_type': '',
                'raw_data': []
            }
            
            # Parse record info
            record_info = row[4] if len(row) > 4 else ''
            data_field = row[9] if len(row) > 9 else ''
            
            # Determine direction
            if 'Write' in record_info or 'S 32' in record_info or 'S 33' in record_info:
                trans['direction'] = 'MAC→PHY Write'
            elif 'Read' in record_info or 'S 34' in record_info or 'S 35' in record_info:
                trans['direction'] = 'PHY→MAC Read'
            elif 'Block Write' in record_info:
                trans['direction'] = 'MAC→PHY Block Write'
            elif 'Block Read' in record_info:
                trans['direction'] = 'PHY→MAC Block Read'
            else:
                trans['direction'] = record_info[:30] if record_info else 'Unknown'
            
            # Parse data bytes
            if data_field:
                # Store raw bytes as hex strings
                data_bytes = data_field.split()
                trans['raw_data'] = [b.upper() for b in data_bytes if b.strip()]
                
                # Parse as byte list for processing
                bytes_list = trans['raw_data']
                
                if len(bytes_list) >= 1:
                    # First byte is often command/register
                    try:
                        cmd_byte = int(bytes_list[0], 16)
                        trans['message_type'] = f"Cmd 0x{cmd_byte:02X}"
                        
                        if cmd_byte in (0xC3, 0xD3) and len(bytes_list) >= 7:
                            msg_type_byte = int(bytes_list[2], 16)
                            is_ptm = (cmd_byte == 0xD3)

                            if msg_type_byte == 0x00:
                                # Status message
                                status_hi = int(bytes_list[3], 16)
                                status_lo = int(bytes_list[4], 16)
                                trans['data_value'] = (status_hi << 8) | status_lo
                                trans['message_type'] = 'PtM Status' if is_ptm else 'MtP Status'

                            elif msg_type_byte in (0x01, 0x02):
                                # Config transaction
                                data_hi = int(bytes_list[3], 16)
                                data_lo = int(bytes_list[4], 16)
                                reg_byte = int(bytes_list[5], 16)
                                trans['register'] = reg_byte & 0x1F
                                trans['data_value'] = (data_hi << 8) | data_lo
                                if msg_type_byte == 0x01:
                                    trans['message_type'] = 'Config Write' if not is_ptm else 'Config Write Ack'
                                else:
                                    trans['message_type'] = 'Config Read Request' if not is_ptm else 'Config Read Response'
                        
                        # D5 = Wake-up Message
                        elif cmd_byte == 0xD5 and len(bytes_list) >= 3:
                            trans['message_type'] = 'Wake-up Message'
                            wake_byte = int(bytes_list[2], 16)
                            trans['wake_indication'] = wake_byte
                            if wake_byte == 0x01:
                                trans['wake_type'] = 'Host Wake'
                            elif wake_byte == 0x02:
                                trans['wake_type'] = 'ME Wake'
                            else:
                                trans['wake_type'] = 'No Wake'
                        
                        # Handle page select (register 31/0x1F)
                        if trans['register'] == 31 and trans['data_value'] is not None:
                            trans['page_access'] = trans['data_value'] & 0x7FF
                            current_page = trans['page_access']
                            
                    except (ValueError, IndexError):
                        pass
            
            trans['page'] = current_page
            
            # Get register info
            if trans['register'] is not None:
                reg_info = get_register_info(current_page, trans['register'])
                if reg_info:
                    trans['register_name'] = reg_info.get('name', f'Register {trans["register"]}')
                    trans['page_name'] = get_page_name(current_page)
                else:
                    trans['register_name'] = f'Register 0x{trans["register"]:02X}'
                    trans['page_name'] = get_page_name(current_page)
            
            transactions.append(trans)
    
    return transactions

# ============================================================================
# SPECIFICATION DEFINITIONS - Jacksonville EAS 1.12 & Clarksville tspec
# ============================================================================

# Expected register values from specs
SPEC_DEFINITIONS = {
    # PHY Status (PtM) - from Jacksonville EAS 1.12 Table 14
    'phy_status': {
        'description': 'PHY Status (PtM Status Command)',
        'fields': {
            'SPD1': {'bit': 15, 'name': 'Speed[1] (MSB)', 'expected': None},
            'SPD0': {'bit': 14, 'name': 'Speed[0] (LSB)', 'expected': None},
            'DPX': {'bit': 13, 'name': 'Duplex Mode (1=Full, 0=Half)', 'expected': None},
            'LDUP': {'bit': 12, 'name': 'Link Up (duplicate)', 'expected': None},
            'CDIS': {'bit': 11, 'name': 'Cable Disconnected', 'expected': None},
            'ELINK': {'bit': 10, 'name': 'Ethernet Link Status', 'expected': None},
            'INT': {'bit': 9, 'name': 'Interrupt Pending', 'expected': None},
            'RSTC': {'bit': 8, 'name': 'Reset Complete', 'expected': None},
            'K1': {'bit': 7, 'name': 'K1 State', 'expected': None},
            'TX_OFF': {'bit': 6, 'name': 'TX Off', 'expected': None},
            'EI': {'bit': 5, 'name': 'Energy Idle', 'expected': None}
        }
    },
    
    # Page 0 Register 0 - Control Register
    'control_register': {
        'page': 0, 'register': 0,
        'description': 'IEEE 802.3 Control Register',
        'fields': {
            'Reset': {'bit': 15, 'name': 'Software Reset', 'expected': 0, 'note': 'Should self-clear after reset'},
            'Loopback': {'bit': 14, 'name': 'Loopback Mode', 'expected': 0, 'note': 'Set to 1 for PCS loopback'},
            'Speed_LSB': {'bit': 13, 'name': 'Speed Select LSB', 'expected': None},
            'AN_Enable': {'bit': 12, 'name': 'Auto-Negotiation Enable', 'expected': 1, 'note': 'Should be 1 for normal operation'},
            'Power_Down': {'bit': 11, 'name': 'Power Down', 'expected': 0, 'note': 'Should be 0 for normal operation'},
            'Isolate': {'bit': 10, 'name': 'Isolate', 'expected': 0},
            'Restart_AN': {'bit': 9, 'name': 'Restart Auto-Negotiation', 'expected': 0, 'note': 'Set to 1 to restart AN'},
            'Duplex': {'bit': 8, 'name': 'Duplex Mode', 'expected': None},
            'Speed_MSB': {'bit': 6, 'name': 'Speed Select MSB', 'expected': None}
        }
    },
    
    # Page 0 Register 1 - Status Register
    'status_register': {
        'page': 0, 'register': 1,
        'description': 'IEEE 802.3 Status Register',
        'fields': {
            'AN_Complete': {'bit': 5, 'name': 'Auto-Negotiation Complete', 'expected': 1, 'note': 'Should be 1 when AN done'},
            'Remote_Fault': {'bit': 4, 'name': 'Remote Fault', 'expected': 0, 'note': 'Should be 0 for healthy link'},
            'AN_Ability': {'bit': 3, 'name': 'Auto-Negotiation Ability', 'expected': 1},
            'Link_Status': {'bit': 2, 'name': 'Link Status', 'expected': 1, 'note': 'Should be 1 when link up'},
            'Jabber_Detect': {'bit': 1, 'name': 'Jabber Detect', 'expected': 0}
        }
    },
    
    # Page 769 Register 16 - Kumeran Mode Control
    'kumeran_mode': {
        'page': 769, 'register': 16,
        'description': 'Kumeran Mode Control (Port Control)',
        'fields': {
            'Force_Link': {'bit': 6, 'name': 'Force Link', 'expected': 0, 'note': 'Set to 1 for loopback mode'},
            'MDIO_Freq': {'bit': 10, 'name': 'MDIO Frequency Access', 'expected': None}
        }
    },
    
    # Page 769 Register 17 - Port General Configuration
    'port_general_config': {
        'page': 769, 'register': 17,
        'description': 'Port General Configuration',
        'fields': {
            'Active_PD_Enable': {'bit': 6, 'name': 'Active Power Down Enable', 'expected': None},
            'ME_WU_Active': {'bit': 5, 'name': 'ME Wake-Up Active', 'expected': None},
            'Host_WU_Active': {'bit': 4, 'name': 'Host Wake-Up Active', 'expected': None},
            'MACPD_Enable': {'bit': 2, 'name': 'MAC Power Down Enable', 'expected': None}
        }
    },
    
    # Page 776 Register 16 - General MUX Data Control
    'general_mux_control': {
        'page': 776, 'register': 16,
        'description': 'General MUX Data Control (Packet Generator)',
        'fields': {
            'Gen_To_MAC': {'bit': 8, 'name': 'Generator to MAC', 'expected': None, 'note': 'Set 1 for packet gen'},
            'Start_Gen_Packet': {'bit': 7, 'name': 'Start Generator Packet', 'expected': None},
            'Force_Link_Val': {'bit': 6, 'name': 'Force Link Value', 'expected': None},
            'Force_Speed': {'bit': 2, 'name': 'Force Speed', 'expected': None},
            'Speed_Sel': {'bits': [4, 3], 'name': 'Speed Select (00=10M,01=100M,10=1G)', 'expected': None}
        }
    },
    
    # Page 779 Register 16 - ULP Configuration 1
    'ulp_config': {
        'page': 779, 'register': 16,
        'description': 'ULP Configuration 1',
        'fields': {
            'RESET_ULP_IND': {'bit': 15, 'name': 'Reset ULP Indication', 'expected': None},
            'FORCE_ULP': {'bit': 14, 'name': 'Force ULP', 'expected': 0, 'note': 'Should be 0 for normal mode'},
            'DISABLE_SMB_PERST': {'bit': 12, 'name': 'Disable SMB PERST', 'expected': None},
            'EN_ULP_LANPHYPC': {'bit': 10, 'name': 'Enable ULP LANPHYPC', 'expected': None},
            'EN_1G_SMBUS': {'bit': 9, 'name': 'Enable 1G SMBus', 'expected': None},
            'RESET_TO_SMBUS': {'bit': 8, 'name': 'Reset to SMBus', 'expected': None},
            'WOL_ME': {'bit': 7, 'name': 'WoL ME', 'expected': None},
            'WOL_HOST': {'bit': 6, 'name': 'WoL Host', 'expected': None},
            'INBAND_EXIT': {'bit': 5, 'name': 'Inband Exit', 'expected': None},
            'STICKY_ULP': {'bit': 4, 'name': 'Sticky ULP', 'expected': None},
            'ULP_IND': {'bit': 2, 'name': 'ULP Indication', 'expected': None},
            'START': {'bit': 0, 'name': 'ULP Start', 'expected': None}
        }
    }
}

# ============================================================================
# EXTENDED SPECIFICATION DEFINITIONS - From PHY Register Audit Report
# Jacksonville EAS 1.12, Clarksville T-Spec, Nahum HAS specifications
# ============================================================================

# Access Type Abbreviations (Jacksonville EAS Section 9.1.1)
ACCESS_TYPES = {
    'RW': 'Read/Write - Can be read and written',
    'RO': 'Read Only - Cannot be written',
    'RO/LL': 'Read Only, Latch Low - Latches 0, requires read to clear',
    'RO/LH': 'Read Only, Latch High - Latches 1, requires read to clear',
    'RO/SC': 'Read Only, Self Clear - Reading clears the bit',
    'RO/V': 'Read Only, Volatile - Value changes with hardware state',
    'R/WC': 'Read, Write 1 to Clear',
    'R/WSC': 'Read, Write Set to Clear',
}

# Complete Page 0 Registers (IEEE 802.3 + Jacksonville Extensions)
EXTENDED_PAGE0_REGISTERS = {
    0x00: {
        'name': 'Control Register',
        'access': 'RW',
        'default': 0x1140,
        'spec_ref': 'IEEE 802.3 Clause 22.2.4.1',
        'critical_bits': {
            15: {'name': 'Reset', 'note': 'Self-clearing after reset completes'},
            14: {'name': 'Loopback', 'note': 'PCS loopback mode'},
            13: {'name': 'Speed Select LSB', 'note': 'Combined with bit 6 for speed'},
            12: {'name': 'AN Enable', 'expected': 1, 'note': 'Auto-Negotiation Enable'},
            11: {'name': 'Power Down', 'expected': 0, 'note': 'Should be 0 for active'},
            10: {'name': 'Isolate', 'expected': 0},
            9: {'name': 'Restart AN', 'note': 'Self-clearing'},
            8: {'name': 'Duplex Mode', 'note': '1=Full, 0=Half'},
            6: {'name': 'Speed Select MSB', 'note': 'MSB:LSB = 10:1Gbps, 01:100Mbps, 00:10Mbps'}
        }
    },
    0x01: {
        'name': 'Status Register',
        'access': 'RO',
        'default': 0x796D,
        'spec_ref': 'IEEE 802.3 Clause 22.2.4.2',
        'critical_bits': {
            5: {'name': 'AN Complete', 'expected': 1, 'note': '1 when AN done'},
            4: {'name': 'Remote Fault', 'expected': 0, 'note': 'Should be 0 for healthy link'},
            3: {'name': 'AN Ability', 'expected': 1},
            2: {'name': 'Link Status', 'expected': 1, 'note': '1 when link up - Latching low'},
            1: {'name': 'Jabber Detect', 'expected': 0}
        }
    },
    0x04: {
        'name': 'AN Advertisement',
        'access': 'RW',
        'default': 0x01E1,
        'spec_ref': 'IEEE 802.3 Clause 37.2.1',
        'critical_bits': {
            15: {'name': 'Next Page', 'note': '1 = more pages to follow'},
            13: {'name': 'Remote Fault', 'note': 'Fault indication'},
            10: {'name': 'Pause', 'note': 'PAUSE capable'},
            8: {'name': '100BASE-TX Full Duplex', 'expected': 1},
            7: {'name': '100BASE-TX Half Duplex', 'expected': 1},
            6: {'name': '10BASE-T Full Duplex', 'expected': 1},
            5: {'name': '10BASE-T Half Duplex', 'expected': 1}
        }
    },
    0x17: {
        'name': 'PHY Special Control/Status',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 94',
        'critical_bits': {
            15: {'name': 'Auto-MDIX Enable'},
            14: {'name': 'Auto-MDIX Status'},
            10: {'name': 'Signal Detect'},
            4: {'name': 'Speed Indication bit 1'},
            3: {'name': 'Speed Indication bit 0', 'note': '11=Reserved, 10=1000Mbps, 01=100Mbps, 00=10Mbps'},
            2: {'name': 'Duplex Indication', 'note': '1=Full duplex'}
        }
    },
    0x19: {
        'name': 'Interrupt Status Register',
        'access': 'RO/SC',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS (CONFLICT - needs resolution)',
        'note': 'CONFLICT with OEM Bits register - verify spec',
        'critical_bits': {
            15: {'name': 'Speed Changed'},
            14: {'name': 'Duplex Changed'},
            13: {'name': 'Page Received'},
            11: {'name': 'AN Complete'},
            10: {'name': 'Link Status Changed'},
            7: {'name': 'Symbol Error'},
            2: {'name': 'False Carrier'},
            1: {'name': 'Energy Detect'},
            0: {'name': 'AN Error'}
        }
    },
    0x1A: {
        'name': 'SMBus Address Register',
        'access': 'RW',
        'default': 0x0C80,
        'spec_ref': 'Jacksonville EAS Table 96',
        'critical_bits': {
            12: {'name': 'SMBus Freq High', 'note': 'Combined with bit 8 for SMBus frequency'},
            11: {'name': 'SMB Fragments Size', 'note': '0=32B, 1=64B'},
            10: {'name': 'APM Enable'},
            9: {'name': 'PEC Enable'},
            8: {'name': 'SMBus Freq Low', 'note': 'Combined with bit 12 for SMBus frequency'},
            7: {'name': 'SMBus Address Valid'},
            6: {'name': 'Address bit 6'},
            5: {'name': 'Address bit 5'},
            4: {'name': 'Address bit 4'},
            3: {'name': 'Address bit 3'},
            2: {'name': 'Address bit 2'},
            1: {'name': 'Address bit 1'},
            0: {'name': 'Address bit 0', 'note': 'SMBus 7-bit address [6:0]'}
        }
    }
}

# Page 769 - Port Control Registers (Extended definitions)
EXTENDED_PAGE769_REGISTERS = {
    0x10: {
        'name': 'Kumeran Mode Control',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 55',
        'critical_bits': {
            10: {'name': 'MDIO Frequency Access', 'note': 'TX LPI Exit indicator'},
            6: {'name': 'Force Link', 'note': 'Set to 1 for loopback mode'},
            5: {'name': 'Slow Link Mode'},
            4: {'name': 'MNG Pass Through'},
            3: {'name': 'Clock Request Override'},
            2: {'name': 'Clock Request Enable'},
            1: {'name': 'Kumeran Lock Loss Fix'},
            0: {'name': 'Disable Nway'}
        }
    },
    0x11: {
        'name': 'Port General Configuration',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 56',
        'critical_bits': {
            15: {'name': 'Force SMBus', 'note': 'Force SMBus mode'},
            14: {'name': 'Enable Tx Packet Buffer'},
            13: {'name': 'Transmit Disable'},
            6: {'name': 'Active PD Enable'},
            5: {'name': 'ME Wake-Up Active', 'note': 'ME wake event active'},
            4: {'name': 'Host Wake-Up Active', 'note': 'Host wake event active'},
            3: {'name': 'SMBUS_From_SX'},
            2: {'name': 'MACPD Enable', 'note': 'MAC Power Down Enable - CRITICAL for WOL'},
            1: {'name': 'MAC Wake On LAN'},
            0: {'name': 'PHY Wake On LAN'}
        }
    },
    0x14: {
        'name': 'DFT Control Register',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 57',
        'critical_bits': {
            15: {'name': 'Power Down', 'note': 'Master power down'},
            14: {'name': 'PLL Power Down'},
            11: {'name': 'Analog Test Enable'},
            10: {'name': 'Ignore Early GLINK'},
            9: {'name': 'Force GLINK'},
            8: {'name': 'Force GLINK Value'}
        }
    },
    0x17: {
        'name': 'SMBus Control Register',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 60',
        'critical_bits': {
            15: {'name': 'SMBus Enable'},
            14: {'name': 'SMBus Auto Switch'},
            13: {'name': 'Force SMBus Mode'},
            10: {'name': 'SMBus Filter Enable'},
            9: {'name': 'SMBus Watchdog Enable'},
            8: {'name': 'SMBus PEC Enable'},
            5: {'name': 'SMBus/PCIe Mode', 'note': '1=SMBus active, 0=PCIe active'},
            4: {'name': 'SMBus Request'},
            3: {'name': 'PCIe Link Active'},
            2: {'name': 'SMBus Link Active'},
            1: {'name': 'SMBus NACK Indicator'},
            0: {'name': 'SMBus Busy'}
        }
    },
    0x1C: {
        'name': 'Extended Proxy Control (EPRXC)',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 64',
        'critical_bits': {
            15: {'name': 'Proxy Mode Enable'},
            14: {'name': 'Flow Control Enable'},
            10: {'name': 'SMBus/PCIe Select', 'note': 'Mode transition control'},
            9: {'name': 'Force Proxy'},
            8: {'name': 'Proxy Ready'},
            5: {'name': 'Transmit Queue Full'},
            4: {'name': 'Receive Queue Empty'},
            3: {'name': 'Proxy TX Enable'},
            2: {'name': 'Proxy RX Enable'}
        }
    }
}

# Page 770 - Kumeran Registers (Extended)
EXTENDED_PAGE770_REGISTERS = {
    0x11: {
        'name': 'PCIe Power Management Control',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 72',
        'critical_bits': {
            15: {'name': 'ASPM L1 Enable'},
            14: {'name': 'ASPM L0s Enable'},
            10: {'name': 'LTR Enable'},
            9: {'name': 'OBFF Enable'},
            8: {'name': 'Clock Request Enable'},
            5: {'name': 'L1 Sub States Enable'},
            4: {'name': 'L1.1 Enable'},
            3: {'name': 'L1.2 Enable'}
        }
    },
    0x12: {
        'name': 'In-Band Control',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 73',
        'critical_bits': {
            15: {'name': 'In-Band Enable'},
            10: {'name': 'Auto Config'},
            9: {'name': 'Status Request'},
            8: {'name': 'Config ACK Enable'}
        }
    },
    0x14: {
        'name': 'Acknowledge Timeouts',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 75',
        'critical_bits': {
            15: {'name': 'Config Timeout Enable'},
            14: {'name': 'Status Timeout Enable'},
            11: {'name': 'Config Timeout[10:8]', 'note': '3-bit timeout value'},
            10: {'name': 'Config Timeout[10:8]'},
            9: {'name': 'Config Timeout[10:8]'},
            7: {'name': 'Status Timeout[7:0]', 'note': '8-bit timeout value'}
        }
    }
}

# Page 772 - Kumeran Configuration Registers (Extended)
EXTENDED_PAGE772_REGISTERS = {
    0x12: {
        'name': 'Low Power Idle GPIO Control',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 77',
        'critical_bits': {
            15: {'name': 'LPI GPIO15 Enable'},
            14: {'name': 'LPI GPIO14 Enable'},
            10: {'name': 'TX LPI Request'},
            9: {'name': 'RX LPI Indication'},
            8: {'name': 'EEE Capability'},
            5: {'name': 'LPI Signal Mode'},
            4: {'name': 'LPI Manual Mode'}
        }
    },
    0x14: {
        'name': 'Low Power Idle Control',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 79 - CRITICAL for EEE',
        'critical_bits': {
            15: {'name': 'EEE Enable', 'note': 'Energy Efficient Ethernet master enable'},
            14: {'name': 'TX LPI Enable'},
            13: {'name': 'RX LPI Enable'},
            10: {'name': 'LPI Counter Enable'},
            9: {'name': 'Assert LPI on Link Down'},
            8: {'name': 'Fast LPI Mode'},
            5: {'name': 'Advertise EEE 100BASE-TX'},
            4: {'name': 'Advertise EEE 1000BASE-T'}
        }
    }
}

# Page 776 - General Registers (Extended)
EXTENDED_PAGE776_REGISTERS = {
    0x12: {
        'name': 'Jacksonville Energy Detect Mode',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 91',
        'critical_bits': {
            15: {'name': 'Energy Detect Enable'},
            10: {'name': 'Signal Detect Threshold'},
            5: {'name': 'Energy Detect Polarity'}
        }
    },
    0x13: {
        'name': 'Jacksonville Capability',
        'access': 'RO',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 92 - CRITICAL for SKU detection',
        'critical_bits': {
            15: {'name': 'Jacksonville PHY', 'expected': 1},
            10: {'name': 'EEE Capable'},
            9: {'name': 'WOL Capable'},
            8: {'name': 'AMT Capable'},
            7: {'name': '1000BASE-T Capable'},
            6: {'name': '100BASE-TX Capable'},
            5: {'name': '10BASE-T Capable'},
            4: {'name': 'Auto-MDIX Capable'},
            3: {'name': 'Ultra Low Power Capable'},
            2: {'name': 'SMBus Capable'}
        }
    }
}

# Page 779 - ULP Registers (Extended)
EXTENDED_PAGE779_REGISTERS = {
    0x10: {
        'name': 'ULP Configuration 1',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 85',
        'critical_bits': {
            15: {'name': 'RESET_ULP_IND'},
            14: {'name': 'FORCE_ULP', 'expected': 0, 'note': 'Should be 0 for normal'},
            12: {'name': 'DISABLE_SMB_PERST'},
            10: {'name': 'EN_ULP_LANPHYPC'},
            9: {'name': 'EN_1G_SMBUS'},
            8: {'name': 'RESET_TO_SMBUS'},
            7: {'name': 'WOL_ME'},
            6: {'name': 'WOL_HOST'},
            5: {'name': 'INBAND_EXIT'},
            4: {'name': 'STICKY_ULP'},
            2: {'name': 'ULP_IND'},
            0: {'name': 'START'}
        }
    },
    0x13: {
        'name': 'ULP Software Control',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 88',
        'critical_bits': {
            15: {'name': 'Software Control Enable'},
            10: {'name': 'Force D3'},
            9: {'name': 'Force D0'},
            8: {'name': 'ULP State'},
            5: {'name': 'Cable Status Check'},
            4: {'name': 'Link Partner Status Check'}
        }
    }
}

# Page 800 - WOL Registers (CRITICAL - mostly missing from implementation)
EXTENDED_PAGE800_REGISTERS = {
    0x00: {
        'name': 'Receive Control (RCTL)',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 100 - CRITICAL',
        'critical_bits': {
            15: {'name': 'Receiver Enable'},
            5: {'name': 'Multicast Promiscuous Enable'},
            4: {'name': 'Unicast Promiscuous Enable'},
            3: {'name': 'Broadcast Accept Mode'},
            2: {'name': 'Strip Ethernet CRC'}
        }
    },
    0x01: {
        'name': 'Wake Up Control (WUC)',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 101 - CRITICAL',
        'critical_bits': {
            15: {'name': 'Wake Up Enable'},
            10: {'name': 'PME Enable'},
            9: {'name': 'PME Status'},
            5: {'name': 'ARP Request Enable'},
            4: {'name': 'IPV4 TCP SYN Enable'},
            3: {'name': 'IPV6 Packet Enable'},
            2: {'name': 'Magic Packet Enable'}
        }
    },
    0x02: {
        'name': 'Wake Up Filter Control (WUFC)',
        'access': 'RW',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 102 - CRITICAL',
        'critical_bits': {
            15: {'name': 'Filter 0 Enable'},
            14: {'name': 'Filter 1 Enable'},
            13: {'name': 'Filter 2 Enable'},
            12: {'name': 'Filter 3 Enable'},
            10: {'name': 'Broadcast Enable'},
            9: {'name': 'Multicast Enable'},
            8: {'name': 'Unicast Enable'}
        }
    },
    0x03: {
        'name': 'Wake Up Status (WUS)',
        'access': 'RO/SC',
        'default': 0x0000,
        'spec_ref': 'Jacksonville EAS Table 103 - CRITICAL',
        'critical_bits': {
            15: {'name': 'Wake Packet', 'note': '1=packet caused wake'},
            10: {'name': 'Magic Packet Received'},
            9: {'name': 'ARP Request Received'},
            8: {'name': 'IPV4 TCP SYN Received'},
            7: {'name': 'IPV6 Packet Received'},
            5: {'name': 'Link Status Change'},
            4: {'name': 'Filter Match'}
        }
    }
}

# NOTE: CRITICAL_VALIDATION_RULES replaced with context-aware validation functions
# See: detect_trace_context(), get_phy_capabilities(), validate_*_configuration()
# This provides intelligent validation based on trace context and hardware capabilities

# Known Configuration Flows (Extended from Clarksville T-Spec)
# Configuration flows from Clarksville tspec
CONFIGURATION_FLOWS = {
    'loopback_1g': {
        'name': 'PCS Loopback at 1Gbps',
        'description': 'Configure PCS loopback mode at 1Gbps speed',
        'steps': [
            {'page': 2, 'register': 21, 'bits': [2, 1, 0], 'value': 0b110, 'desc': 'Set GIGA speed'},
            {'page': 0, 'register': 0, 'bit': 15, 'value': 1, 'desc': 'SW Reset'},
            {'page': 769, 'register': 20, 'bit': 10, 'value': 1, 'desc': 'Ignore early_glink indication'},
            {'page': 776, 'register': 16, 'bit': 6, 'value': 1, 'desc': 'Determine link value'},
            {'page': 769, 'register': 16, 'bit': 6, 'value': 1, 'desc': 'Force link value'},
            {'page': 0, 'register': 0, 'bit': 14, 'value': 1, 'desc': 'Set loopback'}
        ]
    },
    'loopback_100m': {
        'name': 'PCS Loopback at 100Mbps',
        'description': 'Configure PCS loopback mode at 100Mbps speed',
        'steps': [
            {'page': 2, 'register': 21, 'bits': [2, 1, 0], 'value': 0b101, 'desc': 'Set 100MHz speed'},
            {'page': 0, 'register': 0, 'bit': 15, 'value': 1, 'desc': 'SW Reset'},
            {'page': 776, 'register': 16, 'bit': 6, 'value': 1, 'desc': 'Determine link value'},
            {'page': 769, 'register': 16, 'bit': 6, 'value': 1, 'desc': 'Force link value'},
            {'page': 0, 'register': 0, 'bit': 14, 'value': 1, 'desc': 'Set loopback'}
        ]
    },
    'loopback_10m': {
        'name': 'PCS Loopback at 10Mbps',
        'description': 'Configure PCS loopback mode at 10Mbps speed',
        'steps': [
            {'page': 2, 'register': 21, 'bits': [2, 1, 0], 'value': 0b100, 'desc': 'Set 10MHz speed'},
            {'page': 0, 'register': 0, 'bit': 15, 'value': 1, 'desc': 'SW Reset'},
            {'page': 776, 'register': 16, 'bit': 6, 'value': 1, 'desc': 'Determine link value'},
            {'page': 769, 'register': 16, 'bit': 6, 'value': 1, 'desc': 'Force link value'},
            {'page': 0, 'register': 0, 'bit': 14, 'value': 1, 'desc': 'Set loopback'}
        ]
    },
    'packet_gen_endless': {
        'name': 'Packet Generator (Endless Mode)',
        'description': 'Activate packet generator in endless mode',
        'steps': [
            {'page': 776, 'register': 16, 'bit': 8, 'value': 1, 'desc': 'Enable gen_to_mac clocks'},
            {'page': 776, 'register': 17, 'bits': [13, 0], 'value': None, 'desc': 'Configure packet length'},
            {'page': 776, 'register': 16, 'bit': 2, 'value': 1, 'desc': 'Force speed'},
            {'page': 769, 'register': 16, 'bit': 6, 'value': 1, 'desc': 'Force link'},
            {'page': 776, 'register': 16, 'bit': 6, 'value': 1, 'desc': 'Force link value'},
            {'page': 776, 'register': 28, 'bit': 15, 'value': 1, 'desc': 'Set endless bit'},
            {'page': 776, 'register': 16, 'bit': 7, 'value': 1, 'desc': 'Start packet generator'}
        ]
    }
}


def parse_time_to_seconds(time_str):
    """Parse time string like '0:24.286.892' or '2:33.210.650' to total seconds"""
    if not time_str:
        return None
    try:
        # Format: M:SS.mmm.uuu (minutes:seconds.milliseconds.microseconds)
        parts = time_str.split(':')
        if len(parts) == 2:
            minutes = int(parts[0])
            sec_parts = parts[1].split('.')
            seconds = int(sec_parts[0])
            milliseconds = int(sec_parts[1]) if len(sec_parts) > 1 else 0
            microseconds = int(sec_parts[2]) if len(sec_parts) > 2 else 0
            total = minutes * 60 + seconds + milliseconds / 1000 + microseconds / 1000000
            return total
        return None
    except (ValueError, IndexError):
        return None


def validate_register_access(page, register, value, operation, results):
    """
    Validate register access against specification rules
    
    Args:
        page: PHY register page number
        register: Register address
        value: Data value being read/written
        operation: 'read' or 'write'
        results: Results dictionary to append warnings/issues
    
    Returns:
        List of validation messages
    """
    validation_messages = []
    
    # Get extended register info
    reg_info = None
    if page == 0 and register in EXTENDED_PAGE0_REGISTERS:
        reg_info = EXTENDED_PAGE0_REGISTERS[register]
    elif page == 769 and register in EXTENDED_PAGE769_REGISTERS:
        reg_info = EXTENDED_PAGE769_REGISTERS[register]
    elif page == 770 and register in EXTENDED_PAGE770_REGISTERS:
        reg_info = EXTENDED_PAGE770_REGISTERS[register]
    elif page == 772 and register in EXTENDED_PAGE772_REGISTERS:
        reg_info = EXTENDED_PAGE772_REGISTERS[register]
    elif page == 776 and register in EXTENDED_PAGE776_REGISTERS:
        reg_info = EXTENDED_PAGE776_REGISTERS[register]
    elif page == 779 and register in EXTENDED_PAGE779_REGISTERS:
        reg_info = EXTENDED_PAGE779_REGISTERS[register]
    elif page == 800 and register in EXTENDED_PAGE800_REGISTERS:
        reg_info = EXTENDED_PAGE800_REGISTERS[register]
    
    if not reg_info:
        return validation_messages
    
    # Check write to read-only register
    if operation == 'write':
        access_type = reg_info.get('access', '')
        if access_type.startswith('RO'):
            msg = f"⚠️ Write to Read-Only register: Page {page} Reg 0x{register:02X} ({reg_info['name']}) - Access type: {access_type}"
            validation_messages.append(msg)
            results['warnings'].append({'type': 'invalid_write', 'message': msg})
    
    # Validate critical bits
    if value is not None and 'critical_bits' in reg_info:
        for bit_pos, bit_info in reg_info['critical_bits'].items():
            bit_value = (value >> bit_pos) & 1
            expected = bit_info.get('expected')
            
            if expected is not None and bit_value != expected:
                msg = f"⚠️ Unexpected bit value: Page {page} Reg 0x{register:02X} Bit {bit_pos} ({bit_info['name']}) = {bit_value}, expected {expected}"
                if bit_info.get('note'):
                    msg += f" - {bit_info['note']}"
                validation_messages.append(msg)
                results['warnings'].append({'type': 'unexpected_bit_value', 'message': msg})
    
    return validation_messages


def detect_trace_context(results):
    """
    Determine if trace is in active operation or S-state period
    Returns: 'active', 's_state', 'mixed', 'unknown'
    """
    # Check for time gaps (S-state indicators)
    if results['time_gaps'] and len(results['time_gaps']) > 0:
        total_trans = results['total_transactions']
        if total_trans > 0:
            first_gap_index = results['time_gaps'][0]['from_index']
            
            if first_gap_index < total_trans * 0.2:
                return 's_state'  # Gap early, most trace is post-S-state
            elif first_gap_index > total_trans * 0.8:
                return 'active'   # Gap late, most trace is pre-S-state
            else:
                return 'mixed'
    
    # Check for NACK periods (PHY in ULP/power-down)
    if results['nack_periods'] and len(results['nack_periods']) > 3:
        return 's_state'
    
    # Check for ULP configuration (entering S-state)
    if results['ulp_analysis']['ulp_config_written']:
        return 'mixed'  # Has ULP config, likely entering S-state
    
    # Check for wake events (exiting S-state)
    if results['wake_events']:
        return 's_state'
    
    return 'active'  # Default: normal operation


def get_phy_capabilities(register_values):
    """
    Read PHY capabilities from Page 776 Reg 0x13 (Jacksonville Capability)
    Returns dict of supported features
    """
    capabilities = {
        'eee': None,  # None = unknown, True/False = known
        'wol': None,
        'amt': None,
        'ulp': None,
        'smbus': None,
        'jacksonville_phy': None
    }
    
    key = (776, 0x13)  # Jacksonville Capability Register
    if key in register_values:
        cap_value = register_values[key]
        capabilities['jacksonville_phy'] = bool((cap_value >> 15) & 1)
        capabilities['eee'] = bool((cap_value >> 10) & 1)
        capabilities['wol'] = bool((cap_value >> 9) & 1)
        capabilities['amt'] = bool((cap_value >> 8) & 1)
        capabilities['ulp'] = bool((cap_value >> 3) & 1)
        capabilities['smbus'] = bool((cap_value >> 2) & 1)
    
    return capabilities


def is_cable_connected(results):
    """
    Determine if cable is connected based on trace data
    Returns: True (connected), False (disconnected), None (unknown)
    """
    # Check cable status from PtM Status messages
    if results['link_status_history']:
        last_status = results['link_status_history'][-1]
        if last_status.get('cable_disconnected', False):
            return False
        # If we have link status and no cable disconnect flag, assume connected
        if last_status.get('link') == 'UP':
            return True
    
    # Check ULP cable status reads (Page 779 Reg 29)
    if results['ulp_analysis']['cable_status_reads']:
        for cs in results['ulp_analysis']['cable_status_reads']:
            if cs['value'] in [0x00FF, 0xFF00, 0xFFFF]:
                return False
    
    return None  # Unknown


def check_critical_requirements(register_values, results):
    """
    Context-aware validation of critical register configurations
    Intelligently validates based on trace context and hardware capabilities
    """
    # Detect trace context
    context = detect_trace_context(results)
    results['trace_context'] = context
    
    # Get PHY capabilities
    capabilities = get_phy_capabilities(register_values)
    results['phy_capabilities'] = capabilities
    
    # Add context info
    context_msg = {
        'active': 'Normal active operation',
        's_state': 'S-state (sleep/standby) period',
        'mixed': 'Mixed (entering/exiting S-state)',
        'unknown': 'Unknown context'
    }
    results['configuration_checks'].append({
        'category': 'trace_context',
        'check': 'Trace Context Detection',
        'status': 'ℹ️ INFO',
        'details': context_msg.get(context, 'Unknown')
    })
    
    # Validate based on context
    if context == 'active':
        validate_active_operation(register_values, results, capabilities)
    elif context == 's_state':
        validate_s_state_configuration(register_values, results, capabilities)
    elif context == 'mixed':
        validate_mixed_context(register_values, results, capabilities)
    
    # Always validate SMBus configuration (context-independent)
    validate_smbus_configuration(register_values, results, capabilities)


def validate_active_operation(register_values, results, capabilities):
    """Validate registers for active (non-sleep) operation"""
    
    # Check Power Down bit (should be 0 in active mode)
    key_ctrl = (0, 0)  # Page 0 Reg 0
    if key_ctrl in register_values:
        ctrl_val = register_values[key_ctrl]
        power_down = (ctrl_val >> 11) & 1
        
        if power_down == 1:
            results['issues'].append({
                'type': 'unexpected_power_down',
                'severity': 'error',
                'register': 'Page 0 Reg 0',
                'field': 'Power Down',
                'expected': '0',
                'actual': '1',
                'note': 'Power Down set during active operation - PHY cannot operate'
            })
        else:
            results['configuration_checks'].append({
                'category': 'active_operation',
                'check': 'Power Down = 0',
                'status': '✅ PASS',
                'details': 'PHY powered on for active operation'
            })
    
    # Check Transmit Disable (should be 0 for normal operation)
    key_port = (769, 0x11)  # Page 769 Reg 17 - Port General Config
    if key_port in register_values:
        port_val = register_values[key_port]
        tx_disable = (port_val >> 13) & 1
        
        if tx_disable == 1:
            results['issues'].append({
                'type': 'transmit_disabled',
                'severity': 'error',
                'register': 'Page 769 Reg 0x11',
                'field': 'Transmit Disable',
                'expected': '0',
                'actual': '1',
                'note': 'Transmit disabled - cannot send packets'
            })


def validate_s_state_configuration(register_values, results, capabilities):
    """Validate registers for S-state (sleep/standby) operation"""
    
    cable_connected = is_cable_connected(results)
    
    # Check ULP configuration
    key_ulp = (779, 0x10)  # Page 779 Reg 16 - ULP Config 1
    if key_ulp in register_values:
        ulp_val = register_values[key_ulp]
        wol_host = (ulp_val >> 6) & 1
        wol_me = (ulp_val >> 7) & 1
        
        if wol_host or wol_me:
            results['configuration_checks'].append({
                'category': 's_state_config',
                'check': 'WOL Configured',
                'status': '✅ PASS',
                'details': f'WOL_HOST={wol_host}, WOL_ME={wol_me}'
            })
        else:
            results['warnings'].append({
                'type': 'wol_not_configured',
                'message': 'S-state detected but WOL not configured (ULP Page 779 Reg 16 bits 6-7 = 0)'
            })
    
    # Check Magic Packet WOL only if cable is connected
    if cable_connected is False:
        results['configuration_checks'].append({
            'category': 's_state_config',
            'check': 'Cable Status',
            'status': 'ℹ️ INFO',
            'details': 'Cable disconnected - Magic Packet WOL unavailable. GPIO wake sources may be used.'
        })
    elif cable_connected is True:
        # Cable connected - validate Magic Packet WOL configuration
        key_wuc = (800, 0x01)  # Page 800 Reg 1 - Wake Up Control
        if key_wuc in register_values:
            wuc_val = register_values[key_wuc]
            wuc_enable = (wuc_val >> 15) & 1
            magic_pkt = (wuc_val >> 2) & 1
            
            if wuc_enable and magic_pkt:
                results['configuration_checks'].append({
                    'category': 's_state_config',
                    'check': 'Magic Packet WOL',
                    'status': '✅ PASS',
                    'details': f'Wake Up Control = 0x{wuc_val:04X} - Magic Packet enabled'
                })
            elif not magic_pkt:
                results['warnings'].append({
                    'type': 'magic_packet_not_enabled',
                    'message': 'Cable connected but Magic Packet WOL not enabled (Page 800 Reg 1 bit 2 = 0)'
                })
    
    # Check MACPD Enable (required for WOL)
    key_port = (769, 0x11)  # Page 769 Reg 17
    if key_port in register_values:
        port_val = register_values[key_port]
        macpd_enable = (port_val >> 2) & 1
        
        if macpd_enable:
            results['configuration_checks'].append({
                'category': 's_state_config',
                'check': 'MACPD Enable',
                'status': '✅ PASS',
                'details': 'MAC Power Down enabled for WOL'
            })


def validate_mixed_context(register_values, results, capabilities):
    """Validate mixed context (transitioning into/out of S-state)"""
    results['configuration_checks'].append({
        'category': 'mixed_context',
        'check': 'Validation Scope',
        'status': 'ℹ️ INFO',
        'details': 'Trace contains S-state transition - skipping strict validation'
    })


def validate_smbus_configuration(register_values, results, capabilities):
    """Validate SMBus configuration (always check regardless of context)"""
    
    # Check if SMBus is supported
    if capabilities.get('smbus') is False:
        results['warnings'].append({
            'type': 'smbus_not_supported',
            'message': 'SMBus not supported by this PHY SKU (Page 776 Reg 0x13 bit 2 = 0)'
        })
        return
    
    # Check SMBus enable
    key_smb_ctrl = (769, 0x17)  # Page 769 Reg 23 - SMBus Control
    if key_smb_ctrl in register_values:
        smb_val = register_values[key_smb_ctrl]
        smb_enable = (smb_val >> 15) & 1
        smb_mode = (smb_val >> 5) & 1
        
        results['configuration_checks'].append({
            'category': 'smbus_config',
            'check': 'SMBus Status',
            'status': '✅ DETECTED' if smb_enable or smb_mode else 'ℹ️ INFO',
            'details': f'Enable={smb_enable}, Mode Active={smb_mode}'
        })


def detect_enhanced_events(trans, register_values, results):
    """
    Detect PHY events using enhanced spec knowledge
    
    Args:
        trans: Current transaction
        register_values: Dictionary of current register values
        results: Results dictionary to append events
    """
    page = trans.get('page')
    register = trans.get('register')
    value = trans.get('data_value')
    
    if value is None:
        return
    
    # Detect Reset events (Page 0, Reg 0, Bit 15)
    if page == 0 and register == 0x00:
        reset_bit = (value >> 15) & 1
        if reset_bit == 1:
            results['reset_events'].append({
                'index': trans.get('index'),
                'time': trans.get('time'),
                'description': 'Software Reset initiated',
                'register_value': f'0x{value:04X}'
            })
    
    # Detect Link Status changes (Page 0, Reg 1, Bit 2)
    if page == 0 and register == 0x01:
        link_status = (value >> 2) & 1
        key = (page, register)
        if key in register_values:
            prev_value = register_values[key]
            if prev_value is not None:
                prev_link = (prev_value >> 2) & 1
                if link_status != prev_link:
                    results['link_status_history'].append({
                        'index': trans.get('index'),
                        'time': trans.get('time'),
                        'status': 'Link Up' if link_status else 'Link Down',
                        'value': f'0x{value:04X}'
                    })
    
    # Detect Speed changes (Page 0, Reg 0x17, Bits 4:3)
    if page == 0 and register == 0x17:
        speed_bits = (value >> 3) & 0x3
        speed_map = {0: '10Mbps', 1: '100Mbps', 2: '1000Mbps', 3: 'Reserved'}
        speed = speed_map.get(speed_bits, 'Unknown')
        
        key = (page, register)
        if key in register_values:
            prev_value = register_values[key]
            if prev_value is not None:
                prev_speed_bits = (prev_value >> 3) & 0x3
                if speed_bits != prev_speed_bits:
                    results['speed_changes'].append({
                        'index': trans.get('index'),
                        'time': trans.get('time'),
                        'from': speed_map.get(prev_speed_bits, 'Unknown'),
                        'to': speed,
                        'value': f'0x{value:04X}'
                    })
    
    # Detect EEE/LPI events (Page 772, Reg 0x14)
    if page == 772 and register == 0x14:
        eee_enable = (value >> 15) & 1
        tx_lpi = (value >> 14) & 1
        rx_lpi = (value >> 13) & 1
        
        if eee_enable:
            results['configuration_checks'].append({
                'category': 'eee_config',
                'check': 'EEE Enabled',
                'status': '✅ Detected',
                'details': f'TX_LPI={tx_lpi}, RX_LPI={rx_lpi}',
                'index': trans.get('index'),
                'time': trans.get('time')
            })
    
    # Detect WOL configuration (Page 800, Reg 0x01)
    if page == 800 and register == 0x01:
        wuc_enable = (value >> 15) & 1
        magic_pkt = (value >> 2) & 1
        
        if wuc_enable:
            results['configuration_checks'].append({
                'category': 'wol_config',
                'check': 'WOL Enabled',
                'status': '✅ Detected',
                'details': f'Magic Packet Enable={magic_pkt}',
                'index': trans.get('index'),
                'time': trans.get('time')
            })


def analyze_trace(filename):
    """Analyze SMBus trace and return debug analysis results"""
    try:
        transactions = parse_smbus_csv(filename)
    except Exception as e:
        raise Exception(f"Error parsing CSV file: {str(e)}")
    
    results = {
        'total_transactions': len(transactions),
        'transactions': transactions,
        'register_accesses': {},
        'configuration_checks': [],
        'flow_analysis': [],
        'issues': [],
        'warnings': [],
        'status_messages': [],
        'link_status_history': [],
        'speed_changes': [],
        'page_accesses': {},
        'wake_events': [],  # Track wake-up messages
        'host_wake_count': 0,
        'me_wake_count': 0,
        # ULP Analysis
        'ulp_analysis': {
            'page_779_accessed': False,
            'ulp_config_written': False,
            'ulp_config_value': None,
            'wol_host_enabled': False,
            'wol_me_enabled': False,
            'ulp_entry_detected': False,
            'cable_status_reads': [],
            'link_partner_status': []
        },
        'time_gaps': [],  # Large gaps indicating S-states
        'nack_periods': [],  # Periods where PHY not responding
        'reset_events': [],  # SW Reset events with timestamps
        'initialization_sequences': [],  # Full init sequences detected
        'trace_context': 'unknown',  # Context detection result
        'phy_capabilities': {}  # PHY hardware capabilities
    }
    
    # Track current page
    current_page = 0
    register_values = {}  # {(page, register): last_value}
    all_values = {}  # {(page, register): [list of all values]}
    write_sequence = []   # Track write sequence for flow detection
    last_link_status = None
    last_speed = None
    
    # Time tracking for gap detection
    last_time = None
    last_time_str = None
    last_valid_index = None
    nack_start = None
    in_nack_period = False
    
    for trans in transactions:
        page = trans.get('page', current_page)
        register = trans.get('register')
        data_value = trans.get('data_value')
        direction = trans.get('direction', '')
        msg_type = trans.get('message_type', '')
        time_str = trans.get('time', '')
        trans_index = trans.get('index', 0)
        
        # Parse time for gap detection
        current_time = parse_time_to_seconds(time_str)
        
        # Detect NACK periods (no data transactions)
        is_nack = data_value is None and register is None and msg_type == ''
        
        if is_nack:
            if not in_nack_period:
                in_nack_period = True
                nack_start = {'index': trans_index, 'time': time_str}
        else:
            if in_nack_period and nack_start:
                results['nack_periods'].append({
                    'start_index': nack_start['index'],
                    'start_time': nack_start['time'],
                    'end_index': trans_index,
                    'end_time': time_str
                })
                in_nack_period = False
                nack_start = None
        
        # Detect large time gaps (potential S-state periods)
        if current_time is not None and last_time is not None:
            gap = current_time - last_time
            if gap > 5.0:  # Gap > 5 seconds indicates potential S-state
                results['time_gaps'].append({
                    'from_index': last_valid_index,
                    'to_index': trans_index,
                    'from_time': last_time_str,
                    'to_time': time_str,
                    'gap_seconds': round(gap, 3)
                })
        
        if current_time is not None:
            last_time = current_time
            last_time_str = time_str
            last_valid_index = trans_index
        
        # Track page changes
        if register == 31 and trans.get('page_access') is not None:
            new_page = trans.get('page_access')
            if new_page not in results['page_accesses']:
                results['page_accesses'][new_page] = 0
            results['page_accesses'][new_page] += 1
            current_page = new_page
            
            # Track ULP page access (Page 779)
            if new_page == 779:
                results['ulp_analysis']['page_779_accessed'] = True
            continue
        
        # Track ULP-related register accesses
        if page == 779:
            results['ulp_analysis']['page_779_accessed'] = True
            
            # Register 16 (0x10) - ULP Control/WOL Config
            if register == 16 and data_value is not None:
                results['ulp_analysis']['ulp_config_written'] = True
                results['ulp_analysis']['ulp_config_value'] = data_value
                # Check WOL bits
                results['ulp_analysis']['wol_me_enabled'] = bool((data_value >> 7) & 1)
                results['ulp_analysis']['wol_host_enabled'] = bool((data_value >> 6) & 1)
            
            # Register 29 (0x1D) - Cable Status
            if register == 29 and data_value is not None:
                results['ulp_analysis']['cable_status_reads'].append({
                    'index': trans_index,
                    'time': time_str,
                    'value': data_value
                })
        
        # Track Page 770 Register 17 - Link Partner Status
        if page == 770 and register == 17 and data_value is not None:
            results['ulp_analysis']['link_partner_status'].append({
                'index': trans_index,
                'time': time_str,
                'value': data_value,
                'link_partner_present': not bool((data_value >> 10) & 1)
            })
        
        # Track SW Reset events (IEEE 802.3 Control Register: Page 0, Reg 0, Bit 15)
        if page == 0 and register == 0 and data_value is not None:
            if (data_value >> 15) & 1:  # SW Reset bit
                results['reset_events'].append({
                    'index': trans_index,
                    'time': time_str,
                    'value': data_value
                })
        
        # Track Wake-up Messages (D5 command)
        if msg_type == 'Wake-up Message':
            wake_type = trans.get('wake_type', 'Unknown')
            wake_event = {
                'index': trans.get('index'),
                'time': trans.get('time', ''),
                'type': wake_type,
                'raw_byte': trans.get('wake_indication', 0)
            }
            results['wake_events'].append(wake_event)
            
            if wake_type == 'Host Wake':
                results['host_wake_count'] += 1
            elif wake_type == 'ME Wake':
                results['me_wake_count'] += 1
        
        # Track PtM Status messages for link/speed monitoring
        if msg_type in ['PtM Status', 'Status'] and data_value is not None:
            # Parse status bits per Jacksonville EAS 1.12 Table 14 / SMBUS_STATUS_BITS
            # 16-bit PtM status: Speed[15:14], Duplex[13], Link[12,10], Cable[11], Reset[8]
            link_up = (data_value >> 10) & 1
            duplex = (data_value >> 13) & 1
            speed = (data_value >> 14) & 0x03
            cable_dis = (data_value >> 11) & 1
            
            speed_str = {0: '10Mbps', 1: '100Mbps', 2: '1Gbps', 3: 'Reserved'}.get(speed, 'Unknown')
            duplex_str = 'Full' if duplex else 'Half'
            link_str = 'UP' if link_up else 'DOWN'
            
            status_entry = {
                'index': trans.get('index'),
                'link': link_str,
                'speed': speed_str,
                'duplex': duplex_str,
                'cable_disconnected': bool(cable_dis),
                'raw_value': data_value
            }
            results['link_status_history'].append(status_entry)
            
            # Check for link changes
            if last_link_status is not None and link_up != last_link_status:
                change_type = 'Link UP' if link_up else 'Link DOWN'
                results['warnings'].append({
                    'type': 'link_change',
                    'message': f"Link state changed to {change_type} at transaction {trans.get('index')}",
                    'index': trans.get('index')
                })
            last_link_status = link_up
            
            # Check for speed changes
            if last_speed is not None and speed != last_speed:
                old_speed = {0: '10Mbps', 1: '100Mbps', 2: '1Gbps', 3: 'Reserved'}.get(last_speed)
                results['speed_changes'].append({
                    'index': trans.get('index'),
                    'from': old_speed,
                    'to': speed_str
                })
            last_speed = speed
        
        if page is not None and register is not None:
            key = (page, register)
            
            # Track all values seen
            if key not in all_values:
                all_values[key] = []
            if data_value is not None:
                all_values[key].append(data_value)
            
            # Track register accesses
            if key not in results['register_accesses']:
                results['register_accesses'][key] = {'reads': 0, 'writes': 0, 'last_value': None, 'all_values': []}
            
            if 'Write' in direction or 'MAC→PHY' in direction or 'Config' in msg_type:
                results['register_accesses'][key]['writes'] += 1
                if data_value is not None:
                    results['register_accesses'][key]['last_value'] = data_value
                    results['register_accesses'][key]['all_values'].append(('W', data_value))
                    register_values[key] = data_value
                    write_sequence.append({'page': page, 'register': register, 'value': data_value, 'index': trans.get('index')})
                    
                    # *** ENHANCED: Validate write operation ***
                    validate_register_access(page, register, data_value, 'write', results)
                    
                    # *** ENHANCED: Detect events with spec knowledge ***
                    detect_enhanced_events(trans, register_values, results)
            else:
                results['register_accesses'][key]['reads'] += 1
                if data_value is not None:
                    results['register_accesses'][key]['last_value'] = data_value
                    results['register_accesses'][key]['all_values'].append(('R', data_value))
                    
                    # *** ENHANCED: Validate read operation ***
                    validate_register_access(page, register, data_value, 'read', results)
                    
                    # *** ENHANCED: Detect events with spec knowledge ***
                    detect_enhanced_events(trans, register_values, results)
    
    # ============================================================================
    # ISSUE DETECTION
    # ============================================================================
    
    # Check 1: Link down at end of trace
    if results['link_status_history']:
        last_status = results['link_status_history'][-1]
        if last_status['link'] == 'DOWN':
            results['issues'].append({
                'type': 'link_down',
                'severity': 'error',
                'register': 'PHY Status',
                'field': 'Link Status',
                'expected': 'UP',
                'actual': 'DOWN',
                'note': 'Link is DOWN at end of trace - check cable connection or PHY configuration'
            })
    
    # Check 2: Cable disconnected
    if results['link_status_history']:
        for status in results['link_status_history']:
            if status['cable_disconnected']:
                results['issues'].append({
                    'type': 'cable_disconnected',
                    'severity': 'error',
                    'register': 'PHY Status',
                    'field': 'Cable Disconnected',
                    'expected': '0',
                    'actual': '1',
                    'note': f"Cable disconnected detected at transaction {status['index']}"
                })
                break
    
    # Check 3: Loopback mode enabled (might be intentional)
    key_ctrl = (0, 0)  # Page 0 Register 0
    if key_ctrl in register_values:
        ctrl_val = register_values[key_ctrl]
        if (ctrl_val >> 14) & 1:  # Loopback bit
            results['warnings'].append({
                'type': 'loopback_enabled',
                'message': 'Loopback mode is ENABLED in Control Register (Page 0, Reg 0, Bit 14)'
            })
    
    # NOTE: Check 4 (Power down mode) removed - now handled by context-aware validation
    
    # Check 5: Auto-negotiation disabled when it should be enabled
    if key_ctrl in register_values:
        ctrl_val = register_values[key_ctrl]
        an_enable = (ctrl_val >> 12) & 1
        if not an_enable:
            results['warnings'].append({
                'type': 'an_disabled',
                'message': 'Auto-Negotiation is DISABLED - manual speed/duplex configuration required'
            })
    
    # Check 6: ULP Force mode
    key_ulp = (779, 16)
    if key_ulp in register_values:
        ulp_val = register_values[key_ulp]
        if (ulp_val >> 14) & 1:  # FORCE_ULP bit
            results['warnings'].append({
                'type': 'ulp_forced',
                'message': 'ULP (Ultra Low Power) mode is FORCED - Page 779 Reg 16 Bit 14'
            })
    
    # Check 7: Multiple resets detected
    reset_count = 0
    for write in write_sequence:
        if write['page'] == 0 and write['register'] == 0:
            if (write['value'] >> 15) & 1:  # Reset bit
                reset_count += 1
    if reset_count > 1:
        results['warnings'].append({
            'type': 'multiple_resets',
            'message': f'Multiple PHY resets detected ({reset_count} times) - may indicate initialization issues'
        })
    
    # Check 8: No page accesses (might indicate parsing issue)
    if not results['page_accesses']:
        results['warnings'].append({
            'type': 'no_page_access',
            'message': 'No page select operations detected - all accesses may be on Page 0 or parsing issue'
        })
    
    # Check 9: Speed mismatch between status reports
    if len(results['speed_changes']) > 0:
        for change in results['speed_changes']:
            results['warnings'].append({
                'type': 'speed_change',
                'message': f"Speed changed from {change['from']} to {change['to']} at transaction {change['index']}"
            })
    
    # Check 10: No register values captured at all
    if not register_values:
        results['warnings'].append({
            'type': 'no_register_values',
            'message': 'No register write values captured - data may not be parsed correctly or trace contains only reads'
        })
    
    # Check 11: Very few transactions
    if results['total_transactions'] < 10:
        results['warnings'].append({
            'type': 'few_transactions',
            'message': f'Only {results["total_transactions"]} transactions found - trace may be incomplete'
        })
    
    # Check 12: No link status messages
    if not results['link_status_history']:
        results['warnings'].append({
            'type': 'no_link_status',
            'message': 'No PtM Status messages detected - link status cannot be monitored'
        })
    
    # Check 13: Report all pages accessed for debugging
    if results['page_accesses']:
        pages_str = ', '.join([str(p) for p in sorted(results['page_accesses'].keys())])
        results['warnings'].append({
            'type': 'pages_accessed',
            'message': f'Pages accessed: {pages_str}'
        })
    
    # ============================================================================
    # ULP ANALYSIS CHECKS
    # ============================================================================
    
    # Check 14: ULP page not accessed when wake events expected
    ulp = results['ulp_analysis']
    if not ulp['page_779_accessed']:
        if results['time_gaps']:  # If there are S-state gaps, ULP should have been configured
            results['warnings'].append({
                'type': 'ulp_not_configured',
                'message': 'ULP Page 779 was NOT accessed - ULP entry not attempted before S-state'
            })
    
    # Check 15: No wake messages but time gaps exist
    if results['time_gaps'] and not results['wake_events']:
        results['warnings'].append({
            'type': 'no_wake_in_sstate',
            'message': f'Time gaps detected ({len(results["time_gaps"])} S-state periods) but NO wake-up messages (D5) received'
        })
    
    # Check 16: ULP configuration without WOL enabled
    if ulp['ulp_config_written'] and not ulp['wol_host_enabled'] and not ulp['wol_me_enabled']:
        results['warnings'].append({
            'type': 'ulp_no_wol',
            'message': f'ULP config written (0x{ulp["ulp_config_value"]:04X}) but neither WOL_HOST nor WOL_ME enabled'
        })
    
    # Check 17: NACK periods detected (PHY not responding)
    if results['nack_periods']:
        for nack in results['nack_periods']:
            results['warnings'].append({
                'type': 'nack_period',
                'message': f'PHY NACK period: Lines {nack["start_index"]}-{nack["end_index"]} ({nack["start_time"]} to {nack["end_time"]})'
            })
    
    # Check 18: Large time gaps (S-state detection)
    if results['time_gaps']:
        for gap in results['time_gaps']:
            gap_desc = f"{gap['gap_seconds']:.1f}s"
            if gap['gap_seconds'] > 60:
                gap_desc = f"{gap['gap_seconds']/60:.1f}min"
            results['warnings'].append({
                'type': 'time_gap',
                'message': f'Large time gap detected: {gap_desc} (Lines {gap["from_index"]}-{gap["to_index"]}) - possible S-state period'
            })
    
    # Check 19: Multiple reset events
    if len(results['reset_events']) > 1:
        reset_times = [f"Line {r['index']}" for r in results['reset_events']]
        results['warnings'].append({
            'type': 'multiple_resets_timed',
            'message': f'Multiple SW Reset events: {", ".join(reset_times)}'
        })
    
    # Check 20: Cable status indicates disconnected
    if ulp['cable_status_reads']:
        for status in ulp['cable_status_reads']:
            if status['value'] == 0x00FF or status['value'] == 0xFF00:
                results['warnings'].append({
                    'type': 'cable_disconnected_ulp',
                    'message': f'Cable status (Page 779 Reg 29) = 0x{status["value"]:04X} at Line {status["index"]} - Cable disconnected'
                })
                break
    
    # Check 21: Link partner not present
    if ulp['link_partner_status']:
        for lp in ulp['link_partner_status']:
            if not lp['link_partner_present']:
                results['warnings'].append({
                    'type': 'no_link_partner',
                    'message': f'Link Partner absent (Page 770 Reg 17) = 0x{lp["value"]:04X} at Line {lp["index"]}'
                })
                break
    
    # Analyze configuration against specs
    for spec_name, spec in SPEC_DEFINITIONS.items():
        try:
            if 'page' not in spec or 'register' not in spec:
                continue
                
            key = (spec['page'], spec['register'])
            if key in register_values:
                value = register_values[key]
                check_result = {
                    'name': spec['description'],
                    'page': spec['page'],
                    'register': spec['register'],
                    'value': value,
                    'fields': []
                }
                
                for field_name, field_def in spec['fields'].items():
                    if 'bit' in field_def:
                        bit_val = (value >> field_def['bit']) & 1
                        field_result = {
                            'name': field_def['name'],
                            'bit': field_def['bit'],
                            'value': bit_val,
                            'expected': field_def.get('expected'),
                            'note': field_def.get('note', '')
                        }
                        
                        if field_def.get('expected') is not None:
                            field_result['match'] = (bit_val == field_def['expected'])
                            if not field_result['match']:
                                results['issues'].append({
                                    'type': 'mismatch',
                                    'register': f"Page {spec['page']} Reg {spec['register']}",
                                    'field': field_def['name'],
                                    'expected': field_def['expected'],
                                    'actual': bit_val,
                                    'note': field_def.get('note', '')
                                })
                        else:
                            field_result['match'] = None
                        
                        check_result['fields'].append(field_result)
                        
                    elif 'bits' in field_def:
                        # Multi-bit field
                        bits = field_def['bits']
                        mask = 0
                        for b in bits:
                            mask |= (1 << b)
                        bit_val = (value & mask) >> min(bits)
                        
                        field_result = {
                            'name': field_def['name'],
                            'bits': bits,
                            'value': bit_val,
                            'expected': field_def.get('expected'),
                            'note': field_def.get('note', '')
                        }
                        field_result['match'] = None
                        check_result['fields'].append(field_result)
                
                results['configuration_checks'].append(check_result)
        except KeyError as e:
            # Add detailed error information
            raise Exception(f"KeyError in SPEC_DEFINITIONS['{spec_name}']: {str(e)}. Spec keys: {list(spec.keys())}")
        except Exception as e:
            # Catch any other errors with context
            raise Exception(f"Error processing SPEC_DEFINITIONS['{spec_name}']: {str(e)}")
    
    # Detect configuration flows
    for flow_name, flow in CONFIGURATION_FLOWS.items():
        try:
            flow_result = {
                'name': flow['name'],
                'description': flow['description'],
                'steps_found': [],
                'steps_missing': [],
                'complete': True
            }
            
            for step in flow['steps']:
                # Safety check: ensure step has required keys
                if 'page' not in step or 'register' not in step:
                    continue
                
                key = (step['page'], step['register'])
                step_desc = f"Page {step['page']} Reg {step['register']}: {step['desc']}"
                
                if key in register_values:
                    flow_result['steps_found'].append(step_desc)
                else:
                    flow_result['steps_missing'].append(step_desc)
                    flow_result['complete'] = False
        except KeyError as e:
            # Add detailed error information
            raise Exception(f"KeyError in CONFIGURATION_FLOWS['{flow_name}']: {str(e)}. Flow keys: {list(flow.keys())}")
        except Exception as e:
            # Catch any other errors with context
            raise Exception(f"Error processing CONFIGURATION_FLOWS['{flow_name}']: {str(e)}")
        
        if flow_result['steps_found']:  # Only add if at least some steps were found
            results['flow_analysis'].append(flow_result)
    
    # ============================================================================
    # *** ENHANCED: Check critical register configuration requirements ***
    # ============================================================================
    check_critical_requirements(register_values, results)
    
    # Generate status messages
    if not results['issues']:
        results['status_messages'].append(('success', 'No critical issues detected'))
    else:
        results['status_messages'].append(('warning', f'{len(results["issues"])} potential issue(s) found'))
    
    # Add enhanced analysis summary
    context_display = {
        'active': 'Active Operation',
        's_state': 'S-State (Sleep/Standby)',
        'mixed': 'Mixed (Transitioning)',
        'unknown': 'Unknown'
    }
    results['status_messages'].append(('info', f'Trace Context: {context_display.get(results["trace_context"], "Unknown")}'))
    
    # PHY capabilities summary
    caps = results.get('phy_capabilities', {})
    if caps.get('jacksonville_phy'):
        cap_list = []
        if caps.get('eee'): cap_list.append('EEE')
        if caps.get('wol'): cap_list.append('WOL')
        if caps.get('ulp'): cap_list.append('ULP')
        if caps.get('smbus'): cap_list.append('SMBus')
        if cap_list:
            results['status_messages'].append(('info', f'PHY Capabilities: {", ".join(cap_list)}'))
    
    return results


def create_debug_window(filename):
    """Create the debug analysis window"""
    # Analyze the trace
    results = analyze_trace(filename)
    
    # VS Code colors
    colors = {
        'bg': '#1e1e1e',
        'surface': '#252526',
        'surface_light': '#2d2d2d',
        'accent': '#007acc',
        'text': '#cccccc',
        'text_bright': '#ffffff',
        'text_dim': '#808080',
        'success': '#4ec9b0',
        'warning': '#dcdcaa',
        'error': '#f14c4c',
        'border': '#3c3c3c',
        'selection': '#264f78'
    }
    
    window = tk.Toplevel()
    window.title(f"Debug Analysis - {os.path.basename(filename)}")
    window.geometry("1100x750")
    window.configure(bg=colors['bg'])
    
    # Styling
    style = ttk.Style(window)
    style.theme_use('clam')
    style.configure(".", background=colors['bg'], foreground=colors['text'])
    style.configure("TFrame", background=colors['bg'])
    style.configure("TNotebook", background=colors['surface'], borderwidth=0)
    style.configure("TNotebook.Tab", font=("Segoe UI", 10), padding=[15, 8],
                    background=colors['surface_light'], foreground=colors['text_dim'])
    style.map("TNotebook.Tab",
              background=[('selected', colors['bg'])],
              foreground=[('selected', colors['text_bright'])])
    style.configure("Treeview", font=("Consolas", 10), rowheight=24,
                    background=colors['surface'], foreground=colors['text'],
                    fieldbackground=colors['surface'])
    style.configure("Treeview.Heading", font=("Segoe UI", 10),
                    background=colors['surface_light'], foreground=colors['text'])
    style.map("Treeview", background=[('selected', colors['selection'])],
              foreground=[('selected', colors['text_bright'])])
    
    # Header
    header = tk.Frame(window, bg=colors['surface_light'], height=40)
    header.pack(fill=tk.X)
    header.pack_propagate(False)
    
    tk.Label(header, text="Debug Analysis", font=("Segoe UI", 12),
             bg=colors['surface_light'], fg=colors['text']).pack(side=tk.LEFT, padx=15, pady=8)
    
    # Status indicator
    status_color = colors['success'] if not results['issues'] else colors['warning']
    status_text = f"{results['total_transactions']} transactions • {len(results['issues'])} issues"
    tk.Label(header, text=status_text, font=("Consolas", 10),
             bg=colors['surface_light'], fg=status_color).pack(side=tk.RIGHT, padx=15, pady=8)
    
    # Notebook
    notebook = ttk.Notebook(window)
    notebook.pack(fill=tk.BOTH, expand=True, padx=0, pady=0)
    
    # === TAB 1: Issues & Warnings ===
    issues_frame = tk.Frame(notebook, bg=colors['bg'])
    notebook.add(issues_frame, text="  Issues & Warnings  ")
    
    # Create scrollable text widget for issues
    issues_text = tk.Text(issues_frame, font=("Consolas", 10), bg=colors['surface'],
                          fg=colors['text'], wrap=tk.WORD, padx=15, pady=15)
    issues_scroll = ttk.Scrollbar(issues_frame, orient=tk.VERTICAL, command=issues_text.yview)
    issues_text.configure(yscrollcommand=issues_scroll.set)
    issues_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    issues_scroll.pack(side=tk.RIGHT, fill=tk.Y)
    
    issues_text.tag_configure("header", foreground=colors['accent'], font=("Segoe UI", 12, "bold"))
    issues_text.tag_configure("error", foreground=colors['error'])
    issues_text.tag_configure("warning", foreground=colors['warning'])
    issues_text.tag_configure("success", foreground=colors['success'])
    issues_text.tag_configure("info", foreground=colors['text_dim'])
    
    # Summary section
    issues_text.insert(tk.END, "═══════════════════════════════════════════════════════════════\n", "header")
    issues_text.insert(tk.END, "                      ANALYSIS SUMMARY\n", "header")
    issues_text.insert(tk.END, "═══════════════════════════════════════════════════════════════\n\n", "header")
    
    issues_text.insert(tk.END, f"Total Transactions Analyzed: {results['total_transactions']}\n", "info")
    issues_text.insert(tk.END, f"Unique Register Accesses: {len(results['register_accesses'])}\n", "info")
    issues_text.insert(tk.END, f"Link Status Reports: {len(results['link_status_history'])}\n", "info")
    issues_text.insert(tk.END, f"Pages Accessed: {len(results['page_accesses'])}\n", "info")
    issues_text.insert(tk.END, "\n")

    # Unexpected address detection
    unexpected_addrs = {}
    addr_dist = {}
    for t in results.get('transactions', []):
        a = t.get('address', '')
        if a:
            addr_dist[a] = addr_dist.get(a, 0) + 1
            if t.get('unexpected_address'):
                unexpected_addrs[a] = unexpected_addrs.get(a, 0) + 1
    if unexpected_addrs:
        issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n", "error")
        issues_text.insert(tk.END, "  ⚠️  UNEXPECTED SMBUS ADDRESSES DETECTED\n", "error")
        issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n", "error")
        for a, c in sorted(unexpected_addrs.items()):
            issues_text.insert(tk.END, f"  ⚠️  Address 0x{a}: {c} transactions\n", "error")
        issues_text.insert(tk.END, "  Expected: 0x6E (MAC→PHY) and 0x70 (PHY→MAC) only.\n\n", "error")
    if addr_dist:
        issues_text.insert(tk.END, "Address Distribution:\n", "info")
        for a, c in sorted(addr_dist.items()):
            tag = "error" if a in unexpected_addrs else "info"
            issues_text.insert(tk.END, f"  0x{a}: {c}\n", tag)
        issues_text.insert(tk.END, "\n")
    
    # Wake Events Summary
    issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n", "header")
    issues_text.insert(tk.END, "                      WAKE EVENTS\n", "header")
    issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n", "header")
    
    if results['wake_events']:
        issues_text.insert(tk.END, f"Total Wake Messages: {len(results['wake_events'])}\n", "info")
        issues_text.insert(tk.END, f"Host Wake Count: {results['host_wake_count']}\n", "success" if results['host_wake_count'] > 0 else "info")
        issues_text.insert(tk.END, f"ME Wake Count: {results['me_wake_count']}\n", "warning" if results['me_wake_count'] > 0 else "info")
        issues_text.insert(tk.END, "\n")
        
        # List each wake event
        for event in results['wake_events']:
            wake_color = "success" if event['type'] == 'Host Wake' else "warning" if event['type'] == 'ME Wake' else "info"
            issues_text.insert(tk.END, f"  • Line {event['index']}: ", "info")
            issues_text.insert(tk.END, f"{event['type']}", wake_color)
            issues_text.insert(tk.END, f" (0x{event['raw_byte']:02X})\n")
    else:
        issues_text.insert(tk.END, "No wake-up messages detected in trace.\n", "info")
    
    issues_text.insert(tk.END, "\n")
    
    # ULP Analysis Section
    issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n", "header")
    issues_text.insert(tk.END, "                    ULP / S-STATE ANALYSIS\n", "header")
    issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n", "header")
    
    ulp = results['ulp_analysis']
    
    # ULP Page Access
    if ulp['page_779_accessed']:
        issues_text.insert(tk.END, "  ✓ Page 779 (ULP) accessed\n", "success")
    else:
        issues_text.insert(tk.END, "  ✗ Page 779 (ULP) NOT accessed\n", "error")
    
    # ULP Config Written
    if ulp['ulp_config_written']:
        issues_text.insert(tk.END, f"  ✓ ULP Config Written: 0x{ulp['ulp_config_value']:04X}\n", "success")
        issues_text.insert(tk.END, f"      WOL_HOST: {'Enabled' if ulp['wol_host_enabled'] else 'Disabled'}\n", 
                          "success" if ulp['wol_host_enabled'] else "info")
        issues_text.insert(tk.END, f"      WOL_ME:   {'Enabled' if ulp['wol_me_enabled'] else 'Disabled'}\n", 
                          "success" if ulp['wol_me_enabled'] else "info")
    else:
        issues_text.insert(tk.END, "  ✗ ULP Config NOT written (Reg 16)\n", "warning")
    
    issues_text.insert(tk.END, "\n")
    
    # Time Gaps (S-state periods)
    if results['time_gaps']:
        issues_text.insert(tk.END, f"  S-State Gaps Detected: {len(results['time_gaps'])}\n", "warning")
        for gap in results['time_gaps']:
            gap_str = f"{gap['gap_seconds']:.1f}s"
            if gap['gap_seconds'] > 60:
                gap_str = f"{gap['gap_seconds']/60:.1f}min"
            issues_text.insert(tk.END, f"    • Gap of {gap_str} (Lines {gap['from_index']}-{gap['to_index']})\n", "info")
    else:
        issues_text.insert(tk.END, "  No large time gaps detected (no S-state periods)\n", "info")
    
    issues_text.insert(tk.END, "\n")
    
    # NACK Periods
    if results['nack_periods']:
        issues_text.insert(tk.END, f"  PHY NACK Periods: {len(results['nack_periods'])}\n", "warning")
        for nack in results['nack_periods'][:3]:  # Show first 3
            issues_text.insert(tk.END, f"    • Lines {nack['start_index']}-{nack['end_index']}\n", "info")
        if len(results['nack_periods']) > 3:
            issues_text.insert(tk.END, f"    ... and {len(results['nack_periods'])-3} more\n", "info")
    else:
        issues_text.insert(tk.END, "  No NACK periods (PHY always responding)\n", "success")
    
    issues_text.insert(tk.END, "\n")
    
    # Reset Events
    if results['reset_events']:
        issues_text.insert(tk.END, f"  SW Reset Events: {len(results['reset_events'])}\n", "info")
        for rst in results['reset_events'][:5]:  # Show first 5
            issues_text.insert(tk.END, f"    • Line {rst['index']} at {rst['time']}\n", "info")
    else:
        issues_text.insert(tk.END, "  No SW Reset events detected\n", "info")
    
    issues_text.insert(tk.END, "\n")
    
    # Cable Status
    if ulp['cable_status_reads']:
        issues_text.insert(tk.END, f"  Cable Status Reads: {len(ulp['cable_status_reads'])}\n", "info")
        for cs in ulp['cable_status_reads'][:3]:
            status = "DISCONNECTED" if cs['value'] in [0x00FF, 0xFF00, 0xFFFF] else "OK"
            color = "error" if status == "DISCONNECTED" else "success"
            issues_text.insert(tk.END, f"    • Line {cs['index']}: 0x{cs['value']:04X} ({status})\n", color)
    
    issues_text.insert(tk.END, "\n")
    
    # Issues section
    if results['issues']:
        issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n", "error")
        issues_text.insert(tk.END, f"  ✗ ISSUES FOUND: {len(results['issues'])}\n", "error")
        issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n", "error")
        
        for i, issue in enumerate(results['issues'], 1):
            issues_text.insert(tk.END, f"Issue #{i}: ", "error")
            issues_text.insert(tk.END, f"{issue['register']} - {issue['field']}\n")
            issues_text.insert(tk.END, f"   Expected: {issue['expected']}  |  Actual: {issue['actual']}\n")
            if issue.get('note'):
                issues_text.insert(tk.END, f"   Note: {issue['note']}\n", "info")
            issues_text.insert(tk.END, "\n")
    else:
        issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n", "success")
        issues_text.insert(tk.END, "  ✓ NO CRITICAL ISSUES DETECTED\n", "success")
        issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n", "success")
    
    # Warnings section
    if results['warnings']:
        issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n", "warning")
        issues_text.insert(tk.END, f"  ⚠ WARNINGS: {len(results['warnings'])}\n", "warning")
        issues_text.insert(tk.END, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n", "warning")
        
        for i, warn in enumerate(results['warnings'], 1):
            issues_text.insert(tk.END, f"Warning #{i}: ", "warning")
            issues_text.insert(tk.END, f"{warn['message']}\n")
            issues_text.insert(tk.END, "\n")
    
    issues_text.config(state=tk.DISABLED)
    
    # === TAB 2: Link Status History ===
    link_frame = tk.Frame(notebook, bg=colors['bg'])
    notebook.add(link_frame, text="  Link Status  ")
    
    if results['link_status_history']:
        link_tree = ttk.Treeview(link_frame, columns=("index", "link", "speed", "duplex", "cable", "raw"), show="headings")
        link_tree.heading("index", text="Trans #")
        link_tree.heading("link", text="Link")
        link_tree.heading("speed", text="Speed")
        link_tree.heading("duplex", text="Duplex")
        link_tree.heading("cable", text="Cable")
        link_tree.heading("raw", text="Raw Value")
        
        link_tree.column("index", width=80)
        link_tree.column("link", width=80)
        link_tree.column("speed", width=100)
        link_tree.column("duplex", width=80)
        link_tree.column("cable", width=120)
        link_tree.column("raw", width=120)
        
        for status in results['link_status_history']:
            cable_status = "DISCONNECTED" if status['cable_disconnected'] else "OK"
            link_tree.insert("", "end", values=(
                status['index'],
                status['link'],
                status['speed'],
                status['duplex'],
                cable_status,
                f"0x{status['raw_value']:04X}"
            ))
        
        link_scroll = ttk.Scrollbar(link_frame, orient=tk.VERTICAL, command=link_tree.yview)
        link_tree.configure(yscrollcommand=link_scroll.set)
        link_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        link_scroll.pack(side=tk.RIGHT, fill=tk.Y)
    else:
        tk.Label(link_frame, text="No PtM Status messages found in trace.\nLink status cannot be determined.",
                 font=("Segoe UI", 12), bg=colors['bg'], fg=colors['text_dim']).pack(pady=50)
    
    # === TAB 3: Register Analysis ===
    regs_frame = tk.Frame(notebook, bg=colors['bg'])
    notebook.add(regs_frame, text="  Register Analysis  ")
    
    for check in results['configuration_checks']:
        # Safety check: skip entries without page/register (e.g., context-aware checks)
        if 'page' not in check or 'register' not in check:
            continue
            
        # Create frame for each register
        reg_frame = tk.LabelFrame(regs_frame, text=f"Page {check['page']} Register {check['register']} - {check['name']}",
                                   font=("Segoe UI", 10), bg=colors['surface'], fg=colors['accent'],
                                   padx=10, pady=5)
        reg_frame.pack(fill=tk.X, padx=10, pady=5)
        
        value_label = tk.Label(reg_frame, text=f"Value: 0x{check['value']:04X} ({check['value']})",
                               font=("Consolas", 10), bg=colors['surface'], fg=colors['text'])
        value_label.pack(anchor=tk.W)
        
        for field in check['fields']:
            if 'bit' in field:
                bit_info = f"Bit {field['bit']}"
            else:
                bit_info = f"Bits {field['bits']}"
            
            if field['match'] is True:
                status = "✓"
                fg = colors['success']
            elif field['match'] is False:
                status = "✗"
                fg = colors['error']
            else:
                status = "○"
                fg = colors['text_dim']
            
            expected_str = f" (expected: {field['expected']})" if field['expected'] is not None else ""
            note_str = f" - {field['note']}" if field['note'] else ""
            
            field_text = f"  {status} {bit_info}: {field['name']} = {field['value']}{expected_str}{note_str}"
            tk.Label(reg_frame, text=field_text, font=("Consolas", 9),
                    bg=colors['surface'], fg=fg).pack(anchor=tk.W)
    
    # Scrollable canvas for register analysis
    canvas = tk.Canvas(regs_frame, bg=colors['bg'], highlightthickness=0)
    scrollbar = ttk.Scrollbar(regs_frame, orient=tk.VERTICAL, command=canvas.yview)
    scrollable_frame = tk.Frame(canvas, bg=colors['bg'])
    
    scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    
    # === TAB 4: Flow Detection ===
    flow_frame = tk.Frame(notebook, bg=colors['bg'])
    notebook.add(flow_frame, text="  Flow Detection  ")
    
    flow_text = tk.Text(flow_frame, font=("Consolas", 10), bg=colors['surface'],
                        fg=colors['text'], wrap=tk.WORD, padx=15, pady=15)
    flow_scroll = ttk.Scrollbar(flow_frame, orient=tk.VERTICAL, command=flow_text.yview)
    flow_text.configure(yscrollcommand=flow_scroll.set)
    flow_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    flow_scroll.pack(side=tk.RIGHT, fill=tk.Y)
    
    flow_text.tag_configure("header", foreground=colors['accent'], font=("Segoe UI", 11, "bold"))
    flow_text.tag_configure("found", foreground=colors['success'])
    flow_text.tag_configure("missing", foreground=colors['error'])
    flow_text.tag_configure("desc", foreground=colors['text_dim'])
    
    if results['flow_analysis']:
        for flow in results['flow_analysis']:
            status = "COMPLETE" if flow['complete'] else "INCOMPLETE"
            status_color = "found" if flow['complete'] else "missing"
            
            flow_text.insert(tk.END, f"\n{flow['name']} [{status}]\n", "header")
            flow_text.insert(tk.END, f"{flow['description']}\n\n", "desc")
            
            if flow['steps_found']:
                flow_text.insert(tk.END, "Steps Found:\n", "found")
                for step in flow['steps_found']:
                    flow_text.insert(tk.END, f"  ✓ {step}\n", "found")
            
            if flow['steps_missing']:
                flow_text.insert(tk.END, "\nSteps Missing:\n", "missing")
                for step in flow['steps_missing']:
                    flow_text.insert(tk.END, f"  ✗ {step}\n", "missing")
            
            flow_text.insert(tk.END, "\n" + "─" * 60 + "\n")
    else:
        flow_text.insert(tk.END, "No configuration flows detected in this trace.\n\n", "desc")
        flow_text.insert(tk.END, "Supported flows:\n", "header")
        for flow_name, flow in CONFIGURATION_FLOWS.items():
            flow_text.insert(tk.END, f"  • {flow['name']}\n", "desc")
    
    flow_text.config(state=tk.DISABLED)
    
    # === TAB 5: Register Access Summary ===
    access_frame = tk.Frame(notebook, bg=colors['bg'])
    notebook.add(access_frame, text="  Register Accesses  ")
    
    access_tree = ttk.Treeview(access_frame, columns=("page", "register", "name", "reads", "writes", "last_value"), show="headings")
    access_tree.heading("page", text="Page")
    access_tree.heading("register", text="Register")
    access_tree.heading("name", text="Name")
    access_tree.heading("reads", text="Reads")
    access_tree.heading("writes", text="Writes")
    access_tree.heading("last_value", text="Last Value")
    
    access_tree.column("page", width=80)
    access_tree.column("register", width=80)
    access_tree.column("name", width=350)
    access_tree.column("reads", width=80)
    access_tree.column("writes", width=80)
    access_tree.column("last_value", width=120)
    
    for (page, register), data in sorted(results['register_accesses'].items()):
        page_name = get_page_name(page)
        reg_name = f"Page {page} Register {register}"
        last_val = f"0x{data['last_value']:04X}" if data['last_value'] is not None else "N/A"
        
        access_tree.insert("", "end", values=(
            page,
            f"0x{register:02X}",
            f"{page_name}",
            data['reads'],
            data['writes'],
            last_val
        ))
    
    access_scroll = ttk.Scrollbar(access_frame, orient=tk.VERTICAL, command=access_tree.yview)
    access_tree.configure(yscrollcommand=access_scroll.set)
    access_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    access_scroll.pack(side=tk.RIGHT, fill=tk.Y)
    
    # === TAB 6: Specifications Reference ===
    spec_frame = tk.Frame(notebook, bg=colors['bg'])
    notebook.add(spec_frame, text="  Spec Reference  ")
    
    spec_text = tk.Text(spec_frame, font=("Consolas", 10), bg=colors['surface'],
                        fg=colors['text'], wrap=tk.WORD, padx=15, pady=15)
    spec_scroll = ttk.Scrollbar(spec_frame, orient=tk.VERTICAL, command=spec_text.yview)
    spec_text.configure(yscrollcommand=spec_scroll.set)
    spec_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    spec_scroll.pack(side=tk.RIGHT, fill=tk.Y)
    
    spec_text.tag_configure("header", foreground=colors['accent'], font=("Segoe UI", 11, "bold"))
    spec_text.tag_configure("field", foreground=colors['success'])
    spec_text.tag_configure("note", foreground=colors['warning'])
    
    spec_text.insert(tk.END, "Jacksonville EAS 1.12 & Clarksville Specification Reference\n", "header")
    spec_text.insert(tk.END, "=" * 60 + "\n\n")
    
    for spec_name, spec in SPEC_DEFINITIONS.items():
        if 'page' in spec and 'register' in spec:
            spec_text.insert(tk.END, f"Page {spec['page']} Register {spec['register']}: {spec['description']}\n", "header")
        else:
            spec_text.insert(tk.END, f"{spec['description']}\n", "header")
        
        for field_name, field_def in spec['fields'].items():
            if 'bit' in field_def:
                bit_str = f"Bit {field_def['bit']}"
            elif 'bits' in field_def:
                bit_str = f"Bits {field_def['bits']}"
            else:
                bit_str = ""
            
            expected = f" [Expected: {field_def['expected']}]" if field_def.get('expected') is not None else ""
            spec_text.insert(tk.END, f"  {bit_str}: {field_def['name']}{expected}\n", "field")
            
            if field_def.get('note'):
                spec_text.insert(tk.END, f"      Note: {field_def['note']}\n", "note")
        
        spec_text.insert(tk.END, "\n")
    
    spec_text.config(state=tk.DISABLED)
    
    # === TAB 7: Raw Data Debug ===
    raw_frame = tk.Frame(notebook, bg=colors['bg'])
    notebook.add(raw_frame, text="  Raw Data  ")
    
    raw_text = tk.Text(raw_frame, font=("Consolas", 10), bg=colors['surface'],
                       fg=colors['text'], wrap=tk.NONE, padx=15, pady=15)
    raw_scroll_y = ttk.Scrollbar(raw_frame, orient=tk.VERTICAL, command=raw_text.yview)
    raw_scroll_x = ttk.Scrollbar(raw_frame, orient=tk.HORIZONTAL, command=raw_text.xview)
    raw_text.configure(yscrollcommand=raw_scroll_y.set, xscrollcommand=raw_scroll_x.set)
    
    raw_text.tag_configure("header", foreground=colors['accent'], font=("Segoe UI", 11, "bold"))
    raw_text.tag_configure("data", foreground=colors['success'])
    raw_text.tag_configure("dim", foreground=colors['text_dim'])
    
    raw_text.insert(tk.END, "RAW PARSED DATA (for debugging)\n", "header")
    raw_text.insert(tk.END, "=" * 80 + "\n\n")
    
    # Show register values dictionary
    raw_text.insert(tk.END, "CAPTURED REGISTER VALUES:\n", "header")
    raw_text.insert(tk.END, "-" * 40 + "\n")
    
    sorted_keys = sorted(results['register_accesses'].keys())
    for (page, register) in sorted_keys:
        data = results['register_accesses'][(page, register)]
        last_val = f"0x{data['last_value']:04X}" if data['last_value'] is not None else "N/A"
        raw_text.insert(tk.END, f"Page {page:3d} Reg 0x{register:02X}: ", "data")
        raw_text.insert(tk.END, f"Last={last_val}, Reads={data['reads']}, Writes={data['writes']}\n")
        
        # Show value history
        if data.get('all_values'):
            raw_text.insert(tk.END, f"    History: ", "dim")
            vals = [f"{op}:0x{v:04X}" for op, v in data['all_values'][-5:]]  # Last 5
            raw_text.insert(tk.END, ", ".join(vals) + "\n", "dim")
    
    raw_text.insert(tk.END, "\n")
    raw_text.insert(tk.END, f"Total unique registers accessed: {len(results['register_accesses'])}\n", "header")
    raw_text.insert(tk.END, f"Total transactions: {results['total_transactions']}\n", "header")
    
    raw_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
    raw_scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
    raw_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    
    raw_text.config(state=tk.DISABLED)
    
    window.focus_force()
