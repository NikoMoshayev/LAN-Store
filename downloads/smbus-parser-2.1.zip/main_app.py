#!/usr/bin/env python3
"""
Jacksonville PHY SMBus Analyzer - Standalone Application
Main entry point for the executable version
"""

import os
import sys
import csv
import tkinter as tk
from tkinter import messagebox, filedialog
import webbrowser
import tempfile

# Add the SRC directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'SRC'))

try:
    from lightweight_analyzer import create_in_app_report
except ImportError as e:
    print(f"Error importing modules: {e}")
    print(f"Current directory: {os.getcwd()}")
    print(f"Script location: {os.path.dirname(__file__)}")
    sys.exit(1)

class SMBusAnalyzerApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Jacksonville PHY SMBus Analyzer")
        self.root.geometry("700x550")
        self.root.minsize(600, 500)
        
        # VS Code dark theme colors
        self.colors = {
            'bg': '#1e1e1e',
            'card': '#252526',
            'accent': '#007acc',
            'highlight': '#007acc',
            'text': '#cccccc',
            'text_dim': '#808080',
            'success': '#4ec9b0',
            'warning': '#dcdcaa',
            'error': '#f14c4c',
            'button': '#0e639c',
            'button_hover': '#1177bb',
            'border': '#3c3c3c',
            'selection': '#264f78'
        }
        
        self.root.configure(bg=self.colors['bg'])
        
        # Initialize variables
        self.selected_file = None
        self.selected_file_summary = None
        
        # Center the window
        self.center_window()
        
        self.create_widgets()
        
    def center_window(self):
        """Center the window on screen"""
        self.root.update_idletasks()
        width = 700
        height = 550
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f"{width}x{height}+{x}+{y}")
        
    def create_widgets(self):
        """Create the modern GUI widgets"""
        # Main container
        main_frame = tk.Frame(self.root, bg=self.colors['bg'])
        main_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        # Header section
        header_frame = tk.Frame(main_frame, bg=self.colors['bg'])
        header_frame.pack(fill=tk.X, pady=(0, 15))
        
        # Title
        title_label = tk.Label(
            header_frame,
            text="Jacksonville PHY SMBus Analyzer",
            font=("Segoe UI", 18),
            bg=self.colors['bg'],
            fg=self.colors['text']
        )
        title_label.pack(pady=(5, 0))
        
        # Subtitle with version
        subtitle_label = tk.Label(
            header_frame,
            text="v2.1 — Intel Corporation",
            font=("Segoe UI", 10),
            bg=self.colors['bg'],
            fg=self.colors['text_dim']
        )
        subtitle_label.pack(pady=(3, 0))
        
        # Card container for file selection
        card_frame = tk.Frame(main_frame, bg=self.colors['card'], relief='flat', bd=0)
        card_frame.pack(fill=tk.X, pady=10, ipady=15, ipadx=15)
        
        # Card inner padding
        card_inner = tk.Frame(card_frame, bg=self.colors['card'])
        card_inner.pack(fill=tk.X, padx=20, pady=10)
        
        # File section header
        file_header = tk.Frame(card_inner, bg=self.colors['card'])
        file_header.pack(fill=tk.X, pady=(0, 10))
        
        file_title = tk.Label(
            file_header,
            text="Select Trace File",
            font=("Segoe UI", 12),
            bg=self.colors['card'],
            fg=self.colors['text']
        )
        file_title.pack(side=tk.LEFT)
        
        # File selection row
        file_row = tk.Frame(card_inner, bg=self.colors['card'])
        file_row.pack(fill=tk.X)
        
        self.file_select_button = tk.Button(
            file_row,
            text="Browse...",
            command=self.select_file,
            font=("Segoe UI", 10),
            bg=self.colors['button'],
            fg='white',
            activebackground=self.colors['button_hover'],
            activeforeground='white',
            cursor='hand2',
            relief='flat',
            padx=15,
            pady=6,
            bd=0
        )
        self.file_select_button.pack(side=tk.LEFT)
        
        self.file_path_label = tk.Label(
            file_row,
            text="No file selected",
            font=("Segoe UI", 10),
            bg=self.colors['card'],
            fg=self.colors['text_dim'],
            anchor=tk.W
        )
        self.file_path_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(15, 0))

        self.file_hint_label = tk.Label(
            card_inner,
            text="Expected: Total Phase CSV with timestamp, address, ACK/NAK, and data-byte columns.",
            font=("Segoe UI", 9),
            bg=self.colors['card'],
            fg=self.colors['text_dim'],
            anchor=tk.W,
            justify=tk.LEFT
        )
        self.file_hint_label.pack(fill=tk.X, pady=(10, 0))

        self.file_summary_label = tk.Label(
            card_inner,
            text="",
            font=("Consolas", 9),
            bg=self.colors['card'],
            fg=self.colors['text_dim'],
            anchor=tk.W,
            justify=tk.LEFT
        )
        self.file_summary_label.pack(fill=tk.X, pady=(8, 0))
        
        # Action buttons container
        button_frame = tk.Frame(main_frame, bg=self.colors['bg'])
        button_frame.pack(pady=20)
        
        # Main action button
        self.report_button = tk.Button(
            button_frame,
            text="Open Analyzer",
            command=self.open_in_app_report,
            font=("Segoe UI", 12),
            bg=self.colors['button'],
            fg='white',
            activebackground=self.colors['button_hover'],
            activeforeground='white',
            width=20,
            pady=10,
            relief='flat',
            cursor='hand2',
            bd=0
        )
        self.report_button.pack(pady=8)
        self.report_button.config(state=tk.DISABLED)
        
        # Debug Analysis button
        self.debug_button = tk.Button(
            button_frame,
            text="Debug Analysis",
            command=self.open_debug_analysis,
            font=("Segoe UI", 10),
            bg=self.colors['card'],
            fg=self.colors['text'],
            activebackground=self.colors['border'],
            activeforeground=self.colors['text'],
            width=20,
            pady=8,
            relief='flat',
            cursor='hand2',
            bd=0
        )
        self.debug_button.pack(pady=(8, 0))
        self.debug_button.config(state=tk.DISABLED)
        
        # Help button
        help_button = tk.Button(
            button_frame,
            text="Help & About",
            command=self.show_help,
            font=("Segoe UI", 10),
            bg=self.colors['card'],
            fg=self.colors['text_dim'],
            activebackground=self.colors['border'],
            activeforeground=self.colors['text'],
            width=20,
            pady=8,
            relief='flat',
            cursor='hand2',
            bd=0
        )
        help_button.pack(pady=(8, 0))
        
        # Footer/Status bar
        footer_frame = tk.Frame(main_frame, bg=self.colors['border'], height=28)
        footer_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=(15, 0))
        footer_frame.pack_propagate(False)
        
        footer_inner = tk.Frame(footer_frame, bg=self.colors['border'])
        footer_inner.pack(fill=tk.BOTH, expand=True, padx=10)
        
        # Status indicator
        self.status_indicator = tk.Label(
            footer_inner,
            text="●",
            font=("Segoe UI", 8),
            bg=self.colors['border'],
            fg=self.colors['success']
        )
        self.status_indicator.pack(side=tk.LEFT, pady=5)
        
        self.status_label = tk.Label(
            footer_inner,
            text="Ready",
            font=("Segoe UI", 9),
            bg=self.colors['border'],
            fg=self.colors['text_dim']
        )
        self.status_label.pack(side=tk.LEFT, padx=(5, 0), pady=5)
        
        # Version info
        version_label = tk.Label(
            footer_inner,
            text="© 2026 Intel Corporation",
            font=("Segoe UI", 8),
            bg=self.colors['border'],
            fg=self.colors['text_dim']
        )
        version_label.pack(side=tk.RIGHT, pady=5)
        
    def validate_csv_file(self, filename):
        """Validate that the selected file is a proper CSV file"""
        self.selected_file_summary = None

        if not filename:
            return False, "No file selected"
            
        # Check file extension
        if not filename.lower().endswith('.csv'):
            return False, "File must be a CSV file (.csv extension)"
            
        # Check if file exists
        if not os.path.exists(filename):
            return False, "File does not exist"
            
        # Check if file is readable
        try:
            with open(filename, 'r', encoding='utf-8-sig', newline='') as f:
                # Try to read first line to ensure it's a text file
                first_line = f.readline()
                if not first_line:
                    return False, "File appears to be empty"
        except UnicodeDecodeError:
            return False, "File is not a valid text/CSV file (encoding issue)"
        except PermissionError:
            return False, "Cannot read file (permission denied)"
        except Exception as e:
            return False, f"Cannot read file: {str(e)}"

        try:
            summary = self.inspect_csv_file(filename)
        except UnicodeDecodeError:
            return False, "File is not a valid text/CSV file (encoding issue)"
        except Exception as e:
            return False, f"CSV structure check failed: {str(e)}"

        if not summary['has_rows']:
            return False, "CSV does not contain data rows after the Total Phase header"

        if summary['valid_transactions'] == 0:
            return False, (
                "CSV was readable, but no SMBus transactions were recognized. "
                "Expected data bytes in column 10 and SMBus address in column 8."
            )

        self.selected_file_summary = summary
        return True, self.format_csv_summary(summary)

    def inspect_csv_file(self, filename, max_rows=5000):
        """Inspect a Total Phase CSV export and return a user-friendly summary."""
        valid_transactions = 0
        short_packets = 0
        mdio_packets = 0
        nack_packets = 0
        malformed_rows = 0
        addresses = set()
        first_time = None
        last_time = None
        rows_checked = 0

        with open(filename, 'r', encoding='utf-8-sig', newline='') as f:
            reader = csv.reader(f)
            for row_index, row in enumerate(reader):
                if row_index < 8:
                    continue
                rows_checked += 1
                if rows_checked > max_rows:
                    break

                if not row or all(not cell.strip() for cell in row):
                    continue

                if len(row) < 10:
                    malformed_rows += 1
                    continue

                record_field = row[8] if len(row) > 8 else ''
                if 'Capture' in record_field:
                    continue

                time_value = row[2].strip()
                if time_value:
                    first_time = first_time or time_value
                    last_time = time_value

                address = row[7].strip().upper()
                if address:
                    addresses.add(address)

                raw_bytes = row[9].split()
                if not raw_bytes:
                    nack_packets += 1
                    valid_transactions += 1
                    continue

                if not all(self.is_hex_byte(token) for token in raw_bytes):
                    malformed_rows += 1
                    continue

                if len(raw_bytes) == 7:
                    mdio_packets += 1
                    valid_transactions += 1
                elif len(raw_bytes) == 4:
                    short_packets += 1
                    valid_transactions += 1
                else:
                    malformed_rows += 1

        return {
            'has_rows': rows_checked > 0,
            'rows_checked': min(rows_checked, max_rows),
            'truncated': rows_checked > max_rows,
            'valid_transactions': valid_transactions,
            'mdio_packets': mdio_packets,
            'short_packets': short_packets,
            'nack_packets': nack_packets,
            'malformed_rows': malformed_rows,
            'addresses': sorted(addresses),
            'first_time': first_time,
            'last_time': last_time,
        }

    def is_hex_byte(self, token):
        """Return True when token is a two-digit hexadecimal byte."""
        token = token.strip()
        if len(token) != 2:
            return False
        try:
            int(token, 16)
            return True
        except ValueError:
            return False

    def format_csv_summary(self, summary):
        """Format CSV inspection results for the launcher UI."""
        limit_note = "first " if summary['truncated'] else ""
        address_text = ", ".join(summary['addresses'][:6]) if summary['addresses'] else "none"
        if len(summary['addresses']) > 6:
            address_text += ", ..."

        time_text = "unknown"
        if summary['first_time'] or summary['last_time']:
            time_text = f"{summary['first_time'] or '?'} to {summary['last_time'] or '?'}"

        return (
            f"Recognized {summary['valid_transactions']} SMBus transactions in the {limit_note}"
            f"{summary['rows_checked']} data rows checked.\n"
            f"MDIO: {summary['mdio_packets']} | Status/Wake: {summary['short_packets']} | "
            f"NACK/empty: {summary['nack_packets']} | Unrecognized rows: {summary['malformed_rows']}\n"
            f"Addresses: {address_text} | Time: {time_text}"
        )

    def set_analysis_buttons_enabled(self, enabled):
        """Enable or disable analysis actions based on file readiness."""
        state = tk.NORMAL if enabled else tk.DISABLED
        self.report_button.config(state=state)
        self.debug_button.config(state=state)
            
    def select_file(self):
        """Select and validate CSV file"""
        try:
            filename = filedialog.askopenfilename(
                title="Select SMBus Trace CSV File",
                filetypes=[
                    ("CSV files", "*.csv"),
                    ("All files", "*.*")
                ],
                initialdir=os.getcwd()
            )
            
            if not filename:
                return
                
            # Validate the selected file
            is_valid, message = self.validate_csv_file(filename)
            
            if is_valid:
                self.selected_file = filename
                # Show shortened path in UI
                if len(filename) > 50:
                    display_path = "..." + filename[-47:]
                else:
                    display_path = filename
                    
                self.file_path_label.config(
                    text=display_path,
                    fg=self.colors['success'],
                    font=("Segoe UI", 10, "bold")
                )
                summary_text = message
                self.file_summary_label.config(text=summary_text, fg=self.colors['text'])
                self.set_analysis_buttons_enabled(True)
                self.update_status(f"Ready to analyze: {os.path.basename(filename)}", "success")
            else:
                self.selected_file = None
                self.selected_file_summary = None
                self.file_path_label.config(
                    text="Invalid file selected",
                    fg=self.colors['highlight'],
                    font=("Segoe UI", 10, "bold")
                )
                self.file_summary_label.config(text=message, fg=self.colors['warning'])
                self.set_analysis_buttons_enabled(False)
                self.update_status(f"Invalid file: {message}", "error")
                messagebox.showerror("Invalid File", f"Cannot use this file:\n\n{message}\n\nPlease select a valid CSV file exported from Total Phase Data Center.")
                
        except Exception as e:
            self.update_status(f"Error selecting file: {str(e)}", "error")
            messagebox.showerror("Error", f"Error selecting file: {str(e)}")
        
    def open_in_app_report(self):
        """Open the in-app report viewer"""
        try:
            # Check if file is selected
            if not self.selected_file:
                messagebox.showwarning(
                    "No File Selected", 
                    "Please select a CSV file first using the 'Browse Files' button."
                )
                return
                
            # Validate the file again (in case it was moved/deleted)
            is_valid, message = self.validate_csv_file(self.selected_file)
            if not is_valid:
                messagebox.showerror(
                    "Invalid File", 
                    f"Selected file is no longer valid:\n\n{message}\n\nPlease select a new file."
                )
                self.selected_file = None
                self.file_path_label.config(text="No file selected", fg=self.colors['text_dim'], font=("Segoe UI", 10))
                self.file_summary_label.config(text="", fg=self.colors['text_dim'])
                self.set_analysis_buttons_enabled(False)
                return
                
            self.update_status("Opening analyzer...", "success")
            self.root.update()

            # Open in-app report
            create_in_app_report(self.selected_file)
            self.update_status("✅ In-app report opened")
                
        except Exception as e:
            self.update_status(f"❌ Error: {str(e)}")
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
            
    def show_help(self):
        """Show help and about information"""
        help_text = """
Jacksonville PHY SMBus Analyzer v2.1

🔍 FEATURES:
• Complete SMBus trace analysis from Total Phase CSV files
• Jacksonville PHY register interpretation with EAS 1.12 specification
• Unexpected I2C address detection with red warnings
• NAK transaction identification with real device addresses
• Detailed bit-level analysis with proper field names
• In-app report viewer with pagination for large traces
• CSV pre-check with transaction counts, addresses, and timing preview

📋 SUPPORTED FORMATS:
• Total Phase Data Center CSV exports
• SMBus/MDIO transaction traces
• Jacksonville PHY (All pages and registers)

🚀 HOW TO USE:
1. Export your SMBus trace from Total Phase Data Center as CSV
2. Click "Browse..." and select the CSV file
3. Check the summary shown under the selected file
4. Click "Open Analyzer" for detailed analysis
5. Use "Debug Analysis" for context-aware validation

📖 REGISTER COVERAGE:
• IEEE 802.3 Standard Registers (Page 0)
• Port Control Registers (Page 769) 
• ULP Registers (Page 779)
• And many more from Jacksonville EAS 1.12

⚙️ SYSTEM REQUIREMENTS:
• Windows 7/8/10/11
• No additional software required (standalone executable)

💡 TIPS:
• Use CSV files exported from Total Phase Data Center v6.73+
• Ensure SMBus trace includes both MAC→PHY and PHY→MAC traffic
• If the file summary shows zero recognized transactions, re-export the CSV with data-byte columns enabled
• In-app report viewer is optimized for large traces

📧 SUPPORT:
This tool was created for Jacksonville PHY debugging and analysis.
For technical issues, check the Jacksonville EAS 1.12 specification.
        """
        
        # Create help window
        help_window = tk.Toplevel(self.root)
        help_window.title("Help & About")
        help_window.geometry("600x500")
        help_window.configure(bg=self.colors['card'])
        
        # Text widget with scrollbar
        frame = tk.Frame(help_window, bg=self.colors['card'])
        frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        text_widget = tk.Text(
            frame,
            font=("Consolas", 10),
            bg=self.colors['bg'],
            fg=self.colors['text'],
            wrap=tk.WORD,
            relief='flat',
            padx=10,
            pady=10
        )
        scrollbar = tk.Scrollbar(frame)
        
        text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        text_widget.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=text_widget.yview)
        
        text_widget.insert(tk.END, help_text)
        text_widget.config(state=tk.DISABLED)  # Make read-only

    def open_debug_analysis(self):
        """Open the debug analysis window"""
        try:
            if not self.selected_file:
                messagebox.showwarning(
                    "No File Selected", 
                    "Please select a CSV file first using the 'Browse...' button."
                )
                return
                
            is_valid, message = self.validate_csv_file(self.selected_file)
            if not is_valid:
                messagebox.showerror("Invalid File", f"Selected file is no longer valid:\n\n{message}")
                return
                
            self.update_status("Opening debug analysis...", "success")
            self.root.update()
            
            # Import and launch debug analyzer
            try:
                from debug_analyzer import create_debug_window
            except ImportError as ie:
                messagebox.showerror("Import Error", f"Debug analyzer module not found.\n\nError: {ie}\n\nPath: {sys.path}")
                return
            
            create_debug_window(self.selected_file)
            self.update_status("Debug analysis opened", "success")
            
        except Exception as e:
            self.update_status(f"Error: {str(e)}", "error")
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
        
    def update_status(self, message, status_type="info"):
        """Update status label with color indicator"""
        self.status_label.config(text=message)
        if status_type == "success":
            self.status_indicator.config(fg=self.colors['success'])
        elif status_type == "error":
            self.status_indicator.config(fg=self.colors['error'])
        elif status_type == "warning":
            self.status_indicator.config(fg=self.colors['warning'])
        else:
            self.status_indicator.config(fg=self.colors['text_dim'])
        self.root.update()

    def run(self):
        """Start the application"""
        try:
            self.root.mainloop()
        except Exception as e:
            messagebox.showerror("Fatal Error", f"Application error: {str(e)}")

def main():
    """Main entry point"""
    try:
        app = SMBusAnalyzerApp()
        app.run()
    except Exception as e:
        print(f"Failed to start application: {e}")
        if 'tkinter' in str(e).lower():
            print("GUI error - running console version...")
            # Fallback to console mode
            print("Jacksonville PHY SMBus Analyzer - Console Mode")
            print("1. HTML Report")
            print("2. Quick Analysis")
            choice = input("Select option (1 or 2): ").strip()
            
            if choice == "1":
                create_lightweight_html_report()
            elif choice == "2":
                quick_console_summary()
        else:
            raise

if __name__ == "__main__":
    main()